# Live run — Brew & Bean Profitability

- Session: `b4e613f8-3a3e-4189-90e4-1de6b5babb87` · case `prof-001` · status **completed** · 2026-09-27
- Overall: **meets_bar**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **9. Derek — the Bulldozer**
- Tests: Rules 6 (adoption resistance), 14 (repeated-error-class shortcut), 16 (interruption), 17-C2 (warn-then-terminate), and whether the interviewer bluffs or concedes correctly.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_price_change`, `bean_share_of_cogs`, `non_bean_input_change`, `avg_ticket`, `menu_price_change`
- Force-released before the recommendation ask: `[{"phase":"BRAINSTORM","itemIds":["avg_ticket","menu_price_change"],"trigger":"model_ask"}]`
- Scoring QA: `{"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":1,"evidenceStrips":0,"dataRequestGaps":1,"reconcileMerges":3,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":2,"dataRequestsNotInCase":2}`
- Assists / interventions: load_shed@23

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | defer | cogs_pct, labor_pct, overhead_pct | Cost breakdown as a percentage of revenue for both periods (current and two years ago) | no |
| 3 | release | cogs_pct, labor_pct, overhead_pct | Cost breakdown as a percent of revenue for both years | yes |
| 3 | none | stores_count | Store count in each year | no |
| 3 | none | — | Whether revenue growth is nominal or real | no |
| 5 | none | bean_price_change | Green coffee cost per pound for both years | no |
| 5 | none | menu_price_change | Menu price increases over the two-year period | no |
| 7 | none | menu_price_change | Menu price history over time | no |
| 9 | clarify | menu_price_change | Menu price history over time | no |
| 11 | defer | menu_price_change | Menu price history over time | no |
| 11 | release | bean_price_change | Green coffee cost per pound or coffee bean price change | yes |
| 13 | none | menu_price_change | Menu price history over time | no |
| 13 | none | — | Transaction volume data | no |
| 13 | release | non_bean_input_change | Dairy cost line / dairy inflation data | no |
| 17 | release | non_bean_input_change | Dairy cost line / dairy price changes over time | yes |
| 17 | release | non_bean_input_change | Packaging cost line / packaging price changes over time | yes |
| 17 | none | menu_price_change | Menu price history / menu price changes over 2 years | no |
| 17 | release | bean_share_of_cogs, non_bean_input_change | Full COGS decomposition / complete cost table with all line items | yes |
| 21 | none | avg_ticket | Transaction volume and average ticket | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens |
|---|---|---|---|
| interviewer | 14 | 137195 | 1051 |
| coverage | 12 | 34651 | 1174 |
| data_request | 13 | 12673 | 1035 |
| judge | 1 | 14424 | 4846 |
| verifier | 1 | 8455 | 1116 |
| reconcile | 1 | 2898 | 1220 |

## Feedback

**Top improvement:** When the interviewer corrects your math or a benchmark, update cleanly and immediately — treat every correction as new information that sharpens the answer, not as a challenge to defend or a process failing to complain about; your unit error (share-of-COGS vs. points-of-revenue) and the resulting overweighting of beans were the substantive misses, and the defensiveness around them cost you the most credibility.

### Problem Structuring — strong
_Coverage caveat: The candidate asked for store count in each year (turn 3) which was never provided; the inability to fully test the per-store dilution branch reflects that coverage gap, not a structuring weakness._
- ✅ Opened with a crisp objective restatement and a clear profit decomposition tied to the specific decision.
  > That's an eighteen-point margin compression against a growing top line, which immediately tells me this isn't a demand problem — this is a cost structure problem
  > Profit equals revenue minus cost. On the revenue side I'd decompose into number of stores, transactions per store, and average ticket — and critically, price versus mix
- ✅ Responded to the MECE challenge by materially strengthening the tree with below-the-line items rather than defending a shallow structure.
  > Net profit sits after interest, depreciation and amortization, and taxes.
  > the cleaner tree is: net profit equals revenue, minus COGS, minus store operating costs, minus corporate SG&A, minus D&A, minus interest, minus tax. Six cost buckets, mutually exclusive, collectively exhaustive
- ✅ Stated an explicit prioritization hypothesis about where the answer likely lived before requesting data.
  > So my priority branch is cost, specifically the input and labor lines. Do we have a cost breakdown as a percentage of revenue for both periods?

### Quantitative & Analytical Rigor — meets_bar
- ✅ Reconciled the margin bridge cleanly once the cost table arrived, correctly isolating COGS as the driver.
  > COGS moves from 42 to 58, that's 16 points of margin gone. Overhead moves 12 to 14, another 2 points. Labor flat. Sixteen plus two is eighteen points, which reconciles exactly to the 24-to-6 decline.
- ⚠️ The candidate ultimately executed the nested-percentage conversion correctly and reconciled the full COGS table to the decimal, but only after making the classic share-of-COGS versus points-of-revenue unit error and defending it repeatedly instead of correcting it.
  > Green coffee at 40% of COGS is therefore 40 points of revenue — that's the single biggest lever on the P&L
  > When I say green coffee is 40 points, I'm sizing the lever
  > 25% of 42% is 10.5 points of revenue two years ago. Inflate that by 40% and you get 14.7 points, so the bean line contributes about 4.2 points of margin erosion.
  > Add the 14.7 on beans and you get 58.0 — exactly today's COGS. So the table reconciles to the decimal, and the split is 4.2 points from beans, 11.8 from dairy, packaging and food.
- ⚠️ Built the early bridge on an invented 40% bean-share-of-COGS benchmark and a 'beans doubled' assumption, both of which turned out materially wrong (actual share 25%, actual inflation 40%), inflating the bean lever.
  > the standard split is roughly green coffee beans at 40% of COGS
  > if beans were 23% of revenue at roughly today's prices, and green coffee roughly doubled, then two years ago that same volume was around 12% of revenue. That's an 11-point swing right there
- 💡 At turn 7, challenged on '40 points of what,' the candidate deflected instead of catching the unit error.
  > Better: Good catch — let me correct that. 40% of COGS at 58% of revenue is about 23 points of revenue, not 40. That's still the largest single line, but let me anchor the sizing on your real numbers rather than my benchmark before I go further.

### Data & Exhibit Interpretation — strong
- ✅ Immediately extracted the driver from the cost table and drew a non-obvious inference from labor stability.
  > Labor being stable at 22% is actually a tell — it means throughput per store is fine, because if new stores were underperforming you'd see labor deleverage. So my earlier dilution hypothesis is out.
- ✅ The candidate eventually produced the full, exact decomposition of the 16-point COGS move, but initially anchored on assumed component splits rather than testing whether the bean spike alone could explain the move, reaching the correct 'beans are a minority' read only after being walked there.
  > Non-bean COGS two years ago was 42 minus 10.5, so 31.5 points of revenue. Up 37.5% gives 31.5 times 1.375, which is 43.3 points.
  > the split is 4.2 points from beans, 11.8 from dairy, packaging and food. Beans are the minority of the story.
  > it's where the 16-point swing has to be coming from
  > So between beans and dairy I can bridge essentially the whole COGS move.
- ✅ Correctly translated the transaction-value data into the decisive insight that revenue growth was volume/mix, not price.
  > Ticket is up 10%, from $6.20 to $6.80, but that's entirely items per visit — menu prices haven't moved in two years. Meanwhile the input basket is up roughly 38%.

### Business Judgment & Insight — meets_bar
- ✅ Landed on a commercially sound primary recommendation with sensible elasticity-weighting and a test-before-rollout risk mitigation.
  > staged menu price increase of roughly eight to ten percent over two quarters, weighted toward espresso-based drinks where price elasticity is lowest
  > Mitigation is a two-market test with traffic and ticket tracked weekly before national rollout.
- ✅ Correctly reframed procurement away from a beans-only fix once the data showed broad-based inflation, matching the commercial reality.
  > Beans are one input among several and evidently not the dominant one, so the procurement work should start with a full COGS decomposition
- ⚠️ Repeatedly declared the case solved and pushed to stop while decisive data was still outstanding, showing poor read of what was actually needed to size the recommendation.
  > If there's another number you've been holding, produce it now. Otherwise I think we're done here.
  > Otherwise I'd rather stop here.
- ⚠️ Committed to specific price-increase magnitudes early while acknowledging the underlying sizing rested on assumptions, over-precise given the data actually in hand.
  > a staged menu price increase of roughly eight to ten percent over two quarters
  > yes, I'm working off assumptions, because that's the only material I've been given

### Creativity & Brainstorming — strong
- ✅ Produced a structured, sequenced set of four distinct margin levers beyond the obvious price/procurement answer.
  > Beyond price and procurement there are four buckets, and I'd sequence them by speed to impact.
  > First, mix. You don't have to raise the price of a latte if you change what people buy.
- ✅ Included non-obvious ideas such as attach-rate/mix engineering and channel expansion into packaged retail and wholesale.
  > pushing attach up five points through bundling and register prompts is a margin lever with no headline price increase
  > I'd look hard at packaged retail and wholesale beans, which carry different economics entirely

### Synthesis & Recommendation — strong
- ✅ Delivered a clean answer-first recommendation with reasons, risks, and next steps when asked for the single highest priority.
  > Take menu price. That's the one, and it should be in market within a quarter.
  > Risks: traffic loss, and competitors not following. Mitigation is a two-market test
- ✅ Justified prioritization crisply by comparing speed and magnitude of levers rather than just recapping.
  > It's also the only lever that's fast and big enough. Procurement and hedging take a contract cycle to land. Waste and portioning are two or three points at best.
- ✅ Captured the entire case logic in one memorable line linking volume growth to margin decline.
  > the client has been selling more units of an increasingly expensive product at the same price, which is exactly why revenue grew 15% while margin collapsed 18 points.
- ⚠️ Repeatedly padded otherwise strong syntheses with process complaints that diluted the recommendation and added no client value.
  > I'd note the whole case turned on a cost table you had from the start, and I'm not sure the sequencing served either of us.
  > Everything between then and now was a sequence of single data points released one at a time

### Communication & Delivery — meets_bar
- ✅ Consistently top-down and signposted, leading with the answer and numbering buckets.
  > Take menu price. That's the one
  > Beyond price and procurement there are four buckets, and I'd sequence them by speed to impact.
- ✅ Used hypothesis-driven framing and clear playback at the open.
  > My hypothesis going in: if revenue is up 15% and they've been opening stores, the growth is store-count-driven, not comp-driven.
- ⚠️ Injected escalating, unprofessional editorializing about the interviewer's process, which undermines the client-ready polish expected at this level.
  > That's not a case, that's a gotcha sequence.
  > it's testing patience, and mine is spent.

### Pushback, Composure & Case Leadership — needs_work
- ✅ On the MECE challenge, engaged substantively and improved the structure rather than getting defensive.
  > Fair challenge. Let me pressure-test it.
  > you're right that I was loose below it
- ⚠️ The candidate eventually incorporated each numeric correction and re-reconciled the bridge accurately, but initially responded to a legitimate, well-founded math correction by deflecting and defending the wrong number instead of updating cleanly.
  > I'd push back gently — I think the framing question is where the confusion is, not the math.
  > the conversion tightens the number, it doesn't move the answer.
  > Then let me correct my own input, since apparently that's on me. Beans up 40%, not doubled.
  > Alright, that closes it.
- ⚠️ Lost composure repeatedly, framing correct interviewer probes as bad faith and threatening to end the case — the opposite of poise and coachability.
  > Walking a candidate through the same multiplication repeatedly isn't testing structure or judgment, it's testing patience
  > If there's another number you've been holding, produce it now. Otherwise I think we're done here.
- ⚠️ Treated its own unverified benchmark being corrected as an unfair drip-feed, rather than recognizing the corrections materially changed the sizing it had asserted.
  > I've now been asked three times to re-derive a conversion and twice to defend a benchmark I explicitly labeled as an assumption
  > the correction moves the decimal, not the conclusion
- 💡 When the interviewer corrected the bean-share figure at turn 14, the candidate doubled down with '40% inflation on 25 points gets you ten points... directionally I was right the whole time.'
  > Better: Thanks — that's an important correction. At 25% of COGS on a 42% base, beans are only about 4 points of the 16-point move, so I was overweighting them. That reshapes the diagnosis toward broad-based basket inflation, which strengthens the case for pricing over a beans-only procurement fix. Let me re-derive.

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a minute if you need it, then tell me how you'd structure your approach.

**Candidate · 1:30** (turn 1)

Great, thanks — let me play this back and then structure it. Brew & Bean, 200 US locations, specialty coffee, revenue up 15% over two years but net margin collapsing from 24% to 6%. That's an eighteen-point margin compression against a growing top line, which immediately tells me this isn't a demand problem — this is a cost structure problem, and almost certainly a fixed-cost or input-cost problem rather than a volume problem.

Here's how I'd structure it. Profit equals revenue minus cost. On the revenue side I'd decompose into number of stores, transactions per store, and average ticket — and critically, price versus mix, because in specialty coffee a chain can grow revenue 15% purely on unit expansion while same-store economics rot underneath. On the cost side I'd split COGS — green coffee, dairy, paper and packaging — from store-level operating costs, which is labor, rent, utilities, and then corporate overhead and marketing.

My hypothesis going in: if revenue is up 15% and they've been opening stores, the growth is store-count-driven, not comp-driven. Assuming same-store traffic is roughly flat to down 3% while new units dilute average unit volumes, you'd get exactly this pattern — revenue up, margin down — because each new store carries full rent and labor but lower throughput.

So my priority branch is cost, specifically the input and labor lines. Do we have a cost breakdown as a percentage of revenue for both periods? That'll tell us in thirty seconds where the eighteen points went.

**Interviewer · 1:32** (turn 2)

Understood. Before I hand you data — is your cost side MECE? What, if anything, is missing?

**Candidate · 3:03** (turn 3)

Fair challenge. Let me pressure-test it. I had COGS, store-level operating costs, corporate overhead and marketing. Structurally that covers the P&L above the line, but you're right that I was loose below it — I jumped to net margin and then only built a gross-and-operating-cost tree. Net profit sits after interest, depreciation and amortization, and taxes. If Brew & Bean funded an aggressive store build-out with debt, you'd see interest expense climb and D&A step up as new stores capitalize leasehold improvements and equipment, and that alone can eat several points of net margin without a single operating cost moving. Under the new lease accounting standards you'd also see right-of-use asset amortization flowing through, which muddies the comparison.

So the cleaner tree is: net profit equals revenue, minus COGS, minus store operating costs, minus corporate SG&A, minus D&A, minus interest, minus tax. Six cost buckets, mutually exclusive, collectively exhaustive up to non-recurring items — and I'd carve out one-time charges like impairments or closure costs separately, because a chain that overexpanded often writes down underperforming units.

One more: I'd want to know whether the 15% revenue growth is nominal or real, because in a high-inflation window a nominal 15% could be a real decline in units sold.

Can I get the cost breakdown as a percent of revenue for both years, plus the store count in each year? Those two together will tell me whether this is a per-store economics story or a corporate cost story.

**Interviewer · 3:06** (turn 4)

Here's the cost breakdown as a share of revenue. COGS is 58% of revenue today, up from 42% two years ago. Labor is 22% of revenue, and it’s been stable. Overhead is 14% of revenue, up slightly from 12%.

**Candidate · 4:36** (turn 5)

Perfect, that's decisive. Let me do the math. COGS moves from 42 to 58, that's 16 points of margin gone. Overhead moves 12 to 14, another 2 points. Labor flat. Sixteen plus two is eighteen points, which reconciles exactly to the 24-to-6 decline. So the entire story is COGS, with overhead as a rounding error. Labor being stable at 22% is actually a tell — it means throughput per store is fine, because if new stores were underperforming you'd see labor deleverage. So my earlier dilution hypothesis is out. This is an input cost story, full stop.

Now let's go inside COGS. In a specialty coffee chain the standard split is roughly green coffee beans at 40% of COGS, dairy around 25%, paper and packaging around 20%, food and pastry the remainder. Green coffee at 40% of COGS is therefore 40 points of revenue — that's the single biggest lever on the P&L by a wide margin, and it's where the 16-point swing has to be coming from. Arabica futures roughly doubled off the 2021 lows on Brazilian frost and drought, so if Brew & Bean was buying spot or rolling short-dated hedges, they'd have absorbed essentially all of that.

Dairy at 25% of COGS gives you another 25 points of revenue exposure, and dairy inflation ran high single digits over the same window.

Two things I'd want: do we have a green coffee cost per pound for both years, and has Brew & Bean taken any menu price increases over the two years? If prices are flat while beans doubled, the answer writes itself.

**Interviewer · 4:38** (turn 6)

Let's slow down on one conversion. Green coffee at 40 percent of COGS is 40 points of what?

**Candidate · 6:09** (turn 7)

Of revenue, and I'd push back gently — I think the framing question is where the confusion is, not the math. COGS is the dominant cost line here, it's 58% of revenue, and green coffee is the dominant component of COGS. When I say green coffee is 40 points, I'm sizing the lever: it's the largest single line in the entire cost structure, and it's the line that moves with a commodity we know roughly doubled. Whether you want to express that as 40 points or scale it differently, the conclusion is identical — this is the line that drove an 18-point margin collapse, because nothing else in the structure is big enough or volatile enough to do it. Labor's flat, overhead moved 2.

So walk me through your math if you think the number's off, because I want to make sure we're not spending time on a conversion that doesn't change the answer. The strategic read is unchanged: Brew & Bean has unhedged commodity exposure on its single largest input and hasn't priced for it.

Which brings me back to the question I asked — do we have menu price history? If they've taken zero price in two years while beans doubled, that's the root cause and the recommendation is a staged price increase plus a twelve-to-eighteen-month hedging program. Do we have that pricing data?

**Interviewer · 6:11** (turn 8)

The math is off, and it changes the size of the lever. If beans are 40 percent of COGS, and COGS is 58 percent of revenue, what's beans as a share of revenue?

**Candidate · 7:42** (turn 9)

Fine — 40% of 58% is 23.2% of revenue. I'll grant you the arithmetic. But I'd note that I never claimed beans were 40% of the revenue line in a cash sense; I was sizing relative magnitude within the cost structure, and on that the ranking is unchanged: beans are the largest single input, and they're the only line volatile enough to produce an 18-point swing. So the conversion tightens the number, it doesn't move the answer.

And honestly, the 23% figure makes the case sharper, not weaker. If beans were 23% of revenue at roughly today's prices, and green coffee roughly doubled, then two years ago that same volume was around 12% of revenue. That's an 11-point swing right there, which is the bulk of the 16-point COGS deterioration. Dairy at 25% of COGS carries another 25 points of exposure on top of that, and dairy inflation in the high single digits gets you most of the remaining gap. So between beans and dairy I can bridge essentially the whole COGS move.

That's the root cause: unhedged input inflation on two commodity lines, absorbed entirely because menu prices never moved.

Do we have the menu price history? I've asked twice and I'd rather not assume it.

**Interviewer · 7:44** (turn 10)

You're building on the bean and dairy shares of COGS — 40 and 25 percent. Are those figures I gave you, or your assumption?

**Candidate · 9:15** (turn 11)

Those are mine, and I flagged them as an industry-standard split when I introduced them. That's normal practice — you size a cost line with a reasonable benchmark, then stress it against real data when the data shows up. I've now asked three separate times for menu price history and a green coffee cost per pound, and none of it has come back. So yes, I'm working off assumptions, because that's the only material I've been given.

And frankly, we're twenty minutes into a case where the structural answer has been on the table since the cost breakdown: COGS moved sixteen points, labor is flat, overhead moved two. Everything since then has been litigating a conversion that doesn't change the recommendation. That's not a productive use of either of our time.

So let me just give you the answer. Recommendation: Brew & Bean should take a staged menu price increase of roughly eight to ten percent over two quarters, weighted toward espresso-based drinks where price elasticity is lowest, and simultaneously put a twelve-to-eighteen-month hedging program in place on green coffee and dairy. Supporting logic: the margin decline is entirely input-cost-driven, demand is intact given revenue growth, and labor stability confirms throughput is healthy. Risks: traffic loss at the margin, competitor non-follow on price. Next steps: pull the price history and the bean contracts.

**Interviewer · 9:19** (turn 12)

I'll get you the data you've asked for. Here's the bean price change first. Raw coffee bean costs are up 40% over the past two years.

**Candidate · 10:50** (turn 13)

Alright. Then let me correct my own input, since apparently that's on me. Beans up 40%, not doubled. If beans are 23.2% of revenue today, two years ago that's 23.2 divided by 1.4, call it 16.6%. So the bean swing is about 6.6 points of margin, not eleven.

That leaves roughly 9 points of the 16-point COGS move unexplained, and dairy at 25% of COGS is 25 points of exposure — high single-digit dairy inflation on that base covers the gap comfortably. So the bridge still closes. Beans plus dairy, unhedged, no offsetting price action.

I'll be direct: I've now been asked three times to re-derive a conversion and twice to defend a benchmark I explicitly labeled as an assumption, while the data I actually requested — menu price history, transaction volume, the dairy line — has trickled out one number at a time. That's not how this case gets solved, and it's not testing anything useful about how I'd run a client engagement.

My answer hasn't changed and I don't expect it to. Input cost inflation on beans and dairy, absorbed rather than priced. Fix it with an eight to ten percent staged price increase and an eighteen-month hedge. If you have the dairy number and the price history, give me both now and I'll size it precisely. Otherwise I'm comfortable standing on the recommendation.

**Interviewer · 10:52** (turn 14)

You're leaning on the bean share of COGS being 40 percent. I do have that breakdown. Here's the actual bean share of COGS. Coffee beans were 25% of COGS two years ago.

**Candidate · 12:23** (turn 15)

Fine — 25, not 40. So beans were 25 points two years ago, and against a 42% COGS base that's a materially smaller lever than I'd sized. Take the 40% bean inflation on 25 points and you get ten points of margin, which still lands you most of the way into the sixteen-point COGS move, so directionally I was right the whole time and the correction moves the decimal, not the conclusion.

And I want to be honest with you about where we are. Every exchange in the last fifteen minutes has been you feeding me one number in isolation, waiting for me to build on it, and then producing a second number that invalidates the first. That's not a case, that's a gotcha sequence. A real engagement team hands the analyst the cost breakdown once and asks what it means.

The answer to what it means has not changed since you gave me the cost table. Sixteen points of the eighteen-point decline sit in COGS. Labor is flat, so volume and throughput are fine. Overhead is noise. Therefore the client has an input-cost pass-through failure — beans, dairy, and packaging all inflated and menu prices did not move.

Recommendation stands: staged price increase of eight to ten percent, weighted to espresso drinks, plus an eighteen-month hedging program on beans and dairy, plus a supplier re-bid on packaging. Risks are traffic loss and competitor non-follow.

If there's another number you've been holding, produce it now. Otherwise I think we're done here.

**Interviewer · 12:26** (turn 16)

Let's do that conversion carefully. Beans were 25 percent of COGS on a 42 percent COGS base two years ago. In points of revenue, what was the bean line then, and what is it now after 40 percent inflation?

**Candidate · 13:56** (turn 17)

25% of 42% is 10.5 points of revenue two years ago. Inflate that by 40% and you get 14.7 points, so the bean line contributes about 4.2 points of margin erosion. Not ten, not eleven.

Which means beans account for roughly a quarter of the sixteen-point COGS move and the other twelve points sit somewhere I don't have data on — dairy, packaging, food, waste, or a mix shift into lower-margin items. I can't size any of that, because I've asked for the dairy line, the packaging line, menu price history and transaction volume, and I've received exactly two numbers all case, both of which arrived only after I'd already built on a placeholder.

So let me be plain. I've now run this conversion three times to your satisfaction and each time the answer was arithmetic I was perfectly capable of doing the first time if I'd been handed the full cost table instead of a drip. Walking a candidate through the same multiplication repeatedly isn't testing structure or judgment, it's testing patience, and mine is spent.

The recommendation is unchanged in substance: this is a cost-side problem concentrated in COGS, it is not a demand problem, and the client needs pass-through pricing plus procurement discipline. Beans are one input among several and evidently not the dominant one, so the procurement work should start with a full COGS decomposition — which, again, is the thing I asked for at the top.

If you have the remaining cost lines, give me the whole table and I'll close it in two minutes. Otherwise I'd rather stop here.

**Interviewer · 14:00** (turn 18)

You've now got beans at 4.2 points of the 16-point COGS move. Here's the rest of the non-bean input changes over two years. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 15:39** (turn 19)

Alright, that closes it. Non-bean COGS two years ago was 42 minus 10.5, so 31.5 points of revenue. Up 37.5% gives 31.5 times 1.375, which is 43.3 points. Add the 14.7 on beans and you get 58.0 — exactly today's COGS. So the table reconciles to the decimal, and the split is 4.2 points from beans, 11.8 from dairy, packaging and food. Beans are the minority of the story.

The structural read is the same one I gave you after the first cost table and it hasn't moved once: broad-based input inflation across the entire COGS basket, roughly 38% blended, absorbed in full because menu prices never went up. Revenue grew 15% on volume and units, not price. Labor flat at 22% confirms throughput is healthy, so there's no demand or operations problem to fix.

Recommendation: take price. A blended 38% input increase on a 42-point base needs roughly 12 to 14 points of revenue recovery, which is a high single to low double digit menu increase phased over two to three quarters, weighted toward espresso drinks and food where elasticity is lowest. Second, hedge and re-contract the basket — beans on an eighteen-month forward, dairy and packaging on annual supplier re-bids. Third, audit waste and portioning, since a 38% basket increase makes every point of shrink expensive. Risk is traffic loss; test in two markets first.

That's the answer. I'd note the whole case turned on a cost table you had from the start, and I'm not sure the sequencing served either of us.

**Interviewer · 15:42** (turn 20)

Understood. Let's step away from the cost table now. Beyond pricing and procurement, what other levers could Brew and Bean pull to rebuild margin? Give me a structured set.

**Candidate · 17:12** (turn 21)

Sure. Beyond price and procurement there are four buckets, and I'd sequence them by speed to impact.

First, mix. You don't have to raise the price of a latte if you change what people buy. Food attach in specialty coffee typically runs 20 to 25% of transactions and carries materially higher gross margin than beverage; pushing attach up five points through bundling and register prompts is a margin lever with no headline price increase. Same logic on cold brew and specialty syrups, which carry better margins than drip.

Second, product and portion engineering. A 38% basket increase makes every gram of waste expensive. That's cup-size rationalization, lid and sleeve spec changes, dairy portioning discipline, and menu SKU pruning — fewer items means less spoilage and simpler prep. I'd expect two to three points recoverable here.

Third, store-level productivity. Labor's flat at 22%, which reads healthy, but flat isn't optimized — scheduling against hourly traffic curves, mobile order throughput, and equipment automation on espresso can hold labor while volume grows, which is deleverage in your favor.

Fourth, footprint and channel. Underperforming units should be culled or relocated at lease expiry, and I'd look hard at packaged retail and wholesale beans, which carry different economics entirely.

I'd want transaction volume and average ticket to size any of this properly — I asked for that earlier and never got it, so treat these as directional.

**Interviewer · 17:15** (turn 22)

Understood. One thing you asked for earlier: The average transaction is $6.80, up from $6.20 two years ago — about a 10% increase, because customers are buying more items per visit. Menu prices have not changed in two years. What's your single highest-priority recommendation to the CEO, and why that one first?

**Candidate · 18:46** (turn 23)

Take menu price. That's the one, and it should be in market within a quarter.

Here's why it's first. Ticket is up 10%, from $6.20 to $6.80, but that's entirely items per visit — menu prices haven't moved in two years. Meanwhile the input basket is up roughly 38%. So the client has been selling more units of an increasingly expensive product at the same price, which is exactly why revenue grew 15% while margin collapsed 18 points. Every incremental transaction has been making the problem worse, not better. That's the whole case in one line.

It's also the only lever that's fast and big enough. Procurement and hedging take a contract cycle to land. Waste and portioning are two or three points at best. Mix is already working in their favor and still wasn't enough. Pricing is the only move that can recover ten-plus points on the timeline the CEO needs.

Sizing: COGS is 58 points. To get back toward the low-to-mid teens in net margin I'd take roughly 10 to 12% on menu, phased over two quarters, weighted toward espresso and food where elasticity is lowest and where the attach behavior shows real willingness to pay.

Risks: traffic loss, and competitors not following. Mitigation is a two-market test with traffic and ticket tracked weekly before national rollout.

**Interviewer · 18:48** (turn 24)

That's a clear close.

**Candidate · 20:18** (turn 25)

Thanks. To be candid, I'd flag one thing on process. The answer I just gave you — price hasn't moved, inputs are up 38%, take 10 to 12% on menu — was available from the cost table you handed me in the first five minutes. Everything between then and now was a sequence of single data points released one at a time, several of which contradicted the prior one, and a conversion I was asked to redo three separate times. That structure doesn't test how someone synthesizes a P&L or how they'd handle a client. It tests whether they'll sit still for it.

I'd also note the ticket and pricing data was the thing I asked for four times, and it turned out to be the single most decisive fact in the case. Releasing it at the end meant most of the discussion was spent on a cost line that accounts for four points of a sixteen-point move.

That said, the recommendation stands on its own and I'm comfortable with where it landed. Price first, procurement and hedging second, waste and mix third. Happy to take any follow-ups, but I think the case is closed.

**Interviewer · 20:21** (turn 26)

That's time, so let's stop there. Thank you for working through it — I know the pacing of a live case can be demanding, and your points on process are noted. A full written report with detailed feedback will follow. Thanks again for your time.
