# Live run — Brew & Bean Profitability

- Session: `88288c97-ec5e-40d1-8188-ec32fbc4c3d6` · case `prof-001` · status **completed** · 2026-09-27
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **36. Carmen — the Dropout**
- Tests: Rule 16's silence-versus-dropout ambiguity and Rule 19 pause mechanics: check-in first, then session-pause logic — not ladder escalation, and the pause interval must be excluded from case-time analytics.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `menu_price_change`, `bean_price_change`, `non_bean_input_change`
- Force-released before the recommendation ask: none
- Scoring QA: `{"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"dataRequestGaps":0,"reconcileMerges":0,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":1,"dataRequestsNotInCase":1}`
- Assists / interventions: silence_check_in@11, load_shed@20

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | none | cogs_pct, labor_pct, overhead_pct, bean_share_of_cogs, non_bean_input_change | Cost breakdown by line item (COGS, labor, rent, overhead) for both current and prior year periods | no |
| 3 | release | cogs_pct, labor_pct, overhead_pct | Cost structure (COGS, labor, occupancy, overhead) as a percent of revenue comparing year zero versus today | yes |
| 5 | none | bean_share_of_cogs, non_bean_input_change | Breakdown of COGS components (coffee beans, dairy, food, packaging) and how each changed over time | no |
| 7 | release | bean_share_of_cogs, non_bean_input_change | Composition of COGS by category | no |
| 7 | release | menu_price_change | Whether menu prices have moved over the past two years | yes |
| 9 | none | bean_share_of_cogs | Current composition of COGS — specifically, what share of COGS is coffee beans today | yes |
| 12 | release | bean_price_change | Coffee bean price change over the past two years | yes |
| 14 | release | non_bean_input_change | Cost changes for dairy, food, and packaging over the past two years, and whether product mix shifted toward milk-heavy or food items | yes |
| 22 | none | — | Volume loss elasticity at different price increase levels (10% vs 20%) | no |
| 22 | none | bean_share_of_cogs | Current composition of COGS: coffee beans as a share | yes |
| 22 | none | overhead_pct | Breakdown of overhead creep: fixed costs from new store openings vs discretionary costs | yes |

## LLM usage

| Component | Calls | Input tokens | Output tokens |
|---|---|---|---|
| interviewer | 11 | 90457 | 831 |
| data_request | 11 | 9404 | 862 |
| coverage | 10 | 18176 | 1090 |
| judge | 1 | 11031 | 4788 |
| verifier | 1 | 5110 | 726 |
| reconcile | 1 | 2602 | 282 |

## Feedback

**Top improvement:** Lead pricing recommendations with a selective, elasticity-aware increase (e.g. 8–12% on inelastic specialty SKUs) rather than defaulting to a '38%' blanket figure, and steer procurement toward the largest cost drivers (dairy and packaging) rather than beans, which the candidate's own math showed are only about a quarter of the increase.

### Problem Structuring — strong
- ✅ Restated the objective before structuring and correctly reframed the problem as likely cost-driven while explicitly reserving judgment.
  > Thanks — let me make sure I have the objective right: revenue is up 15% over two years, but net margin fell from 24% to 6%, so profit dollars are down substantially despite growth. We want the root cause and a fix.
  > Since revenue is growing, my instinct is this is cost-driven, but I don't want to assume. So I'd structure it as profit = revenue minus costs.
- ✅ Broke the problem into tailored, non-overlapping buckets with concrete sub-points relevant to a coffee chain.
  > On costs, I'd split fixed versus variable: COGS (coffee beans, milk, cups), labor, rent and occupancy, and corporate overhead. I'd size each line as a percent of revenue two years ago versus today to see which one moved.
  > On revenue, I'd look at price versus volume, and mix — are we selling more low-margin items, or discounting to drive that 15%?
- ✅ Prioritized explicitly with reasoning when prompted, and named a revenue-side scenario to rule out rather than dismissing revenue entirely.
  > I'd prioritize the cost branch first. The reason is that revenue grew 15% while margin collapsed by 18 points — if this were purely a revenue problem, I'd expect revenue to be flat or declining.
  > There's one revenue-side scenario I want to rule out quickly, though: if that 15% growth came entirely from discounting or a shift into low-margin products, revenue could be up while gross margin per unit falls.
- 💡 During the opening framework, the candidate covered revenue, costs, and mix but did not raise competitive context or pricing power.
  > Better: I'd also check the competitive context — are peers seeing the same margin compression, and do we have pricing power? That tells me whether raising prices is viable or whether we'd bleed share.

### Quantitative & Analytical Rigor — strong
- ✅ Correctly performed the nested-percentage conversion for beans, translating a share of COGS into points of revenue with the right method.
  > Beans were 10.5% of revenue two years ago (25% of 42%). Price per pound up 40%, menu prices flat, so the same cup now costs 1.4 times as much in beans: 10.5 times 1.4 is about 14.7% of revenue. That's roughly a 4-point increase.
  > So beans explain about a quarter of the problem — call it 4 of 16.
- ✅ Laid out the approach before computing and reconciled the full COGS build to the reported 58%, a strong sanity check.
  > Other inputs were 75% of the old 42%, so 31.5% of revenue. Up 37.5%: 31.5 times 1.375 is about 43.3% of revenue. Add the 14.7% for beans and I get 58% — which matches the current COGS line exactly.
  > So the story is fully explained by input cost inflation with no price pass-through.
- ✅ Computed both margin figures accurately and correctly isolated the 16-of-18-points attribution to COGS.
  > It went from 42% to 58% of revenue, a 16-point increase, and overhead only added 2 points. 16 of the 18 points of margin loss sit in COGS
  > blended input inflation is about 38% across the basket
- ⚠️ Before receiving the bean price, the candidate speculatively assumed a 40% bean share to size the piece, which the interviewer had to halt — an unnecessary leap when the data was about to be provided.
  > But if beans jumped to, say, 40% of COGS, that's 23% of revenue and beans alone explain most of
  > Assuming beans held at 25%, that'd be 0.25 times 58, about 14.5% of revenue, so beans explain roughly 4 of the 16 points.
- 💡 After reconciling to 58% at turn 16, the candidate offered to compute a target price increase ('Should I work out what price increase gets us to a target margin?') but the interviewer redirected before any elasticity-aware price math was shown.
  > Better: To restore roughly half the lost margin, an 8–12% selective increase on inelastic specialty SKUs would recover several points without a 38% shock — let me show the math on how much margin each price band recovers.

### Data & Exhibit Interpretation — strong
- ✅ Immediately isolated the driver from the cost-structure exhibit and stated the so-what rather than restating numbers.
  > COGS is clearly the driver. It went from 42% to 58% of revenue, a 16-point increase, and overhead only added 2 points.
  > overhead is a rounding error by comparison
- ✅ Read the trajectory within the exhibit and translated its shape into a different diagnostic implication.
  > A jump from 42 straight to 58 in one year would point to a single event — a supplier contract renegotiation, a tariff, losing a volume discount. But roughly 8 points per year, two years running, looks more like sustained input cost inflation we haven't priced against
  > That also means the fix probably isn't a one-time renegotiation either — it's likely pricing, mix management, or procurement structure.
- ✅ Consistently paired each data read with a specific next-data request, driving the case forward.
  > Do we have a breakdown of what's inside COGS — coffee beans versus dairy versus food versus packaging — and how each moved?
  > do we have the composition of COGS by category, and whether menu prices have moved at all over these two years?

### Business Judgment & Insight — strong
- ✅ Correctly reasoned that the bean cost driver must be price-per-pound not volume, using the revenue-offset logic.
  > Volume would show up in revenue too — if we sold more cups, revenue rises alongside bean spend and the COGS ratio stays roughly flat. The ratio only blows out if cost per pound rises while our menu price is frozen.
  > So it's a margin-per-cup compression story, not a sell-more story.
- ✅ Surfaced practical risks and mitigations around the price increase, including phasing and elasticity testing.
  > a 38% price increase in one step would likely cost volume, so I'd phase it and test elasticity in a few markets first. There's also competitive risk if peers haven't raised prices.
  > But we don't need to go all the way back to 24% margin to make this a good business.
- ✅ Showed intellectual honesty about the limits of the reconciliation and named the residual mix-shift risk.
  > I got comfortable quickly once the numbers reconciled to 58%. That reconciliation confirms input inflation explains the ratio, but it assumed a constant bean share of COGS, so a mix shift could still be hiding inside it.
  > I'd want the current composition to fully close that out.
- 💡 The candidate defaulted to framing pricing around a '38% price increase' before advocating for selective, SKU-level increases in the recommendation.
  > Better: Rather than a blanket 38% move, I'd target 8–12% on high-margin specialty SKUs where demand is least elastic, which recovers meaningful margin while protecting volume on price-sensitive items.

### Creativity & Brainstorming — strong
- ✅ Organized the brainstorm into four explicit buckets and populated each with distinct ideas.
  > Sure — I'd group levers into four buckets.
  > Second, cost of goods. Renegotiate supplier contracts, lock in forward contracts or hedge on beans to stop the bleeding, consolidate vendors across 200 locations for scale, and reduce waste and spoilage.
- ✅ Included non-obvious ideas beyond simple price hikes and prioritized by fit to root cause.
  > targeted increases on the most inelastic items, sizing changes, and a premium tier
  > I'd sequence pricing and procurement first — they're the fastest and match the root cause.
- 💡 The brainstorm covered pricing, COGS, mix, and overhead but did not surface a lower-cost 'commodity blend' offering for budget-conscious locations.
  > Better: One more idea: pilot a lower-cost commodity blend at budget-conscious locations, so we protect volume among price-sensitive customers while raising prices on premium SKUs elsewhere.

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a clear recommendation and paired levers.
  > My recommendation: Brew & Bean should raise menu prices, and pair that with a procurement program to stabilize input costs.
- ✅ Supported the recommendation with the reconciled root cause, then named risks and concrete next steps concisely.
  > When I run those increases through the old cost base, I land exactly on today's 58%. So this is entirely unpassed-through inflation, not waste, mix, or operational failure.
  > Next steps: run a price test in 10–20 stores, and get the supplier contract terms to size negotiating room.
- ⚠️ The procurement recommendation leaned toward beans/hedging when the math showed beans are only ~a quarter of the increase; a sharper synthesis would have stressed renegotiating dairy and packaging, which carry the larger share.
  > Supporting moves: forward-contract or hedge beans, consolidate vendors across 200 stores for scale, and nudge mix toward lower-input-cost drinks.
- 💡 In the final recommendation the candidate framed the price move as '38% ... in one step' and only then caveated phasing, rather than leading with a selective, targeted increase as the primary lever.
  > Better: I'd recommend a selective 8–12% increase on inelastic specialty items now, not a 38% blanket move, and target the bigger procurement savings at dairy and packaging since beans are only about a quarter of the cost rise.

### Communication & Delivery — strong
- ✅ Consistently top-down and signposted, stating conclusions before detail throughout.
  > COGS is clearly the driver.
  > That closes it. Other inputs were 75% of the old 42%, so 31.5% of revenue.
- ✅ Used hypothesis-driven phrasing and narrated structure before diving into buckets.
  > Two broad explanations. One, input costs per unit are rising... Two, our own volume or mix changed in a way that raises cost per dollar of revenue
  > Sure — I'd group levers into four buckets.
- ✅ Handled the connectivity disruption with composure and re-oriented cleanly.
  > sorry, did you hear any of that? my wifi dropped.
  > I don't think I caught the actual bean price figure before I dropped — could you give me that number again?

### Pushback, Composure & Case Leadership — strong
- ✅ Answered the 'where did the intermediate figure come from' challenge precisely, sourcing it to the exhibit and explaining why it mattered.
  > From the exhibit you showed me — the middle row, 'Last year,' lists COGS at 50%. So it's 42 two years ago, 50 last year, 58 current. I wasn't inferring it, it's in the data.
  > The reason I flagged the trajectory is that it changes what I'd look for.
- ✅ Took the interviewer's redirect on the bean driver as a cue and delivered a crisp price-vs-volume answer, then incorporated the feedback reflectively at the end.
  > On your question: it has to be price per pound, not volume.
  > I appreciate you pushing me on the bean driver, that was the right place to slow down.
- ✅ Drove the case forward proactively at nearly every turn by requesting the specific next data point.
  > Do we have how dairy, food, and packaging moved, and whether product mix shifted — say toward milk-heavy or food items?

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a moment, then walk me through how you'd approach this.

**Candidate · 1:30** (turn 1)

Thanks — let me make sure I have the objective right: revenue is up 15% over two years, but net margin fell from 24% to 6%, so profit dollars are down substantially despite growth. We want the root cause and a fix.

Since revenue is growing, my instinct is this is cost-driven, but I don't want to assume. So I'd structure it as profit = revenue minus costs.

On revenue, I'd look at price versus volume, and mix — are we selling more low-margin items, or discounting to drive that 15%? Also new store openings versus same-store growth, since new stores can dilute margin while they ramp.

On costs, I'd split fixed versus variable: COGS (coffee beans, milk, cups), labor, rent and occupancy, and corporate overhead. I'd size each line as a percent of revenue two years ago versus today to see which one moved.

Do we have a cost breakdown by line item for both periods?

**Interviewer · 1:32** (turn 2)

You've laid out revenue and cost branches. Which branch do you prioritize first, and why?

**Candidate · 3:02** (turn 3)

I'd prioritize the cost branch first. The reason is that revenue grew 15% while margin collapsed by 18 points — if this were purely a revenue problem, I'd expect revenue to be flat or declining. A drop that steep with growing top line points to costs rising faster than sales.

There's one revenue-side scenario I want to rule out quickly, though: if that 15% growth came entirely from discounting or a shift into low-margin products, revenue could be up while gross margin per unit falls. So I'd check price and mix as a quick screen, but I'd spend the bulk of my time decomposing costs.

Specifically, I'd take each major cost line — COGS, labor, occupancy, overhead — as a percent of revenue in year zero versus today, and find which line expanded the most. That tells me where to dig rather than guessing.

Do we have that cost-as-percent-of-revenue comparison?

**Interviewer · 3:06** (turn 4)

Here's the cost structure over time. COGS is 58% of revenue today, up from 42% two years ago. Labor is 22% of revenue, and it’s been stable. Overhead is 14% of revenue, up slightly from 12%.

**Candidate · 4:37** (turn 5)

COGS is clearly the driver. It went from 42% to 58% of revenue, a 16-point increase, and overhead only added 2 points. 16 of the 18 points of margin loss sit in COGS, so that's where I'd focus — overhead is a rounding error by comparison.

And it's been steady, not a one-time shock: 42, then 50, then 58, so roughly 8 points a year. That pattern suggests something structural rather than a single bad contract.

Two broad explanations. One, input costs per unit are rising — green coffee, dairy, packaging — and we haven't passed that through in menu prices. Two, our own volume or mix changed in a way that raises cost per dollar of revenue: more milk-heavy drinks, more food items, or higher waste and spoilage.

Do we have a breakdown of what's inside COGS — coffee beans versus dairy versus food versus packaging — and how each moved?

**Interviewer · 4:39** (turn 6)

You cited a trajectory of 42, 50, 58. Where did the intermediate figure come from?

**Candidate · 6:09** (turn 7)

From the exhibit you showed me — the middle row, "Last year," lists COGS at 50%. So it's 42 two years ago, 50 last year, 58 current. I wasn't inferring it, it's in the data.

The reason I flagged the trajectory is that it changes what I'd look for. A jump from 42 straight to 58 in one year would point to a single event — a supplier contract renegotiation, a tariff, losing a volume discount. But roughly 8 points per year, two years running, looks more like sustained input cost inflation we haven't priced against, or a gradual mix shift toward lower-margin items.

That also means the fix probably isn't a one-time renegotiation either — it's likely pricing, mix management, or procurement structure.

So back to my question: do we have the composition of COGS by category, and whether menu prices have moved at all over these two years?

**Interviewer · 6:12** (turn 8)

I have the COGS composition and the menu price change. Here's the bean share of COGS first, then the menu price change. Coffee beans were 25% of COGS two years ago. Menu prices have not changed in two years.

**Candidate · 7:43** (turn 9)

That's a big finding: menu prices flat for two years while input costs climbed. If we held prices while COGS rose 16 points, we essentially absorbed all of the inflation ourselves.

Let me size the bean piece. Two years ago COGS was 42% of revenue and beans were 25% of that, so beans were about 0.25 times 42, which is 10.5% of revenue. Today COGS is 58% of revenue — if I knew the current bean share I could compare directly. Do we have the current composition?

Assuming beans held at 25%, that'd be 0.25 times 58, about 14.5% of revenue, so beans explain roughly 4 of the 16 points. That would leave 12 points in dairy, food, and packaging, which would be the bigger story. But if beans jumped to, say, 40% of COGS, that's 23% of revenue and beans alone explain most of

**Interviewer · 7:46** (turn 10)

Let me stop you there. You've assumed the current bean share to size that. Before we go further, what's actually driving the bean line — is it price per pound, or volume? Here's the bean price change.

**Interviewer · 8:46** (turn 11)

Still with me? Take your time. The question on the table: before we go further, what's actually driving the bean line — is it price per pound, or volume?

**Candidate · 12:35** (turn 12)

sorry, did you hear any of that? my wifi dropped. I was saying — if beans jumped to around 40% of COGS, that's about 23% of revenue and beans alone would explain most of the 16-point swing.

On your question: it has to be price per pound, not volume. Volume would show up in revenue too — if we sold more cups, revenue rises alongside bean spend and the COGS ratio stays roughly flat. The ratio only blows out if cost per pound rises while our menu price is frozen. So it's a margin-per-cup compression story, not a sell-more story.

I don't think I caught the actual bean price figure before I dropped — could you give me that number again?

**Interviewer · 12:36** (turn 13)

No problem. Here's the bean price change over two years. Raw coffee bean costs are up 40% over the past two years.

**Candidate · 14:07** (turn 14)

Good — so let me size it. Beans were 10.5% of revenue two years ago (25% of 42%). Price per pound up 40%, menu prices flat, so the same cup now costs 1.4 times as much in beans: 10.5 times 1.4 is about 14.7% of revenue. That's roughly a 4-point increase.

But COGS rose 16 points. So beans explain about a quarter of the problem — call it 4 of 16. The other 12 points are sitting somewhere else in COGS: dairy, food, packaging, or waste and spoilage.

That reframes things. Bean inflation is real and we've eaten all of it by not raising prices, but it's not the whole story. I'd want the other COGS components before I land on a root cause.

Do we have how dairy, food, and packaging moved, and whether product mix shifted — say toward milk-heavy or food items?

**Interviewer · 14:09** (turn 15)

Here's the other input cost changes. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 15:39** (turn 16)

That closes it. Other inputs were 75% of the old 42%, so 31.5% of revenue. Up 37.5%: 31.5 times 1.375 is about 43.3% of revenue. Add the 14.7% for beans and I get 58% — which matches the current COGS line exactly.

So the story is fully explained by input cost inflation with no price pass-through. There's no hidden mix shift or waste problem; every point of the 16 is commodity inflation we absorbed because menu prices haven't moved in two years.

Roughly, blended input inflation is about 38% across the basket. To restore the old 42% COGS ratio, we'd need revenue per unit up by about the same 38%, which is a steep single move. But we don't need to go all the way back to 24% margin to make this a good business.

Should I work out what price increase gets us to a target margin?

**Interviewer · 15:42** (turn 17)

Hold that. Beyond a price increase, what other levers could the client pull to reverse this? Give me a structured set.

**Candidate · 17:13** (turn 18)

Sure — I'd group levers into four buckets.

First, pricing. Beyond a blanket increase: targeted increases on the most inelastic items, sizing changes, and a premium tier. Specialty coffee tends to have loyal, less price-sensitive customers, which makes this the most direct lever.

Second, cost of goods. Renegotiate supplier contracts, lock in forward contracts or hedge on beans to stop the bleeding, consolidate vendors across 200 locations for scale, and reduce waste and spoilage. Also value-engineer the inputs — cup and packaging specs, dairy sourcing.

Third, mix. Push customers toward higher-margin items — black coffee is less dairy-intensive than a latte, and food or merchandise may carry different margins. Bundling can raise ticket size without a visible price hike.

Fourth, the cost lines we set aside. Overhead crept from 12 to 14 points; that's 2 points of margin and worth a look, even if it's secondary.

I'd sequence pricing and procurement first — they're the fastest and match the root cause.

**Interviewer · 17:15** (turn 19)

Now bring it together. What's your recommendation to the CEO?

**Candidate · 18:46** (turn 20)

My recommendation: Brew & Bean should raise menu prices, and pair that with a procurement program to stabilize input costs.

The root cause is clear. COGS went from 42% to 58% of revenue, which is 16 of the 18 points of margin lost. Beans are up 40% and other inputs up 37.5% — blended, about 38% input inflation — while menu prices have not moved in two years. When I run those increases through the old cost base, I land exactly on today's 58%. So this is entirely unpassed-through inflation, not waste, mix, or operational failure.

Supporting moves: forward-contract or hedge beans, consolidate vendors across 200 stores for scale, and nudge mix toward lower-input-cost drinks.

Risks: a 38% price increase in one step would likely cost volume, so I'd phase it and test elasticity in a few markets first. There's also competitive risk if peers haven't raised prices.

Next steps: run a price test in 10–20 stores, and get the supplier contract terms to size negotiating room.

**Interviewer · 18:48** (turn 21)

That's a clear place to land.

**Candidate · 20:19** (turn 22)

Thank you — I appreciate you pushing me on the bean driver, that was the right place to slow down. And apologies again for the connection drop mid-analysis.

If I had more time, the two things I'd want to pressure-test are elasticity — what volume we actually lose at a 10% versus 20% price increase, since that determines whether we phase it over two years or move faster — and whether the 2-point overhead creep is fixed cost from new store openings or something more discretionary.

One thing I'd flag on my own reasoning: I got comfortable quickly once the numbers reconciled to 58%. That reconciliation confirms input inflation explains the ratio, but it assumed a constant bean share of COGS, so a mix shift could still be hiding inside it. I'd want the current composition to fully close that out.

Thanks for the case — happy to take any feedback.

**Interviewer · 20:21** (turn 23)

That's a good note to end on, and time is up. Thanks for working through this — you'll get a full written report with detailed feedback. Take care.
