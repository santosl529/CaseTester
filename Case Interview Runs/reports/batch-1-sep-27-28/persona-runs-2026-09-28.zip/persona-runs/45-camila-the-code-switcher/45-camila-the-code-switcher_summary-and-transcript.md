# Live run — Brew & Bean Profitability

- Session: `9d37db69-19fe-4252-9511-85d909672eaa` · case `prof-001` · status **completed** · 2026-09-28
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **45. Camila — the Code-Switcher**
- Tests: Rule 6 quantity normalization against non-English number words, the Rule 13 progress detector against non-English turns, and whether the Communication dimension penalizes code-switching rather than treating it as neutral.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `non_bean_input_change`, `menu_price_change`, `stores_count`
- Force-released before the recommendation ask: none
- Scoring QA: `{"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"dataRequestGaps":0,"reconcileMerges":1,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":0,"dataRequestsNotInCase":4}`
- Assists / interventions: load_shed@23

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 5 | release | cogs_pct, labor_pct, overhead_pct | Cost breakdown as a percent of revenue (COGS, store labor, occupancy, corporate overhead, interest, depreciation) comparing two years ago versus today | yes |
| 5 | none | bean_share_of_cogs, non_bean_input_change | COGS broken down by component: coffee beans, dairy, food, and packaging | no |
| 5 | none | menu_price_change | Menu price history over two years | no |
| 7 | none | bean_share_of_cogs, non_bean_input_change | COGS breakdown by input category (beans, dairy, food, packaging) | no |
| 7 | none | menu_price_change | Menu price history over time | no |
| 13 | release | stores_count | Store count over the two-year period | yes |
| 13 | none | — | Transactions per store over the two-year period | no |
| 17 | none | — | Clarification on whether the exhibit columns are absolute dollars or percentages of revenue | no |
| 19 | none | — | elasticity data / price sensitivity / volume impact from price increases | no |
| 21 | release | cogs_pct | COGS as a percentage of revenue | yes |
| 21 | release | non_bean_input_change | Dairy and packaging cost increases over time | yes |
| 21 | release | overhead_pct | Overhead as a percentage of revenue and trend over time | yes |
| 21 | release | labor_pct | Labor as a percentage of revenue | yes |
| 21 | release | — | Volume growth | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 12 | 100862 | 695 | $0.522 |
| data_request | 12 | 10681 | 828 | $0.015 |
| coverage | 11 | 23121 | 1976 | $0.033 |
| judge | 1 | 11925 | 4222 | $0.165 |
| verifier | 1 | 5848 | 967 | $0.053 |
| reconcile | 1 | 2532 | 844 | $0.034 |
| candidate simulator (claude-opus-5) | 12 | 35748 | 4928 | $0.302 |

- App cost (interviewer + scoring): **$0.82** · with simulator: **$1.12** · list prices, uncached
- Wall time: 19:58

## Feedback

**Top improvement:** Weight the supply-side diagnosis and recommendation to match the data: non-bean inputs (up 37.5%) are the larger share of the COGS increase, so lead procurement on dairy and packaging alongside bean hedging rather than framing the cost fix primarily as a coffee-bean story.

### Problem Structuring — strong
- ✅ Restated the objective and immediately hypothesized the cost side before building the tree, then disaggregated into tailored buckets.
  > so the problem is almost certainly on the cost side, not demand
  > first, break revenue into price and volume to confirm growth is healthy, not discounting; second, break costs into COGS, labor, occupancy, and corporate overhead, and find which line expanded
- ✅ Proactively self-corrected MECE gaps and improved the structure when challenged, adding below-the-line, mix, and cleaning up overlap.
  > my store-economics point overlaps with costs, so it's not clean
  > revenue quality, cost structure, mix, below-the-line — and then external factors like commodity prices or wage inflation sitting underneath the cost branch
- ✅ Stated explicit prioritization tied to where the answer likely lives.
  > I'd start with the cost structure, because the math already tells me costs grew about 42% against 15% revenue growth — that gap is the whole story, so I want to know which line it sits in before I spend time elsewhere
- 💡 In turn 1 the candidate laid out the framework but did not yet surface competitive context or pricing power as an explicit branch (it only emerged later organically).
  > Better: I'd also want to check competitive context early — are peers seeing the same margin compression, and does the client have pricing power relative to competitors — since that shapes whether the fix is pricing or pure cost.

### Quantitative & Analytical Rigor — strong
- ✅ Correctly derived margin decline and tied each cost line to the 18-point drop, verifying columns sum to 100.
  > let me verify: 42 + 22 + 12 + 24 = 100. Y ahora, 58 + 22 + 14 + 6 = 100. Good, it ties
  > COGS rose 58 − 42 = 16 points. Overhead rose 14 − 12 = 2 points. Labor, cero
- ✅ Executed a clean nested-percentage bean decomposition in absolute dollars, avoiding the classic units trap and using a sanity check to guard against error.
  > Now: revenue is 115, and COGS is 58% of that — cincuenta y ocho por ciento de ciento quince = 66.7
  > If I'd used 58 flat, the bean number would come out negative, which is how I'd catch the error
- ✅ Laid out the pricing math with explicit setup and stated the business implication, correctly noting variable costs don't scale with price.
  > costs don't move, because COGS and labor scale with cups served, not with price
  > Profit = 126.5 − 108.1 = 18.4. Margen = 18.4 / 126.5 = 14.5%

### Data & Exhibit Interpretation — strong
- ✅ Oriented on the exhibit units first, then isolated COGS as the driver and characterized the pattern (linear, not one-time).
  > Okay, let me read this as percent of revenue
  > it's a steady, linear march — eight points a year, not a one-time shock. That pattern points to either a sustained input cost increase or a structural mix shift
- ✅ Extracted a non-obvious insight from flat labor and proposed concrete next data requests with a 'so-what'.
  > Labor contributed nothing, which is actually striking given US wage inflation — suggests they either cut hours or automated
  > Two things I need: the COGS breakdown — beans, dairy, food, packaging — and menu price history
- ✅ Correctly decomposed the COGS breakdown to show beans more than doubled and grew as a share of COGS.
  > So beans today = 66.7 − 43.3 = 23.4. Versus 10.5 before. Eso es un aumento de ciento veintitrés por ciento — beans more than doubled, and they've gone from 25% of COGS to about 35%

### Business Judgment & Insight — strong
- ✅ Recognized pricing power from healthy same-store traffic and warned against cutting the lean labor line that supports service quality.
  > Same-store revenue up 15% on flat prices means traffic is growing — demand is healthy and customers are not price-sensitive enough to walk away. So they have pricing power they simply haven't used
  > they're already running efficiently; I'd be careful cutting there, since service quality is what supports pricing power
- ✅ Sized the naive full-recovery price increase, judged it infeasible, and pivoted to a realistic phased option.
  > That's a 24% price increase — demasiado, would hit traffic
  > The real caveat is my flat-volume assumption. At 10%, some traffic walks
- ✅ The candidate correctly flagged that beans do not explain the full picture and pointed to broader procurement, but still leaned too heavily on the bean-spike narrative — a sharper diagnosis would weight the non-bean inputs (up 37.5%), which drive the larger share of the COGS increase.
  > Renegotiate dairy and packaging, where they're paying 37.5% more with 200 stores of buying power they may not be using
  > hedging locks you in if beans fall
  > Green coffee did spike globally. So this is partly market, partly a pricing failure
- 💡 After decomposing beans vs. other inputs, the candidate emphasized beans doubling but did not explicitly quantify that the other inputs (dairy/packaging/food) account for the larger dollar share of the COGS increase.
  > Better: Note that beans rose from 10.5 to 23.4 — about 13 points — but other inputs rose from 31.5 to 43.3, nearly 12 points, so this is not primarily a coffee story; procurement has to hit dairy and packaging, not just hedge beans.

### Creativity & Brainstorming — strong
- ✅ Organized the brainstorm into buckets ordered by impact and produced diverse, relevant levers across COGS, revenue mix, and overhead.
  > Three buckets, ordered by where the money is
  > Procurement: lock in forward contracts or hedge green coffee rather than buying spot... Diversify origins if they're concentrated in one region... And reduce waste — spoilage and over-pouring sit in that line
- ✅ Included non-obvious ideas like mix shift to reduce reliance on price and loyalty subscriptions.
  > Push high-margin items: brewed coffee over dairy-heavy drinks, food attach, loyalty subscriptions. Entonces, si el margen por bebida sube, no necesito tanto precio
- 💡 The brainstorm did not surface the model's 'commodity blend' pilot idea for budget-conscious locations as a way to protect volume while managing input cost.
  > Better: One more revenue-protecting lever: pilot a lower-cost commodity blend at budget-sensitive locations so we can take price on specialty SKUs without alienating price-conscious traffic.

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a specific recommendation, supported by evidence tied to the analysis, then named risks and next steps concisely.
  > My recommendation: raise menu prices around 10% and hedge green coffee — that combination recovers most of the margin, and the case for it is that this is a cost problem, not a demand problem
  > Next steps: price elasticity test in two or three markets, a bean sourcing and hedging review, and an overhead audit on those two creeping points
- ✅ Quantified the impact of the primary lever and layered secondary levers to close the gap.
  > A 10% increase takes margin from 6% to roughly 14.5%; procurement savings and mix shift toward brewed coffee close more of the gap
- ⚠️ The recommendation framed procurement mainly as 'hedge green coffee' when the data shows non-bean inputs are the larger driver, so the supply-side fix is somewhat under-scoped relative to the evidence.
  > raise menu prices around 10% and hedge green coffee
  > within that, beans more than doubled — de 10.5 a 23.4 en dólares, from 25% to 35% of COGS
- 💡 In the final recommendation the candidate led with hedging beans but did not equally elevate renegotiating dairy and packaging, which the 37.5% figure shows is the bigger cost bucket.
  > Better: Pair the price increase with a full procurement push — multi-year bean contracts plus renegotiated dairy and packaging, since non-bean inputs are up 37.5% and explain the larger share of the COGS increase.

### Communication & Delivery — strong
- ✅ Consistently top-down and signposted, stating structure before detail and using hypothesis language.
  > So I'd structure it as: first... second... third...
  > Three buckets, ordered by where the money is
- ✅ Narrated math steps clearly and flagged caveats in real time, keeping the interviewer able to follow.
  > One caveat I should flag: this is all in percentage-of-revenue terms
  > But let me caveat that, because I stated it too cleanly

### Pushback, Composure & Case Leadership — strong
- ✅ Held position under the '6 vs 6.9' challenge with explicit unit reasoning rather than caving, while offering to redo if the exhibit was misread.
  > Let me check myself, but I think 6.9 is right — the exhibit is in percent of revenue, not dollars
  > Have I misread the exhibit? If those columns are absolute dollars rather than percentages, I'd want to redo it
- ✅ Responded to the MECE challenge by specifically identifying gaps and improving the structure without defensiveness.
  > Fair push. A couple of gaps
  > my store-economics point overlaps with costs, so it's not clean
- ✅ Handled the 'walk me through 89%' and 'pure volume' probes with crisp derivations and appropriate caveats.
  > let me verify: 42 + 22 + 12 + 24 = 100
  > let me caveat that, because I stated it too cleanly. 'Volume' here is bundled

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

How would you like to approach this? Feel free to take a moment to gather your thoughts first.

**Candidate · 1:42** (turn 1)

Okay, let me make sure I have the picture. Revenue is up 15% over two years, but net margin fell from 24% to 6% — so the problem is almost certainly on the cost side, not demand. And since margin is a percentage, costs must be growing faster than revenue.

Quick sanity check, entonces: if revenue was 100 before, profit was 24. Now revenue is 115 and profit is 115 × 0.06 = 6.9. So absolute profit dropped from 24 to about 6.9 — that's a 70%-plus decline. Costs went from 76 to about 108, so costs grew roughly 42% while revenue grew 15%.

So I'd structure it as: first, break revenue into price and volume to confirm growth is healthy, not discounting; second, break costs into COGS, labor, occupancy, and corporate overhead, and find which line expanded; third, check whether it's per-store economics or new-store drag.

Does that sound reasonable? And apologies — I sometimes think through numbers in Spanish, hope that's alright.

**Interviewer · 1:45** (turn 2)

That works, and think through it however you like.

Your framework has revenue, costs, and store economics. Is that MECE — what's missing?

**Candidate · 3:15** (turn 3)

Fair push. A couple of gaps.

First, I anchored on net margin but only built an operating tree. Net profit includes below-the-line items — interest expense, depreciation from any build-out or remodels, taxes. If they levered up to fund growth, entonces los intereses could explain a chunk of that decline without any operating problem at all.

Second, mix. I said price and volume, but I left out product and channel mix — a shift from high-margin brewed coffee toward low-margin food, or toward delivery apps that take a 20–30% cut, would show revenue growing while margin collapses.

Third, my store-economics point overlaps with costs, so it's not clean. I'd rather say: same-store P&L versus new-store P&L, as a lens on the cost lines rather than a separate branch.

So: revenue quality, cost structure, mix, below-the-line — and then external factors like commodity prices or wage inflation sitting underneath the cost branch.

Where would you like me to dig first?

**Interviewer · 3:16** (turn 4)

Understood. Where would you start, and why?

**Candidate · 4:47** (turn 5)

I'd start with the cost structure, because the math already tells me costs grew about 42% against 15% revenue growth — that gap is the whole story, so I want to know which line it sits in before I spend time elsewhere.

Specifically, I'd ask for the cost breakdown as a percent of revenue, two years ago versus today: COGS, store labor, occupancy, corporate overhead, and then below-the-line interest and depreciation. That single table probably isolates the driver in one step.

Do we have that split? And if we have it, I'd love the biggest line broken down one level further — if it's COGS, I'd want coffee beans versus dairy versus food versus packaging, since green coffee is a traded commodity and could have moved independently.

One more thing I'd want eventually: menu price history. Si no subieron los precios en dos años, entonces cualquier inflación de insumos pega directo al margen. But let's start with the cost table.

**Interviewer · 4:50** (turn 6)

I have a cost structure exhibit. Here it is.

**Candidate · 6:21** (turn 7)

Okay, let me read this as percent of revenue.

COGS: cuarenta y dos, luego cincuenta, ahora cincuenta y ocho. So +8 points, then +8 more — sixteen points total. Labor is flat at 22 across all three years. Overhead goes 12, 13, 14 — solo dos puntos.

Entonces, de los dieciocho puntos de margen perdido, dieciséis vienen de COGS y dos de overhead. COGS is roughly 89% of the decline. Labor contributed nothing, which is actually striking given US wage inflation — suggests they either cut hours or automated, or they're holding headcount flat while volume grows.

So the whole case is COGS, and it's a steady, linear march — eight points a year, not a one-time shock. That pattern points to either a sustained input cost increase or a structural mix shift, not a single bad contract.

Two things I need: the COGS breakdown — beans, dairy, food, packaging — and menu price history. Si no han subido precios, el 58% podría ser solo denominador.

Do we have either?

**Interviewer · 6:22** (turn 8)

Let me check one thing. You said COGS is 89% of the decline — walk me through that.

**Candidate · 7:52** (turn 9)

Sure. Profit as a percent of revenue went from 24 to 6, entonces la caída es de dieciocho puntos porcentuales.

Now where did those eighteen points go? Costs have to absorb them, since the three lines plus profit sum to 100 in every column — let me verify: 42 + 22 + 12 + 24 = 100. Y ahora, 58 + 22 + 14 + 6 = 100. Good, it ties.

So COGS rose 58 − 42 = 16 points. Overhead rose 14 − 12 = 2 points. Labor, cero. Sixteen plus two is eighteen, which matches the profit decline exactly.

Entonces dieciséis sobre dieciocho = 0.888..., so 89%. That's the share of the margin loss attributable to COGS.

One caveat I should flag: this is all in percentage-of-revenue terms. In absolute dollars COGS grew even more, because revenue itself grew 15%. But for explaining the margin decline, points of revenue is the right unit.

**Interviewer · 7:55** (turn 10)

That holds. Here's the COGS breakdown and the menu price history. Coffee beans were 25% of COGS two years ago. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years. Menu prices have not changed in two years.

**Candidate · 9:26** (turn 11)

Let me work in absolute dollars with revenue = 100 at the start.

Two years ago: COGS 42. Beans are 25% of that, entonces 10.5. Everything else is 31.5.

Now: revenue is 115, and COGS is 58% of that — cincuenta y ocho por ciento de ciento quince = 66.7.

Other inputs up 37.5%: 31.5 × 1.375 = 43.3.

So beans today = 66.7 − 43.3 = 23.4. Versus 10.5 before. Eso es un aumento de ciento veintitrés por ciento — beans more than doubled, and they've gone from 25% of COGS to about 35%.

And prices haven't moved in two years. So they absorbed a commodity spike entirely on the P&L. Note that 15% revenue growth is pure volume — which actually made it worse, since every incremental cup carries the inflated input cost.

Green coffee did spike globally. So this is partly market, partly a pricing failure.

**Interviewer · 9:27** (turn 12)

Let me pause you on one. You said fifteen percent revenue growth is pure volume — walk me through that.

**Candidate · 10:58** (turn 13)

Because menu prices are flat, revenue per unit is unchanged, entonces cualquier crecimiento tiene que venir de unidades vendidas. Revenue = price × volume; si el precio no se mueve, el quince por ciento es volumen.

But let me caveat that, because I stated it too cleanly. "Volume" here is bundled — it could be more transactions per store, or more stores. With 200 locations, if they opened units over two years, part of that 15% is footprint, not same-store traffic. Those have very different implications: new stores carry build-out and depreciation, and might explain the two points of overhead creep.

Second caveat: mix. Even with flat menu prices, average ticket can rise if customers shift toward pricier drinks or food. So revenue could grow without unit volume growing.

Do we have store count over the two years, and transactions per store? That would let me separate same-store volume from expansion.

**Interviewer · 10:59** (turn 14)

Here's what I have on both. 200 stores today — and it was 200 stores two years ago, so the footprint hasn’t changed.

**Candidate · 12:30** (turn 15)

That's clean, then — flat footprint, so the 15% is entirely same-store. Entonces, sin tiendas nuevas, no hay drag de build-out ni depreciación de expansión, and the two points of overhead creep need a different explanation — corporate salaries, maybe marketing.

It also strengthens the pricing argument considerably. Same-store revenue up 15% on flat prices means traffic is growing — demand is healthy and customers are not price-sensitive enough to walk away. So they have pricing power they simply haven't used.

Let me size it. Today: revenue 115, profit 6.9. To get back to a 24% margin, si los costos se quedan igual, costs are 108.1, entonces necesito ingresos de 108.1 / 0.76 = 142.2. That's a 24% price increase — demasiado, would hit traffic.

More realistic: a 10% price increase on flat volume adds 11.5 to revenue and drops nearly all of it to profit, taking us from 6.9 to about 18.4 — roughly 15% margin. Half the gap from price alone.

Should I build out the rest of the recommendation?

**Interviewer · 12:32** (turn 16)

You put profit at 6.9, but the case gave us margin — that's 6, not 6.9. Now walk me through that pricing math again.

**Candidate · 14:02** (turn 17)

Let me check myself, but I think 6.9 is right — the exhibit is in percent of revenue, not dollars.

Each column sums to 100: 58 + 22 + 14 + 6. That's percent of *that year's* revenue. Entonces el seis es seis por ciento, no seis dólares.

And if I set revenue two years ago at 100, today's revenue is 115. Seis por ciento de ciento quince = 6.9. That's in the same units as the original 24, so the comparison holds: profit fell from 24 to 6.9, about a 71% drop.

The 6 would only be the dollar figure if revenue had stayed at 100 — but we're told it grew 15%.

Same logic ran through my COGS math: 58% of 115 = 66.7. If I'd used 58 flat, the bean number would come out negative, which is how I'd catch the error.

Have I misread the exhibit? If those columns are absolute dollars rather than percentages, I'd want to redo it.

**Interviewer · 14:05** (turn 18)

Understood. Now the pricing math — walk me through it once more.

**Candidate · 15:35** (turn 19)

Sure. Current state, revenue = 115.

Costs in dollars: COGS es cincuenta y ocho por ciento de ciento quince = 66.7. Labor, veintidós por ciento = 25.3. Overhead, catorce por ciento = 16.1. Total = 108.1. Profit = 115 − 108.1 = 6.9. Ties to the 6% margin.

Now a 10% price increase, holding volume flat. Revenue = 115 × 1.10 = 126.5. Key point: costs don't move, because COGS and labor scale with cups served, not with price — the same units cost the same to make. So costs stay 108.1.

Profit = 126.5 − 108.1 = 18.4. Margen = 18.4 / 126.5 = 14.5%.

For the full 24%: 0.76R = 108.1, entonces R = 142.2, a 23.7% increase. Too aggressive alone.

The real caveat is my flat-volume assumption. At 10%, some traffic walks. If elasticity costs us 5% of volume, COGS drops proportionally too, so it partially self-corrects — I'd want elasticity data before committing.

**Interviewer · 15:37** (turn 20)

Beyond price, what else could the client do to reverse the margin decline? Give me a structured set of levers.

**Candidate · 17:07** (turn 21)

Three buckets, ordered by where the money is.

First, COGS, since that's 89% of the problem. Procurement: lock in forward contracts or hedge green coffee rather than buying spot — they clearly ate the spike unhedged. Diversify origins if they're concentrated in one region. Renegotiate dairy and packaging, where they're paying 37.5% more with 200 stores of buying power they may not be using. And reduce waste — spoilage and over-pouring sit in that line.

Second, mix and revenue quality. Push high-margin items: brewed coffee over dairy-heavy drinks, food attach, loyalty subscriptions. Entonces, si el margen por bebida sube, no necesito tanto precio.

Third, the smaller lines. Overhead crept two points on a flat footprint — that's worth auditing. Labor held flat at 22% while volume grew 15%, so they're already running efficiently; I'd be careful cutting there, since service quality is what supports pricing power.

I'd sequence price and procurement first — fastest, biggest.

**Interviewer · 17:10** (turn 22)

What's your recommendation to the CEO?

**Candidate · 18:41** (turn 23)

My recommendation: raise menu prices around 10% and hedge green coffee — that combination recovers most of the margin, and the case for it is that this is a cost problem, not a demand problem.

Supporting points. Sixteen of the eighteen points of margin loss are COGS, and within that, beans more than doubled — de 10.5 a 23.4 en dólares, from 25% to 35% of COGS. Meanwhile prices haven't moved in two years while same-store revenue grew 15% on a flat 200-store footprint. That's real pricing power they haven't used. A 10% increase takes margin from 6% to roughly 14.5%; procurement savings and mix shift toward brewed coffee close more of the gap.

Risks: elasticity is unknown, so I'd phase the increase and test by market; competitors may not follow; hedging locks you in if beans fall.

Next steps: price elasticity test in two or three markets, a bean sourcing and hedging review, and an overhead audit on those two creeping points.

**Interviewer · 18:43** (turn 24)

That's a complete case. We'll stop there — thank you for working through it.

You'll get a full written report with detailed feedback; I won't debrief live. Thanks again for your time.
