# Live run — Brew & Bean Profitability

- Session: `bc5421ab-2e08-4dd8-bab6-331eb1bba632` · case `prof-001` · status **completed** · 2026-09-27
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **3. Ines — the Clarifier**
- Tests: Rule 13 clarifying-question budget (N=2 default): tests whether a legitimately thorough candidate trips the ladder. If she does, N is too low or the quality guard is needed after all.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `bean_price_change`, `menu_price_change`, `non_bean_input_change`, `avg_ticket`, `stores_count`
- Force-released before the recommendation ask: `[{"phase":"BRAINSTORM","itemIds":["avg_ticket","stores_count"],"trigger":"model_ask"}]`
- Scoring QA: `{"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"dataRequestGaps":1,"reconcileMerges":1,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":0,"dataRequestsNotInCase":11}`
- Assists / interventions: none

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | release | stores_count, revenue_per_store | Whether revenue growth came from new store openings or same-store sales growth at existing locations | no |
| 3 | refuse | — | Store-level or regional breakdown of the decline in margin/profitability | no |
| 5 | refuse | — | Competitor and industry segment performance data over the two-year period | no |
| 7 | release | cogs_pct, labor_pct, overhead_pct | Cost structure as a percent of revenue for both years (current and prior year) | yes |
| 9 | clarify | — | Composition of COGS: breakdown of what's inside COGS (beans, milk, cups, food) versus what's excluded (delivery commissions, packaging) | no |
| 11 | none | bean_share_of_cogs, non_bean_input_change | COGS breakdown by component (beans, dairy, packaging, food) in absolute dollars per unit over two years | no |
| 11 | release | menu_price_change | Menu price history over two years | yes |
| 13 | release | non_bean_input_change | Dairy and food cost movement over the past two years | yes |
| 13 | none | — | Revenue mix shift (toward food and elaborate milk drinks) | no |
| 15 | refuse | — | Results of any pricing tests the client has conducted | no |
| 15 | refuse | — | Price sensitivity of customers / price elasticity data | no |
| 19 | none | — | Margin by product line (black coffee vs lattes) and gross profit per transaction in dollar terms | no |
| 19 | none | — | Current product mix — share of transactions that are espresso-based drinks | no |
| 19 | none | — | Evidence of customer switching behavior based on promotion or placement | no |
| 19 | none | avg_ticket | Effect on ticket size / average transaction value if customers shift from higher-priced to lower-priced drinks | no |
| 19 | none | — | Capacity and throughput data — serving speed for black coffee vs espresso-based drinks | no |
| 21 | none | — | Whether the CEO or leadership has ruled out price increases for brand reasons | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens |
|---|---|---|---|
| interviewer | 11 | 83907 | 737 |
| coverage | 10 | 13854 | 1090 |
| data_request | 11 | 9017 | 1031 |
| judge | 1 | 11268 | 3588 |
| verifier | 1 | 4388 | 345 |
| reconcile | 1 | 2627 | 662 |

## Feedback

**Top improvement:** Sharpen the pricing recommendation from a broad 10-12% hike to a selective increase concentrated on high-margin, low-elasticity specialty SKUs while protecting entry-level prices to defend already-soft traffic — this targets the same margin recovery with less volume risk.

### Problem Structuring — strong
- ✅ The candidate laid out a clean profit tree (Revenue − Costs), decomposed revenue into price × volume × mix and costs into fixed/variable, and prioritized where the answer likely lived.
  > Profit = Revenue minus Costs. On the revenue side, I'd break the 15% growth into price versus volume... On the cost side, I'd split fixed and variable.
  > Since revenue is growing but margin collapsed from 24% to 6%, this is almost certainly a cost problem, so I'd weight my structure there.
- ✅ The candidate tailored the structure to the specific case, flagging non-obvious buckets like delivery-app commissions and mix shift toward lower-margin items.
  > if they grew revenue purely by discounting and driving traffic, revenue can rise while gross margin falls
  > plus hourly labor that flexes with volume, and delivery-app commissions if they use them

### Quantitative & Analytical Rigor — strong
- ✅ The candidate correctly performed the nested-percentage conversion for beans, translating share-of-COGS into points of revenue before applying the price increase.
  > Beans were 25% of a COGS that was 42% of revenue, so beans ≈ 10.5% of revenue two years ago. Up 40% with no price increase to offset, that's 10.5 × 1.4 = 14.7%, so beans add about 4.2 points of margin damage.
- ✅ The candidate closed the margin bridge exactly, showing beans (4.2pts) plus other inputs (11.8pts) sum to the full 16-point COGS increase.
  > Other inputs were 75% of 42% = 31.5% of revenue. Up 37.5%: 31.5 × 1.375 = 43.3%, an increase of 11.8 points. Add the 4.2 from beans and I get 16.0 points — exactly the COGS increase.
- ✅ The candidate decomposed the 15% revenue growth against the 10% ticket rise to infer transaction count was nearly flat, but never fully verbalized the sanity check that the margin jump from 6% to 15-16% rests on that flat-volume assumption holding.
  > with revenue up 15%, transaction count is only up about 5% ($1.15 / $1.10). So traffic is nearly flat
  > Math: a 10% price increase on flat volume adds ~10 points of margin, taking 6% to roughly 15-16%.

### Data & Exhibit Interpretation — strong
- ✅ The candidate oriented on the exhibit immediately, isolated COGS as the driver, dismissed labor and overhead as minor, and stated the so-what.
  > COGS went from 42% to 58% of revenue, sixteen points, and that alone accounts for almost the entire eighteen-point margin decline. Labor is flat at 22%, overhead drifted up two points but that's minor.
  > So the question is what's inside COGS.
- ✅ The candidate tested whether the bean spike alone could explain the full COGS increase and correctly found it could not, driving the search for other inputs.
  > beans explain only about a quarter of it. There's roughly 12 points unaccounted for — that has to be dairy, packaging, and food inflating too, or a mix shift

### Business Judgment & Insight — strong
- ✅ The candidate showed strong commercial judgment on pricing, insisting on gross profit dollars per transaction rather than margin percentage when evaluating the mix lever.
  > A $6 latte at 55% COGS may throw off more gross profit dollars per unit than a $2.50 drip at 35%. I'd want gross profit per transaction, not margin percentage, since they need dollars.
- ✅ The candidate surfaced the real-world risk of leaning on price given soft traffic and proposed a pilot to mitigate elasticity uncertainty.
  > Risks: elasticity is unknown, and traffic is already soft at +5%. Hence the pilot.
  > I don't want to recommend a 15% price hike if demand falls off a cliff
- ✅ The candidate identified that revenue growth actively worsened the problem, a non-obvious insight with real strategic weight.
  > They sold 15% more units, each at collapsing margin. Growth actively made this worse.

### Creativity & Brainstorming — strong
- ✅ The candidate produced a structured, diverse set of levers spanning procurement, mix, waste, indirect pricing, and reformulation.
  > First, procurement: with 200 stores they have real scale, so I'd look at long-term supplier contracts or hedging on beans and dairy rather than buying at spot
  > Fourth, indirect pricing — shrink portion sizes slightly, or charge for what used to be free, like alternative milks.
- ✅ The candidate included non-obvious ideas like hedging exposure and throughput advantages of faster-serve products.
  > track brewed coffee dumped at close. In a business where COGS is 58% of revenue, a few points of waste is real money
  > Fourth, capacity — black coffee is faster to serve, which could raise throughput at peak.

### Synthesis & Recommendation — strong
- ✅ The candidate led answer-first with a concrete, staged recommendation supported by evidence tied to the analysis, plus risks and next steps.
  > my recommendation: raise menu prices roughly 10-12% in staged increments, starting with a pilot in a subset of stores to read elasticity.
  > Why: all 18 points of margin loss trace to input inflation — beans up 40%, other inputs up 37.5% — absorbed with zero pass-through over two years.
- ✅ The candidate paired the primary lever with procurement and waste, and named crisp next steps.
  > Support it with supplier contracts or hedging on beans and dairy, portion and waste standards, and a mix review once we have gross profit dollars by item.
  > Next steps: two-week price test in 20 stores, item-level margin data, and a procurement review.
- ⚠️ The recommendation was slightly less selective than the model answer, which favored targeted 8-12% increases on high-margin, low-elasticity specialty SKUs rather than a broad 10-12% hike.
  > raise menu prices roughly 10-12% in staged increments
- 💡 Delivering the recommendation, the candidate proposed a broad 10-12% price increase.
  > Better: I'd raise prices selectively — 8-12% concentrated on high-margin specialty drinks where brand loyalty makes demand less elastic, while holding entry-level drip prices to protect traffic, then read the pilot before rolling network-wide.

### Communication & Delivery — strong
- ✅ The candidate was consistently top-down and signposted, narrating structure before detail and numbering ideas.
  > First and most important, I'd need the actual margin by product line
  > Let me do the math. Beans were 25% of a COGS that was 42% of revenue
- ✅ The candidate used hypothesis-driven phrasing and explained the reasoning behind each data request.
  > The reason is I need to separate two very different stories: did input prices rise, or did the mix shift toward lower-margin items

### Pushback, Composure & Case Leadership — strong
- ✅ When challenged on the mix lever, the candidate responded with precise evaluative logic rather than defensiveness or capitulation.
  > I'm assuming black coffee is higher-margin because it's mostly beans and water versus a latte that's largely dairy, but dairy-heavy drinks also carry much higher menu prices... I'd want gross profit per transaction, not margin percentage
- ✅ The candidate drove the case forward, proactively requesting relevant data and proposing next steps at each turn even when data was refused.
  > Before I give a recommendation — do we know anything about how price-sensitive their customers are, or whether they've tested a price increase anywhere?
  > is the CEO constrained on price for brand reasons — has leadership already ruled a price increase off the table?

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a moment, then walk me through how you'd approach this.

**Candidate · 0:56** (turn 1)

Before I put a structure together, I'd like to make sure I understand the situation. First question: when you say revenue grew 15% over two years, do we know whether that growth came from opening new locations, or from existing stores selling more? I ask because a chain that went from, say, 160 to 200 stores has a very different profit story than one where the same 200 stores grew same-store sales.

**Interviewer · 0:58** (turn 2)

Fair question. The store count has held at 200 over the two-year period, so this is same-store growth, not new openings.

What else do you want to clarify?

**Candidate · 1:44** (turn 3)

That's helpful — so it's not an expansion drag. Second question: is this decline broad-based across the 200 locations, or is it concentrated in a subset — certain regions, certain store formats? If, say, 30 urban stores are driving most of it, that changes where we look entirely versus a cost that hits every store equally.

**Interviewer · 1:46** (turn 4)

I don't have a store-level or regional breakdown of the decline. Assume it's broadly across the network.

Ready to lay out your structure?

**Candidate · 2:33** (turn 5)

Almost — one more scoping question, if that's okay. Do we know how competitors or the specialty coffee segment overall have performed over these two years? If everyone's margins compressed by roughly this much, I'd suspect an industry-wide input cost shock like coffee beans or wages. If Brew & Bean is alone, it's something internal to how they're operating.

**Interviewer · 2:35** (turn 6)

I don't have competitor benchmark data. Focus on Brew & Bean's own economics.

Go ahead and lay out your structure.

**Candidate · 4:06** (turn 7)

Okay. Since revenue is growing but margin collapsed from 24% to 6%, this is almost certainly a cost problem, so I'd weight my structure there.

Profit = Revenue minus Costs. On the revenue side, I'd break the 15% growth into price versus volume, because if they grew revenue purely by discounting and driving traffic, revenue can rise while gross margin falls. So: price per transaction, number of transactions, and mix across drinks versus food versus retail bags.

On the cost side, I'd split fixed and variable. Fixed: rent, base labor, equipment, corporate overhead. Variable: cost of goods — beans, milk, cups — plus hourly labor that flexes with volume, and delivery-app commissions if they use them.

Then I'd compare each line as a percent of revenue in year zero versus today, and find which lines expanded. An 18-point margin swing is huge, so it should be one or two lines, not diffuse.

Can I get the cost structure as a percent of revenue for both years?

**Interviewer · 4:08** (turn 8)

Here's the cost structure over time.

**Candidate · 5:20** (turn 9)

This is clean — COGS went from 42% to 58% of revenue, sixteen points, and that alone accounts for almost the entire eighteen-point margin decline. Labor is flat at 22%, overhead drifted up two points but that's minor.

So the question is what's inside COGS. Before I dig, a scoping question: is COGS here purely product inputs — beans, milk, cups, food — or does it also include things like delivery platform commissions or packaging for to-go orders? Those sometimes get bucketed into COGS and would point somewhere very different than a commodity price story.

**Interviewer · 5:22** (turn 10)

Treat COGS as product inputs — beans, dairy, packaging, food. No platform commissions in there.

So what do you want to see inside COGS?

**Candidate · 8:26** (turn 11)

Then I'd want the split of COGS by component across the two years — beans, dairy, packaging, food — in absolute dollars per unit if possible, not just as a percent of revenue. The reason is I need to separate two very different stories: did input prices rise, or did the mix shift toward lower-margin items like food and specialty milk drinks that cost more to make?

And related — do we have menu price history? Because a 16-point COGS increase as a percent of revenue can happen with flat input costs if they simply haven't raised prices in two years while costs crept up. Revenue grew 15%, but if that's all volume and zero price, that's the whole answer right there.

**Interviewer · 8:29** (turn 12)

Let me give you what I have on those. Coffee beans were 25% of COGS two years ago. Raw coffee bean costs are up 40% over the past two years. Menu prices have not changed in two years.

**Candidate · 9:59** (turn 13)

Let me do the math. Beans were 25% of a COGS that was 42% of revenue, so beans ≈ 10.5% of revenue two years ago. Up 40% with no price increase to offset, that's 10.5 × 1.4 = 14.7%, so beans add about 4.2 points of margin damage.

But COGS rose 16 points total. So beans explain only about a quarter of it. There's roughly 12 points unaccounted for — that has to be dairy, packaging, and food inflating too, or a mix shift toward food and elaborate milk drinks that carry worse margins, or waste.

And critically, flat menu prices for two years is doing a lot of work here. Every input increase flowed straight to the bottom line with zero pass-through. The 15% revenue growth must be essentially all volume — they're selling more units at deteriorating unit economics.

Do we have the dairy and food cost movement, or the revenue mix shift?

**Interviewer · 10:01** (turn 14)

Here's the other input cost movement. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 11:32** (turn 15)

That closes the gap perfectly. Other inputs were 75% of 42% = 31.5% of revenue. Up 37.5%: 31.5 × 1.375 = 43.3%, an increase of 11.8 points. Add the 4.2 from beans and I get 16.0 points — exactly the COGS increase. So the entire margin decline is input cost inflation, broad-based across every category, absorbed with zero price pass-through.

Worth noting: because menu prices are flat, the 15% revenue growth is pure volume. They sold 15% more units, each at collapsing margin. Growth actively made this worse.

Before I give a recommendation — do we know anything about how price-sensitive their customers are, or whether they've tested a price increase anywhere? A specialty coffee chain usually has some brand pricing power, but I don't want to recommend a 15% price hike if demand falls off a cliff.

**Interviewer · 11:34** (turn 16)

I don't have price elasticity or pricing-test data.

Set the recommendation aside for a moment. Beyond raising prices, what other levers could the client pull to reverse this? Give me the full set.

**Candidate · 13:05** (turn 17)

A few beyond price. First, procurement: with 200 stores they have real scale, so I'd look at long-term supplier contracts or hedging on beans and dairy rather than buying at spot — that's how they got fully exposed to a 40% swing. Consolidating vendors across the network should also buy volume discounts.

Second, product mix: steer customers toward higher-margin items. Black coffee and espresso have better margins than elaborate dairy-heavy drinks; loyalty promotions and menu placement can shift mix without a visible price change.

Third, portion and waste control: standardize shot and milk pours, track brewed coffee dumped at close. In a business where COGS is 58% of revenue, a few points of waste is real money.

Fourth, indirect pricing — shrink portion sizes slightly, or charge for what used to be free, like alternative milks. Customers notice that less than headline price changes.

Fifth, reformulate: adjust the blend toward less expensive origins if quality holds.

Overhead drifted 12 to 14 points too — smaller, but worth a look.

**Interviewer · 13:07** (turn 18)

You listed steering mix toward black coffee and espresso. What would you need to check before betting on that lever?

**Candidate · 14:43** (turn 19)

A few things. First and most important, I'd need the actual margin by product line — I'm assuming black coffee is higher-margin because it's mostly beans and water versus a latte that's largely dairy, but dairy-heavy drinks also carry much higher menu prices. A $6 latte at 55% COGS may throw off more gross profit dollars per unit than a $2.50 drip at 35%. I'd want gross profit per transaction, not margin percentage, since they need dollars.

Second, current mix and how sticky it is — what share of transactions are already espresso-based, and is there evidence customers switch based on promotion or placement?

Third, the effect on ticket size. If I steer people from a $6 drink to a $2.50 one, revenue per transaction drops and I may just shrink the business.

Fourth, capacity — black coffee is faster to serve, which could raise throughput at peak.

**Interviewer · 14:47** (turn 20)

Now bring it together. Before we wrap, on what you asked about earlier: The average transaction is $6.80, up from $6.20 two years ago — about a 10% increase, because customers are buying more items per visit. 200 stores today — and it was 200 stores two years ago, so the footprint hasn’t changed. What's your recommendation to the CEO?

**Candidate · 21:49** (turn 21)

Quick note on that: ticket rose 10% to $6.80 but menu prices are flat, so that's customers adding items — and with revenue up 15%, transaction count is only up about 5% ($1.15 / $1.10). So traffic is nearly flat; growth came from upselling into items that are apparently dragging margin down.

One clarification before I commit: is the CEO constrained on price for brand reasons — has leadership already ruled a price increase off the table? That changes how hard I lean on it.

Assuming not, my recommendation: raise menu prices roughly 10-12% in staged increments, starting with a pilot in a subset of stores to read elasticity.

Why: all 18 points of margin loss trace to input inflation — beans up 40%, other inputs up 37.5% — absorbed with zero pass-through over two years. Nothing else moved; labor is flat.

Math: a 10% price increase on flat volume adds ~10 points of margin, taking 6% to roughly 15-16%.

Support it with supplier contracts or hedging on beans and dairy, portion and waste standards, and a mix review once we have gross profit dollars by item.

Risks: elasticity is unknown, and traffic is already soft at +5%. Hence the pilot.

Next steps: two-week price test in 20 stores, item-level margin data, and a procurement review.

**Interviewer · 21:55** (turn 22)

That's where we'll have to stop — we're out of time. Thank you for working through this; you'll receive a full written report with detailed feedback. I appreciate the discussion.
