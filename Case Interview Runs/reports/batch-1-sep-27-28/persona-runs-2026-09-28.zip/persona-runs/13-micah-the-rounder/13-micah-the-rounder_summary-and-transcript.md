# Live run — Brew & Bean Profitability

- Session: `574aaf8a-c369-4b7b-9dfd-56cbb24bf959` · case `prof-001` · status **completed** · 2026-09-27
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **13. Micah — the Rounder**
- Tests: Rule 14 within-tolerance band as a false-positive test: estimation is a scored skill and must be accepted silently. If he gets probed, the tolerance is too tight.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `revenue_total`, `bean_share_of_cogs`, `non_bean_input_change`, `menu_price_change`, `bean_price_change`
- Force-released before the recommendation ask: none
- Scoring QA: `{"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"dataRequestGaps":0,"reconcileMerges":1,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":2,"crossDimensionRepeats":0,"dataRequestsNotInCase":2}`
- Assists / interventions: none

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | defer | cogs_pct, labor_pct, overhead_pct | Cost breakdown as a percent of revenue for both years | no |
| 5 | none | bean_share_of_cogs, non_bean_input_change | COGS breakdown by input type (coffee beans, dairy, cups, packaging, food, wastage) | no |
| 5 | none | menu_price_change | Menu price changes over the two-year period | no |
| 7 | release | revenue_total | Total annual revenue | yes |
| 9 | release | bean_share_of_cogs, non_bean_input_change, menu_price_change | COGS composition breakdown and menu pricing information | yes |
| 11 | release | bean_price_change | Actual bean price change over the period | no |
| 13 | release | bean_price_change | Actual coffee bean price change over 2 years | yes |
| 13 | refuse | — | Wastage, shrink, or spoilage as a percent of COGS | no |
| 15 | refuse | — | Elasticity data or competitor pricing information | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens |
|---|---|---|---|
| interviewer | 11 | 87687 | 870 |
| data_request | 11 | 9708 | 869 |
| coverage | 9 | 15832 | 624 |
| judge | 1 | 10700 | 3511 |
| verifier | 1 | 4647 | 709 |
| reconcile | 1 | 2058 | 824 |

## Feedback

**Top improvement:** Sharpen the procurement framing in brainstorm and synthesis: the data showed beans are only 25% of COGS while non-bean inputs (dairy, packaging, food) rose 37.5% and drove the larger share of the increase — weight procurement recommendations toward those non-bean suppliers rather than defaulting to beans, which the candidate led with despite them being the smaller piece.

### Problem Structuring — strong
- ✅ The candidate led with the objective-relevant insight (costs outpacing revenue) before enumerating clean, tailored buckets with prioritization.
  > That combination tells me costs grew much faster than revenue, so I'd lean cost-side first, but I want to confirm revenue quality too.
  > I'd break it into three buckets. One, revenue: is the 15% growth from new store openings versus same-store sales, and is it price or volume?
- ✅ When challenged on MECE, the candidate self-diagnosed overlap and added a genuinely tailored missing dimension (mix and store maturity).
  > I lumped "costs" into one bucket without a clean cut. Better to split by P&L line: COGS, store-level operating costs like labor and rent, then corporate SG&A.
  > Second, I left out mix. If they've shifted toward lower-margin items... that's a margin driver that isn't strictly revenue growth or cost inflation.

### Quantitative & Analytical Rigor — strong
- ✅ The candidate correctly decomposed the 18-point margin drop into its cost drivers immediately and accurately.
  > COGS up 16 points, overhead up 2, labor flat. That's 18 points of cost increase, and the margin fell exactly 18 points, 24 to 6.
- ✅ The candidate performed a clean nested-percentage back-out to infer bean price inflation, narrating each step and tracking units between COGS-share and revenue-points.
  > Other inputs: 31.5, times 1.15 for volume, times 1.375 for price. 31.5 × 1.15 is roughly 36, times 1.375 is about 50 points.
  > So beans today must be about 67 minus 50, call it 17 points. At flat prices beans would be 10.5 × 1.15 ≈ 12. So beans are running roughly 40% above where volume alone explains
- ✅ The candidate sanity-checked results, tied numbers to business implication, and gracefully corrected the sizing when given actual revenue, but when sizing 'the prize' the elasticity math slightly conflated volume loss with revenue loss without fully carrying the price effect.
  > Current profit is 6% of $480 million, about $29 million. If we clawed COGS back to 42%, profit would go to roughly $100 million, so margin back to about 21%.
  > even recovering a third of the COGS gap is $25 million — it nearly doubles profit.
  > If a 10% price rise costs us, say, 5% of volume, we lose 5% of revenue but also 5% of that $280 million COGS, about $14 million back — so the net is still strongly positive.

### Data & Exhibit Interpretation — strong
- ✅ The candidate isolated COGS as the driver the moment the cost breakdown was provided and quantified its share of the decline.
  > So COGS explains roughly 90% of the decline, call it nine tenths, and overhead the rest.
  > So the question becomes what's inside COGS.
- ✅ The candidate translated the COGS composition data into a precise diagnosis — separating input inflation from operational waste — and stated the so-what for the fix.
  > Two conclusions: input inflation across the board, beans worst, and zero price pass-through in two years. That's the root cause.
  > That's reassuring; it means the fix is commercial, not a store-level cleanup.

### Business Judgment & Insight — strong
- ✅ The candidate showed strong commercial sense by protecting labor from cuts to avoid service-quality risk rather than reflexively cutting costs.
  > Labor at 22% has been stable — I'd leave it alone rather than risk service quality.
- ✅ The candidate proactively surfaced the central risk (elasticity) and proposed a concrete, phased mitigation.
  > Risk: elasticity is unknown, and that's the whole bet. I'd phase it — 8-10% on espresso drinks first, test in 20 stores across price tiers, measure transaction counts for six weeks before rolling out.
- ✅ The candidate correctly reasoned that flat prices amid inflation makes pricing the impact-sized lever, and quantified why procurement alone is insufficient.
  > it's the only lever sized to the problem... Procurement, mix, and overhead together are maybe $20 million optimistically, and procurement takes contract cycles to land. Price moves in a quarter.

### Creativity & Brainstorming — strong
- ✅ The candidate organized the brainstorm into clear buckets and produced diverse, specific levers within each.
  > Three buckets beyond pricing. One, procurement... forward contracts or hedging to lock prices, consolidating suppliers for volume discounts, direct-trade sourcing to cut the middleman, and re-specifying blends toward cheaper origins.
- ✅ The candidate included a non-obvious lever — using mix and upselling to raise effective price without a visible increase.
  > Shifting mix a few points, or upselling sizes, raises effective price without a visible price increase.
  > Also worth testing a lower-cost dairy alternative given dairy sits in that 37.5% inflation bucket.
- 💡 During the brainstorm, the candidate covered procurement broadly but framed it primarily around beans.
  > Better: Since beans are only 25% of COGS and the other inputs — dairy, packaging, food — drove the larger share of the increase, I'd weight procurement effort toward renegotiating those non-bean suppliers as much as the beans themselves.

### Synthesis & Recommendation — strong
- ✅ The candidate led answer-first with a committed recommendation and tied it directly to the analysis.
  > Recommendation: lead with price. Brew & Bean hasn't raised menu prices in two years while input costs inflated, and that pass-through gap is the entire margin story.
- ✅ The recommendation was concise, sized, risk-flagged, and closed with concrete next steps.
  > Risk: elasticity is unknown, and that's the whole bet.
  > Next steps: that pilot, competitor price benchmarking, and start bean hedging in parallel.
- 💡 In the final recommendation the candidate quantified procurement modestly but did not emphasize that non-bean inputs (up 37.5%) are the bigger procurement target.
  > Better: In parallel with pricing, I'd renegotiate dairy and packaging supply as aggressively as beans, since those non-bean inputs actually account for the larger portion of the COGS increase.

### Communication & Delivery — strong
- ✅ The candidate was consistently top-down, signposted buckets explicitly, and used hypothesis-driven phrasing throughout.
  > I'd break it into three buckets.
  > Two conclusions: input inflation across the board, beans worst, and zero price pass-through in two years. That's the root cause.
- ✅ The candidate narrated math steps clearly and transparently flagged rounding, keeping the interviewer able to follow.
  > Let me work this through, rounding as I go.
  > I'm rounding but the story doesn't move.

### Pushback, Composure & Case Leadership — strong
- ✅ When challenged on MECE, the candidate neither capitulated nor got defensive — it acknowledged the specific flaw and improved the structure.
  > Fair challenge. I think the three buckets are collectively exhaustive if I define bucket three properly — but as I said it, it's sloppy in two places.
- ✅ The candidate consistently drove the case forward by proactively requesting the next relevant data at each turn.
  > Do we have a split of COGS by input, and whether menu prices have moved over the two years?
  > Yes, please — I'd like to check my inference, because I backed into that number rather than observing it.
- ✅ The candidate handled its own estimation error with composure, acknowledging the miss and noting its implication.
  > Good — I was low by more than half. That implies about $2.4 million per store, so either much higher traffic or a bigger ticket than I assumed. Worth noting for later.

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a moment, then walk me through how you'd approach this.

**Candidate · 1:30** (turn 1)

Let me take a second to structure this.

So margin fell from 24% to 6% — that's an 18-point drop, roughly three quarters of the margin gone — while revenue grew 15%. That combination tells me costs grew much faster than revenue, so I'd lean cost-side first, but I want to confirm revenue quality too.

I'd break it into three buckets. One, revenue: is the 15% growth from new store openings versus same-store sales, and is it price or volume? If they opened a lot of stores, the growth could be masking declining per-store performance. Two, costs: split fixed versus variable — rent, labor, coffee beans and dairy, and any corporate overhead. I'd want to find which line grew fastest as a percent of revenue. Three, anything below the operating line — new debt, one-time charges.

To start: do we have a cost breakdown as a percent of revenue for both years?

**Interviewer · 1:32** (turn 2)

Before we pull data — is that framework MECE? What's missing?

**Candidate · 3:02** (turn 3)

Fair challenge. I think the three buckets are collectively exhaustive if I define bucket three properly — but as I said it, it's sloppy in two places.

First, I lumped "costs" into one bucket without a clean cut. Better to split by P&L line: COGS, store-level operating costs like labor and rent, then corporate SG&A. That way each dollar sits in exactly one place and nothing double-counts — right now labor and rent could arguably sit in either.

Second, I left out mix. If they've shifted toward lower-margin items — say more food, less espresso — or toward lower-margin channels like delivery apps that take a cut, that's a margin driver that isn't strictly revenue growth or cost inflation. It's really a revenue-quality issue, so I'd fold it under revenue as price, volume, mix.

And I'd add store maturity: new stores ramping would drag margin without anything being broken.

So: revenue by price/volume/mix, COGS, store opex, corporate overhead, below-the-line. Does that hold?

**Interviewer · 3:06** (turn 4)

That holds. Let's get you the cost breakdown as a percent of revenue. Here's what I have: COGS is 58% of revenue today, up from 42% two years ago. Labor is 22% of revenue, and it’s been stable. Overhead is 14% of revenue, up slightly from 12%.

**Candidate · 4:37** (turn 5)

That basically solves it. Let me add it up — COGS up 16 points, overhead up 2, labor flat. That's 18 points of cost increase, and the margin fell exactly 18 points, 24 to 6. So COGS explains roughly 90% of the decline, call it nine tenths, and overhead the rest. I'm rounding but the story doesn't move.

Worth sizing it. If revenue today is R, 16 points of R is the prize. Even recovering half the COGS gap gets us back to mid-teens margin.

So the question becomes what's inside COGS. It's coffee beans, dairy, cups and packaging, food, and possibly wastage. Two broad explanations: input prices rose, or their volume-per-dollar-of-revenue worsened — more waste, worse purchasing terms, mix shift into low-margin food.

Do we have a split of COGS by input, and whether menu prices have moved over the two years?

**Interviewer · 4:39** (turn 6)

You want to size the prize in dollars — what's total revenue today?

**Candidate · 7:45** (turn 7)

I don't think I have that figure — can we get total revenue today? If not, I'll estimate it.

Rough build: 200 locations, and a specialty coffee shop does somewhere around $1 million a year per store — call it 500 transactions a day at a $6 ticket, that's $3,000 a day, times 350 days is about $1.05 million, so call it $1 million even. Times 200 stores gives roughly $200 million in revenue.

So the COGS gap is 16% of $200 million, about $32 million a year. Overhead adds 2 points, say $4 million. Total prize around $36 million — call it $35 million, I'm rounding hard here.

For scale, current profit at 6% of $200 million is about $12 million. Getting COGS back to 42% would roughly triple that to around $44 million. That's a big enough number to justify going deep on COGS.

Does $200 million sound directionally right, or do you have the actual figure?

**Interviewer · 7:48** (turn 8)

Here's the actual figure: Total revenue is $480M a year.

**Candidate · 9:19** (turn 9)

Good — I was low by more than half. That implies about $2.4 million per store, so either much higher traffic or a bigger ticket than I assumed. Worth noting for later.

Resizing: COGS gap is 16% of $480 million. Ten percent is $48 million, half again is $24 million, so about $72 million — call it $75 million with the rounding. Overhead's 2 points is roughly $10 million. So the total prize is somewhere around $85 million a year.

Current profit is 6% of $480 million, about $29 million. If we clawed COGS back to 42%, profit would go to roughly $100 million, so margin back to about 21%. That's the full-recovery case and probably optimistic, but even recovering a third of the COGS gap is $25 million — it nearly doubles profit.

So COGS is unambiguously where the work is. Can we open up that 58%?

**Interviewer · 9:22** (turn 10)

Let me give you what I have on COGS composition and menu pricing. Here's the bean share of COGS, the other input changes, and menu price moves: Coffee beans were 25% of COGS two years ago. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years. Menu prices have not changed in two years.

**Candidate · 10:59** (turn 11)

Let me work this through, rounding as I go.

Start on the old revenue base of 100. Old COGS 42 points: beans 25% of that is about 10.5, other inputs about 31.5.

Since prices haven't moved, all 15% revenue growth is volume — so volumes are up 15% across the board.

Other inputs: 31.5, times 1.15 for volume, times 1.375 for price. 31.5 × 1.15 is roughly 36, times 1.375 is about 50 points.

Now today's actual COGS: 58% of revenue, and revenue is 115, so 0.58 × 115 ≈ 67 points.

So beans today must be about 67 minus 50, call it 17 points. At flat prices beans would be 10.5 × 1.15 ≈ 12. So beans are running roughly 40% above where volume alone explains — bean prices are up around 40%.

Two conclusions: input inflation across the board, beans worst, and zero price pass-through in two years. That's the root cause.

**Interviewer · 11:01** (turn 12)

You inferred bean prices are up around forty percent. Do you want the actual bean price change?

**Candidate · 12:31** (turn 13)

Yes, please — I'd like to check my inference, because I backed into that number rather than observing it. If the actual bean increase is materially above 40%, some of what I attributed to beans is really waste or mix, and that's a different fix: procurement versus operations.

One related thing I'd want alongside it — do we have a wastage or shrink figure, or spoilage as a percent of COGS? Flat menu prices and rising volumes can hide a store-level yield problem, and I'd hate to sign off on "it's all input inflation" if a few points are actually product being thrown away. If we don't have it, I'll assume waste is stable and treat the whole gap as price.

But go ahead with the bean number — what is it?

**Interviewer · 12:36** (turn 14)

Raw coffee bean costs are up 40% over the past two years.

**Candidate · 14:06** (turn 15)

Good — 40% matches my back-out, so the gap is fully explained by input inflation, not hidden waste. That's reassuring; it means the fix is commercial, not a store-level cleanup.

Sizing the pricing lever. Prices have been flat for two years while costs inflated. Today COGS is 58% of $480 million, about $280 million. If we pass through a 10% price increase on flat volume, revenue goes to roughly $528 million, and that $48 million drops almost entirely to the bottom line since costs don't move. Profit goes from about $29 million to about $77 million — margin roughly 15%. Rounding, but that's most of the way back.

The risk is elasticity. If a 10% price rise costs us, say, 5% of volume, we lose 5% of revenue but also 5% of that $280 million COGS, about $14 million back — so the net is still strongly positive. Pricing works unless volume falls a long way.

Do we have any elasticity data, or competitor pricing?

**Interviewer · 14:08** (turn 16)

I don't have elasticity or competitor pricing data. Beyond pricing, what other levers could the client pull to recover margin? Give me a structured set.

**Candidate · 17:09** (turn 17)

No data, so I'll assume moderate elasticity and flag it as the key test.

Three buckets beyond pricing.

One, procurement. Beans are up 40% and were 25% of COGS — today that's roughly $70 million of spend. Levers: forward contracts or hedging to lock prices, consolidating suppliers for volume discounts, direct-trade sourcing to cut the middleman, and re-specifying blends toward cheaper origins. A 10% procurement win on beans is about $7 million.

Two, mix and product. Push high-margin items — brewed coffee and espresso carry far better margins than dairy-heavy drinks or food. Shifting mix a few points, or upselling sizes, raises effective price without a visible price increase. Also worth testing a lower-cost dairy alternative given dairy sits in that 37.5% inflation bucket.

Three, overhead. It drifted from 12% to 14%, about $10 million on today's revenue. Smaller prize, but it's controllable and doesn't touch the customer.

Labor at 22% has been stable — I'd leave it alone rather than risk service quality.

**Interviewer · 17:13** (turn 18)

You've got price, procurement, mix, and overhead. Which one leads, and what's your recommendation to the CEO?

**Candidate · 20:34** (turn 19)

Recommendation: lead with price. Brew & Bean hasn't raised menu prices in two years while input costs inflated, and that pass-through gap is the entire margin story.

Why it leads: it's the only lever sized to the problem. A 10% increase on $480 million is roughly $48 million of near-pure profit, taking margin from 6% to about 15%. Procurement, mix, and overhead together are maybe $20 million optimistically, and procurement takes contract cycles to land. Price moves in a quarter.

Supporting: the 18-point margin drop is fully explained — 16 points COGS, 2 overhead — and the COGS move is input inflation, 40% on beans, 37.5% on everything else. No operational breakage to fix. Demand is healthy: volumes are up 15%.

Risk: elasticity is unknown, and that's the whole bet. I'd phase it — 8-10% on espresso drinks first, test in 20 stores across price tiers, measure transaction counts for six weeks before rolling out.

Next steps: that pilot, competitor price benchmarking, and start bean hedging in parallel.

**Interviewer · 21:02** (turn 20)

That's time. Thank you for working through this — a full written report with detailed feedback will follow. Nice to meet you, and take care.
