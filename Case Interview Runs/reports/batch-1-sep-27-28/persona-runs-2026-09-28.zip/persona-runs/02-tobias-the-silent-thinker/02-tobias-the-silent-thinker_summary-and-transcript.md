# Live run — Brew & Bean Profitability

- Session: `d3fa7905-50ce-4f9b-9ac7-0ff719597ee5` · case `prof-001` · status **completed** · 2026-09-27
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **2. Tobias — the Silent Thinker**
- Tests: Rule 13 silence tolerance as a false-positive test: the ladder must NOT fire on a candidate who is simply slow. If he gets rescued, the tolerance window is miscalibrated.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `non_bean_input_change`, `menu_price_change`
- Force-released before the recommendation ask: none
- Scoring QA: `{"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"dataRequestGaps":0,"reconcileMerges":1,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":0,"dataRequestsNotInCase":0}`
- Assists / interventions: none

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | defer | cogs_pct, labor_pct, overhead_pct, bean_share_of_cogs, non_bean_input_change | P&L broken into cost lines (COGS components and operating costs like labor and rent) for both years | no |
| 3 | release | cogs_pct, labor_pct, overhead_pct | Cost structure line items (COGS, labor, overhead) each as a percent of revenue across two years | yes |
| 5 | none | bean_share_of_cogs, non_bean_input_change | Breakdown of COGS by input components (beans, dairy, cups, food) over three years | no |
| 7 | release | bean_share_of_cogs, non_bean_input_change | COGS breakdown by input category (beans vs. other inputs) | yes |
| 9 | release | menu_price_change | Menu price changes over the past two years | yes |

## LLM usage

| Component | Calls | Input tokens | Output tokens |
|---|---|---|---|
| interviewer | 8 | 60995 | 492 |
| data_request | 8 | 6977 | 481 |
| coverage | 7 | 10045 | 1582 |
| judge | 1 | 9730 | 3559 |
| verifier | 1 | 3886 | 426 |
| reconcile | 1 | 2098 | 218 |

## Feedback

**Top improvement:** Flag the assumptions your derived figures rest on and sanity-check the big ones — the headline ~123% bean increase depends on an index built from an assumed 15% revenue growth, so stating it as hard fact overstates your certainty; a one-line caveat plus a plausibility check would make an already-strong analysis bulletproof.

### Problem Structuring — strong
- ✅ Restated the objective as a cost problem via quick arithmetic and laid out three tailored, non-overlapping buckets.
  > Margin fell from 24% to 6% while revenue grew 15%, so this is almost certainly a cost problem — costs grew materially faster than revenue.
  > First, revenue quality... Second, cost structure... Third, external factors: commodity prices, wage inflation, lease renewals, competition.
- ✅ Prioritized explicitly with a reasoned rationale, treating causes as explanations rather than locations.
  > The other two buckets I'd use as explanations once I've located the line — new-store dilution and commodity or wage inflation are causes, not locations. No point theorizing about why before I know where.
- 💡 In the opening framework, the candidate mentioned competition only as a bullet under external factors.
  > Better: I'd also want to know whether peers are seeing the same margin compression — if input inflation is industry-wide, everyone will reprice and our elasticity risk is lower, which changes how aggressive we can be on menu prices.

### Quantitative & Analytical Rigor — strong
- ✅ Verbalized an index-based approach to convert flat percent-of-revenue lines into absolute dollar growth, correctly showing labor grew in line with revenue.
  > 25.3 divided by 22 is 1.15 — labor dollars grew 15%, identical to revenue. That's the point I'm drawing out: a line flat as a percent of revenue is still growing in absolute dollars, just proportionally.
  > So COGS is rising on a per-unit basis, not just with volume.
- ✅ Backed into the unrevealed bean line cleanly and stated the business implication of the ranking.
  > Current total COGS I calculated at 66.7. So beans today = 66.7 − 43.3 = 23.4.
  > Coffee beans are the single largest driver; other inputs at 37.5% are a real secondary issue but roughly a third the impact.
- ✅ The candidate sized the pricing lever from first principles and interpreted the ~123% bean increase against the target margin, but stated that increase as hard fact without flagging its dependence on the 15%-revenue-growth indexing assumption.
  > A 10% price increase, volume held, adds 11.5 straight to profit — 18.4 on 126.5 revenue, a 14.5% margin.
  > Restoring 24% would need roughly 24% pricing, which I wouldn't attempt at once.
  > That's 10.5 to 23.4 — up about 123%, more than doubling. And beans have gone from 25% of COGS to roughly 35%.
- 💡 After deriving the ~123% bean increase, the candidate did not sanity-check whether such a spike was plausible against the other-inputs 37.5% figure.
  > Better: A ~123% bean increase is a strong claim resting on my index assumptions, so let me sanity-check it — beans more than doubling while dairy, packaging and food rose only 37.5% is plausible given recent coffee commodity spikes, but I'd want to confirm the actual bean price change before I bank on that magnitude.

### Data & Exhibit Interpretation — strong
- ✅ Isolated COGS as the driver immediately, quantified its share of the decline, and dismissed labor/overhead with a reason.
  > COGS is the whole story. It went from 42% of revenue to 58% — 16 points of the 18-point margin decline. Labor is flat at 22%, overhead drifted up 2 points, which is worth a note but not the answer.
- ✅ Translated each exhibit into a hypothesis and a specific next data request rather than restating numbers.
  > Two possibilities: input costs per unit went up, or we're selling the same units for less — discounting, or mix shifting toward lower-margin items.
  > Do we have a breakdown of COGS by input — beans, dairy, cups, food — for those three years?

### Business Judgment & Insight — strong
- ✅ Explicitly protected labor from cuts, tying it to the service quality that justifies premium pricing.
  > I would not cut labor. It's the service quality that lets you charge specialty prices.
- ✅ Surfaced elasticity and competitor-repricing risks and proposed a phased, testable rollout rather than a blanket price hike.
  > Risks: specialty coffee demand elasticity, and competitors who may have already repriced.
  > elasticity test in a subset of the 200 stores, and hedge or lock bean contracts so we're not repricing again in six months.
- ✅ Reframed waste economics as a lever specifically because the input got expensive — a commercially sharp insight.
  > If beans doubled in cost, every gram of over-pouring or end-of-day dumped brew is now twice as expensive.
  > the same waste rate costs far more than it did two years ago.

### Creativity & Brainstorming — strong
- ✅ Organized the brainstorm into clear categories with distinct, non-obvious ideas and prioritized labor out with reasoning.
  > Three categories, beyond price and procurement. First, product mix... Second, portion and waste economics... Third, overhead.
  > shift volume toward items where beans aren't the main input — food, teas, cold brew concentrate served in larger formats.
- ✅ Connected mix shift back to the previously flagged elasticity risk, showing ideas were interlinked not scattered.
  > Bundling a lower-bean-content item with coffee raises ticket without touching headline coffee prices, which also protects the elasticity risk I flagged.
- 💡 The brainstorm covered mix, waste, and overhead but did not surface a lower-cost commodity blend option for price-sensitive segments.
  > Better: A fourth option: pilot a lower-cost commodity blend at budget-conscious or high-price-sensitivity locations, preserving the specialty blend where customers pay a premium — this defends volume if the price increase pushes some customers away.

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a crisp headline, then gave three evidence-linked supports, a risk, and sequenced next steps within the time limit.
  > Headline: your margin problem is coffee bean inflation you never passed through to customers. Raise prices and lock your bean supply.
  > The fix, in sequence: a staged price increase, starting around 10%... Then hedge or contract beans... Then mix shift and portion control to claw back the rest.
- ✅ Quantified the impact of the headline recommendation so the CEO hears the payoff, not just the action.
  > a staged price increase, starting around 10%, which on current economics adds roughly 11.5 points and takes margin from 6% to about 14.5%.

### Communication & Delivery — strong
- ✅ Consistently top-down and signposted, stating conclusions before detail and numbering buckets throughout.
  > COGS is the whole story.
  > Three supports. One, COGS explains 16 of the 18 margin points... Two, within COGS, beans more than doubled... Three, prices haven't moved in two years, so we ate all of it.
- ✅ Answered the precise math-walkthrough question cleanly without rambling.
  > I'm holding revenue as an index: 100 two years ago, 115 now, since revenue grew 15%.
  > 25.3 divided by 22 is 1.15 — labor dollars grew 15%, identical to revenue.

### Pushback, Composure & Case Leadership — strong
- ✅ When asked to justify the labor index figure, the candidate calmly walked through the derivation and reinforced the underlying insight.
  > So two years ago labor was 22% × 100 = 22 in index units. Currently it's 22% × 115 = 25.3.
  > a line flat as a percent of revenue is still growing in absolute dollars, just proportionally.
- ✅ Answered the prioritization challenge with explicit reasoning rather than reflexively reshuffling the framework.
  > Cost structure, second bucket — and specifically each line as a percent of revenue across the two years. Reason is arithmetic.
  > the fastest path is a percent-of-revenue bridge: whichever line moved most in basis points is the culprit.

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

How would you like to approach this? Feel free to take a moment to gather your thoughts first.

**Candidate · 2:20** (turn 1)

Here's how I'd frame it. Margin fell from 24% to 6% while revenue grew 15%, so this is almost certainly a cost problem — costs grew materially faster than revenue. I'd want to confirm that first, then isolate where.

Three buckets:

First, revenue quality. The 15% growth — is it from new stores, more transactions per store, or price? Growth from new-store openings can carry fixed costs before they mature, which dilutes margin even if unit economics are fine.

Second, cost structure. I'd split COGS — coffee beans, milk, cups — from store-level operating costs like labor and rent, then corporate overhead. I want each as a percent of revenue, two years ago versus today.

Third, external factors: commodity prices, wage inflation, lease renewals, competition.

To start — do we have the P&L broken into those cost lines for both years?

**Interviewer · 2:23** (turn 2)

Before I hand you data — one question on your structure.

Which of those three buckets would you prioritize first, and why?

**Candidate · 4:43** (turn 3)

Cost structure, second bucket — and specifically each line as a percent of revenue across the two years.

Reason is arithmetic. Revenue grew 15%. If margin went 24% to 6%, then on a base of 100 going to 115, profit went from 24 to about 6.9 — so absolute profit fell roughly 70% while the business got bigger. Total costs went from 76 to 108, up about 42% against 15% revenue growth. That gap is large enough that it almost has to sit in one or two line items, not be spread evenly.

So the fastest path is a percent-of-revenue bridge: whichever line moved most in basis points is the culprit, and that single step also tells me whether it's a store-level cost or overhead.

The other two buckets I'd use as explanations once I've located the line — new-store dilution and commodity or wage inflation are causes, not locations. No point theorizing about why before I know where.

**Interviewer · 4:46** (turn 4)

Understood. Here's the cost structure over time.

**Candidate · 7:49** (turn 5)

COGS is the whole story. It went from 42% of revenue to 58% — 16 points of the 18-point margin decline. Labor is flat at 22%, overhead drifted up 2 points, which is worth a note but not the answer.

And it's worse in absolute terms. Indexing revenue at 100 growing to 115: COGS was 42, now it's 0.58 × 115 = 66.7. That's up 59% while revenue grew 15%. Labor went 22 to 25.3, up 15% — exactly in line with revenue, which tells me store-level productivity is stable and volume-driven costs are behaving normally.

So COGS is rising on a per-unit basis, not just with volume. Two possibilities: input costs per unit went up, or we're selling the same units for less — discounting, or mix shifting toward lower-margin items.

Do we have a breakdown of COGS by input — beans, dairy, cups, food — for those three years?

**Interviewer · 7:51** (turn 6)

You said labor went to 25.3 on that index — walk me through that.

**Candidate · 9:22** (turn 7)

Sure. I'm holding revenue as an index: 100 two years ago, 115 now, since revenue grew 15%.

The exhibit gives cost lines as percent of revenue. Labor is 22% in both periods. So two years ago labor was 22% × 100 = 22 in index units. Currently it's 22% × 115 = 25.3.

25.3 divided by 22 is 1.15 — labor dollars grew 15%, identical to revenue. That's the point I'm drawing out: a line flat as a percent of revenue is still growing in absolute dollars, just proportionally. So labor isn't a problem, but it's also not a source of savings — there's no evidence of inefficiency to strip out.

Same method on COGS gave 42 to 66.7, or 59% growth. That divergence is what isolates COGS as the driver.

**Interviewer · 9:24** (turn 8)

Understood. Here's the COGS breakdown by input. Coffee beans were 25% of COGS two years ago. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 11:45** (turn 9)

Let me back into the bean line, since we weren't given it directly.

Two years ago COGS was 42 index units. Beans at 25% of that is 10.5. Everything else — dairy, packaging, food — is 31.5.

Other inputs up 37.5%: 31.5 × 1.375 = 43.3.

Current total COGS I calculated at 66.7. So beans today = 66.7 − 43.3 = 23.4.

That's 10.5 to 23.4 — up about 123%, more than doubling. And beans have gone from 25% of COGS to roughly 35%.

So the ranking is clear. Coffee beans are the single largest driver; other inputs at 37.5% are a real secondary issue but roughly a third the impact. Both are running far ahead of the 15% revenue growth, which says we absorbed input inflation without passing it through.

That's the question I want to close out: have we taken any menu price increases in the past two years?

**Interviewer · 11:47** (turn 10)

Here's the menu price change. Menu prices have not changed in two years.

**Candidate · 14:08** (turn 11)

My recommendation: Brew & Bean's margin decline is an input-cost pass-through failure, not an operations problem — the fix is a staged menu price increase paired with bean procurement reform.

Three supports. One, COGS explains 16 of the 18 margin points; labor and overhead are essentially stable. Two, within COGS, beans more than doubled — up ~123% — with other inputs up 37.5%. Three, prices haven't moved in two years, so we ate all of it.

Sizing the lever: current index is revenue 115, costs 108.1, profit 6.9. A 10% price increase, volume held, adds 11.5 straight to profit — 18.4 on 126.5 revenue, a 14.5% margin. Restoring 24% would need roughly 24% pricing, which I wouldn't attempt at once.

Risks: specialty coffee demand elasticity, and competitors who may have already repriced.

Next steps: elasticity test in a subset of the 200 stores, and hedge or lock bean contracts so we're not repricing again in six months.

**Interviewer · 14:10** (turn 12)

Before recommendations — one open question.

Beyond pricing and procurement, what else could Brew and Bean do to rebuild margin? Give me a structured set of options.

**Candidate · 17:15** (turn 13)

Three categories, beyond price and procurement.

First, product mix. Beans are now roughly 35% of COGS, so shift volume toward items where beans aren't the main input — food, teas, cold brew concentrate served in larger formats. Bundling a lower-bean-content item with coffee raises ticket without touching headline coffee prices, which also protects the elasticity risk I flagged.

Second, portion and waste economics. If beans doubled in cost, every gram of over-pouring or end-of-day dumped brew is now twice as expensive. I'd audit grams per shot, brewed-coffee waste rates, and dairy spoilage. This is a real lever precisely because the input got expensive — the same waste rate costs far more than it did two years ago.

Third, overhead. It drifted 12 to 14 points, and in absolute terms 12 to 16.1 — up 34% against 15% revenue growth. Smaller than COGS, but it's the one line growing faster than the business that nobody's examined. Worth understanding whether that's new-store support costs or corporate creep.

I'd note labor is deliberately absent — flat at 22% means no evident slack, and cutting baristas in a specialty chain risks the service quality that justifies the price increase.

**Interviewer · 17:18** (turn 14)

Understood. Now give me your final recommendation to the CEO — headline first, in under a minute.

**Candidate · 20:23** (turn 15)

Headline: your margin problem is coffee bean inflation you never passed through to customers. Raise prices and lock your bean supply.

The evidence: of the 18-point margin decline, 16 points sit in COGS. Labor is flat at 22% of revenue, so this isn't an operations or productivity failure. Inside COGS, beans more than doubled — up about 123% — and other inputs rose 37.5%, while menu prices haven't moved in two years. You absorbed the entire input shock.

The fix, in sequence: a staged price increase, starting around 10%, which on current economics adds roughly 11.5 points and takes margin from 6% to about 14.5%. Then hedge or contract beans so you're not repricing again in six months. Then mix shift and portion control to claw back the rest.

Risk is elasticity — test in a subset of stores before rolling to all 200.

I would not cut labor. It's the service quality that lets you charge specialty prices.

**Interviewer · 20:25** (turn 16)

That's where we'll stop — time is up. Thank you for working through this; a full written report with feedback will follow. Nice to meet you.
