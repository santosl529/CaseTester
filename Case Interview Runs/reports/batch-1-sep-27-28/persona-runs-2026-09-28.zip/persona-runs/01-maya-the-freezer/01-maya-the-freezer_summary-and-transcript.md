# Live run — Brew & Bean Profitability

- Session: `c230fe12-c3ff-46c4-8cc6-91c870740b08` · case `prof-001` · status **completed** · 2026-09-28
- Overall: **needs_work**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **1. Maya — the Freezer**
- Tests: Rules 13 (full ladder + silence tolerance), 14 (two-attempt cap, repeated-error class), 12/13 (synthesis cap), 15, 17-C1, 17-C5 — the highest-stakes untested path in the spec.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `stores_count`, `bean_share_of_cogs`, `bean_price_change`, `cogs_pct`, `labor_pct`, `overhead_pct`, `non_bean_input_change`
- Force-released before the recommendation ask: none
- Scoring QA: `{"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":1,"dataRequestGaps":1,"reconcileMerges":5,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":4,"crossDimensionRepeats":1,"dataRequestsNotInCase":3}`
- Assists / interventions: silence_check_in@1, silence_check_in@14, silence_check_in@17, restate_anchor@18, narrow_frame@24, load_shed@46

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 6 | release | stores_count | Whether store count changed over the two-year period | yes |
| 8 | refuse | — | Whether the 15% revenue growth is uniform across all stores or concentrated in a subset of stores | no |
| 10 | clarify | — | Clarification on whether the 24% to 6% net margin figures are after-tax and after-interest (operating margin) or overall net margin | no |
| 24 | release | labor_pct, cogs_pct, overhead_pct | Breakdown of costs as a percent of revenue, comparing two years ago versus now | yes |
| 26 | release | bean_share_of_cogs, non_bean_input_change | Breakdown of COGS components (coffee beans, milk, cups, pastries) | no |
| 28 | clarify | bean_share_of_cogs | Current share of coffee beans as a percentage of COGS | yes |
| 30 | release | bean_price_change | Coffee bean price change over the two-year period | yes |
| 30 | defer | menu_price_change | Menu price changes over the two years | no |
| 42 | release | non_bean_input_change | Price changes on inputs other than coffee beans (milk, cups, pastries, waste) | yes |
| 44 | release | menu_price_change | menu price changes over two years | no |
| 46 | release | menu_price_change | Menu price changes over the 2-year period | no |
| 46 | refuse | — | A specific cut or breakdown of costs (implied: how much of the bean price increase was passed through to customers, or product mix details) | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 23 | 166202 | 1071 | $0.858 |
| data_request | 26 | 18311 | 1460 | $0.026 |
| coverage | 22 | 30459 | 3108 | $0.046 |
| judge | 1 | 11263 | 4259 | $0.163 |
| verifier | 1 | 5184 | 1207 | $0.056 |
| reconcile | 1 | 3303 | 1583 | $0.056 |
| candidate simulator (claude-opus-5) | 23 | 51677 | 2839 | $0.329 |

- App cost (interviewer + scoring): **$1.20** · with simulator: **$1.53** · list prices, uncached
- Wall time: 22:25

## Feedback

**Top improvement:** Master nested-percentage math and hold your derived numbers with confidence: a share of COGS is not points of revenue, so convert by multiplying through (beans at 25% of COGS × 42% of revenue = 8.4%, then × 1.4 = 11.76%), sanity-check every result against the total before asserting it, and state conclusions top-down rather than as questions asking for validation.

### Problem Structuring — needs_work
- ⚠️ The candidate could not decompose costs when asked and required a multi-step directive rescue (Level 1 and Level 2 assists) to name basic cost buckets for a coffee chain.
  > Hmm, I'm not sure.
  > I don't really know where to start, sorry.
- ⚠️ The candidate opened with a recognizable high-level split of revenue, costs, and external factors and stated a directional hypothesis, but the framework never restated the objective, offered no sub-points under revenue (volume × price) or costs, and did not tie the structure to the profit decision.
  > Okay, so I'd want to look at, um, three main areas.
  > First, revenue — like what's happening with sales. Second, costs — what they're spending money on. And third, maybe external stuff, like the market or competitors or the industry.
  > I think the costs one is probably where the issue is, since revenue grew but profit went down.
- 💡 When asked 'within costs, how would you break it down?' (turn 3), the candidate deflected with clarifying questions and then stalled.
  > Better: I'd split costs into COGS — beans, dairy, packaging, food; labor — barista wages and benefits; and occupancy/overhead — rent, utilities, equipment. Since profit fell while revenue grew and the footprint is flat, I'd start with COGS as a percent of revenue to see if input inflation is compressing margin.

### Quantitative & Analytical Rigor — needs_work
- ✅ Once corrected, the candidate correctly reconciled the two COGS drivers against the total margin gap.
  > So 3.36 plus 11.8 is about 15.2 points, and COGS went up 16. So input cost inflation explains basically the whole thing.
- ⚠️ The candidate repeatedly committed a units error, adding a percentage-price-increase directly to a revenue-share figure, and held onto the wrong answer even after multiple corrections.
  > so 8.4 plus 40, so about 48% of revenue now
  > But I still kind of think the 40 sits on top of the 8.4, so 48.4. I'm not sure which one you want.
- ⚠️ The candidate did eventually self-correct the nested-percentage error and land on the correct 3.36-point bean-to-revenue increase (11.76% vs 8.4%), but only under heavy interviewer guidance and after repeatedly reverting to the wrong figure.
  > That'd be the 11.76 one — 8.4 times 1.4.
  > Though if I do 8.4 plus the 40, I get 48.4, and that's the one that lines up better with COGS going to 58. So I keep landing back there.
  > Hmm, that can't be right, that's bigger than total COGS. Sorry — I keep doing that same thing. I think it should be 31.5 times 1.375, which is about 43.3, so up about 11.8 points.
- 💡 At turn 32, the candidate asserted beans would be '48% of revenue now' — a red flag since that alone would nearly equal total COGS of 58%.
  > Better: Beans were 8.4% of revenue and prices rose 40%, so the new bean cost is 8.4 × 1.4 = 11.76% of revenue — an increase of about 3.4 points. That only explains a fraction of the 16-point COGS jump, so other inputs must be the bigger driver.

### Data & Exhibit Interpretation — meets_bar
- ✅ The candidate proposed a concrete next step to open up the COGS bucket rather than stopping at the top-line number.
  > Do we know what's inside COGS? Like a split between coffee beans, milk, cups, pastries?
- ⚠️ The candidate read the cost-structure exhibit cleanly and isolated COGS as the driver, but the translation into the drivers within COGS was derailed by the arithmetic units error before being recovered with help.
  > so 8.4 plus 40, so about 48% of revenue now. That's a huge jump — that would more than explain the whole COGS increase.
  > COGS is the big one — it went from 42 to 58. So that's a 16% increase in COGS.
  > It's really COGS eating the margin — 16 points of the 18 point drop is basically all of it.
- 💡 After naming COGS as the driver (turn 26), a strong candidate would have flagged the hypothesis to test before asking for data.
  > Better: COGS drives 16 of the 18 points. My hypothesis is input-cost inflation rather than volume, so I'd want the COGS mix and the price change on each input to test whether beans alone explain it or whether it's broad-based inflation.

### Business Judgment & Insight — meets_bar
- ✅ The candidate drew a sound commercial inference from the revenue-share logic: rising COGS share while inputs inflated implies little to no price pass-through.
  > if prices had gone up, the COGS share would have fallen, not risen. The fact that it rose 16 points while inputs rose roughly 38-40% suggests they passed through basically nothing.
- ✅ The candidate reasoned that 15% revenue growth on a flat 200-store footprint must be volume or mix rather than price.
  > revenue grew 15% with the same 200 stores, so that's probably volume or mix, not price.
- ⚠️ The candidate's early lever hypothesis (labor) was speculative and unanchored, and was abandoned as soon as the exhibit appeared.
  > Um, maybe labor? I feel like that's usually a big one for a coffee shop, and if wages went up that could hit margin.
- 💡 At turn 46 the candidate correctly inferred prices were likely flat but did not surface pricing power or elasticity risk when connecting the diagnosis to a price-increase lever.
  > Better: If prices are flat while inputs rose ~38%, the primary lever is selective price increases on less-elastic specialty SKUs — but I'd want to check competitor pricing and demand elasticity before recommending, since blanket increases risk volume loss.

### Creativity & Brainstorming — needs_work
_Coverage caveat: The interviewer posed the brainstorm question ('beyond raising menu prices, what else could the client do?') only at the very end and immediately closed the case, so this dimension was effectively not administered — the rating reflects absence of evidence, not a candidate failing._

### Synthesis & Recommendation — needs_work
_Coverage caveat: The interview entered load-shedding at the exhibit stage and closed immediately after the diagnosis, so the final recommendation stage was never run — the rating reflects the diagnostic mini-syntheses available, not a full recommendation the candidate was never given time to deliver._
- ⚠️ The candidate produced a crisp mini-synthesis of the causal story in one line, but never delivered a final recommendation and framed even the diagnostic wrap-ups as questions seeking validation rather than committed conclusions.
  > Is that where you wanted me to land?
  > Sorry, is that a fair way to get there?
  > So: prices flat, costs up, margin absorbed all of it.
  > So the story is: costs inflated, prices didn't move.

### Communication & Delivery — needs_work
- ✅ When the candidate had a clear point, it was expressed concisely and in plain, followable terms.
  > Labor didn't move at all, so my hypothesis was wrong there, sorry. It's really COGS eating the margin — 16 points of the 18 point drop is basically all of it.
- ⚠️ The candidate repeatedly self-deprecated and apologized, which undercut composure and signaled low confidence.
  > I'm stuck, sorry. god I'm so bad at this.
  > Sorry, I know I'm going slow. god I'm so bad at this.
- ⚠️ Most conclusions were phrased as validation-seeking questions rather than assertive, top-down statements.
  > Am I on the right track here?
  > Is that the right track?
- 💡 After stalling on cost buckets (turns 12-18), the candidate spiraled into self-criticism instead of resetting.
  > Better: Let me think about this from the ground up — for a single coffee shop the big spend categories are ingredients, the people serving, and the space itself, so COGS, labor, and occupancy are my three cost buckets.

### Pushback, Composure & Case Leadership — needs_work
- ⚠️ The candidate remained engaged through repeated corrections and eventually incorporated the units feedback on the second calculation, but on the bean math resisted correction across multiple turns, repeatedly reverting to the wrong figure even after being walked through the right one.
  > But I still kind of think the 40 sits on top of the 8.4, so 48.4. I'm not sure which one you want.
  > and that's the one that lines up better with COGS going to 58. So I keep landing back there.
  > I think it should be 31.5 times 1.375, which is about 43.3, so up about 11.8 points.
- ⚠️ The candidate needed directive rescues to progress on structure and did not drive the case forward, largely waiting to be led.
  > I don't really know where to start, sorry.
  > Maybe... the coffee beans? Like the ingredients.
- 💡 At turn 35 when asked '40 percent of the whole revenue, or 40 percent of the 8.4?', the candidate had the pivotal cue but held the wrong interpretation.
  > Better: You're right — the 40% is a rise on the bean cost itself, so it's 40% of 8.4, which is 3.36 points; my earlier 48.4 was mixing units. Beans go from 8.4% to 11.76% of revenue.

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a minute if you need it, then tell me how you'd structure your approach.

**Interviewer · 1:01** (turn 1)

Still with me? Take your time. The question on the table: how would you approach this problem?

**Candidate · 2:03** (turn 2)

Okay, so I'd want to look at, um, three main areas. First, revenue — like what's happening with sales. Second, costs — what they're spending money on. And third, maybe external stuff, like the market or competitors or the industry.

I think the costs one is probably where the issue is, since revenue grew but profit went down. Does that seem like a reasonable place to start?

**Interviewer · 2:06** (turn 3)

Before I react, one thing. Is that structure MECE, and within costs, how would you break it down?

**Candidate · 2:25** (turn 4)

Hmm. Can I ask a clarifying question first — is Brew & Bean company-owned stores or franchised?

**Interviewer · 2:27** (turn 5)

Company-owned, all 200. Now back to my question: how would you break down costs?

**Candidate · 2:46** (turn 6)

Okay. And has the store count changed over the two years, or is it still 200?

**Interviewer · 2:48** (turn 7)

Here's the store count. 200 stores today — and it was 200 stores two years ago, so the footprint hasn’t changed.

**Candidate · 3:08** (turn 8)

Got it, thanks. And is the 15% revenue growth across all stores, or driven by a few?

**Interviewer · 3:10** (turn 9)

I don't have that split. Back to my question: how would you break costs down?

**Candidate · 3:32** (turn 10)

Okay. Um, one more thing — is the 24% to 6% net margin, like, after taxes and interest, or operating?

**Interviewer · 3:33** (turn 11)

I don't have that detail — treat it as overall net margin. Now, how would you break costs down?

**Candidate · 3:44** (turn 12)

Hmm, I'm not sure.

**Interviewer · 3:46** (turn 13)

Take a moment. What are the main buckets of cost for a coffee chain?

**Interviewer · 4:47** (turn 14)

Still with me? Take your time. The question on the table: what are the main buckets of cost for a coffee chain?

**Candidate · 5:10** (turn 15)

I don't really know where to start, sorry.

**Interviewer · 5:11** (turn 16)

Think about running a single coffee shop. What do you pay for to keep the doors open?

**Interviewer · 6:13** (turn 17)

Still with me? Take your time. The question on the table: what do you pay for to keep the doors open?

**Candidate · 6:46** (turn 18)

I'm stuck, sorry. god I'm so bad at this.

**Interviewer · 6:52** (turn 19)

No need for that. What's the single biggest thing you'd spend money on to sell a cup of coffee?

**Candidate · 7:44** (turn 20)

Maybe... the coffee beans? Like the ingredients.

**Interviewer · 7:47** (turn 21)

Okay, that's cost of goods. What else — beyond the ingredients, what do you pay for?

**Candidate · 8:39** (turn 22)

Rent? And, um, paying the baristas.

**Interviewer · 8:41** (turn 23)

So we have cost of goods, rent, and labor. Which of those would you look at first, and why?

**Candidate · 9:50** (turn 24)

Um, maybe labor? I feel like that's usually a big one for a coffee shop, and if wages went up that could hit margin. Is that the right track?

Do we have a breakdown of costs as a percent of revenue, like two years ago versus now?

**Interviewer · 9:53** (turn 25)

There's an exhibit on cost structure over time. Take a look.

**Candidate · 10:53** (turn 26)

Okay, so labor is flat at 22, overhead only moved 12 to 14. COGS is the big one — it went from 42 to 58. So that's a 16% increase in COGS.

Labor didn't move at all, so my hypothesis was wrong there, sorry. It's really COGS eating the margin — 16 points of the 18 point drop is basically all of it.

Do we know what's inside COGS? Like a split between coffee beans, milk, cups, pastries?

**Interviewer · 10:55** (turn 27)

I have a COGS breakdown. Here's the share that coffee beans make up: Coffee beans were 25% of COGS two years ago.

**Candidate · 11:36** (turn 28)

Okay, so if beans were 25% of COGS and COGS was 42% of revenue, then beans were... 25% of 42, so that's 8.4% of revenue two years ago.

Do we know what share beans are now? If bean costs spiked, that could explain a lot of the 16 point jump.

**Interviewer · 11:38** (turn 29)

Before that — you'd want the actual price change. Do you want bean prices, or the other input costs?

**Candidate · 12:17** (turn 30)

Bean prices, please. If those spiked that's probably the driver.

Also, did Brew & Bean change their menu prices at all over the two years? If bean costs went up and they didn't pass any of it through, that would make the margin hit worse.

**Interviewer · 12:19** (turn 31)

Here's the bean price change, then I'll get you menu prices. Raw coffee bean costs are up 40% over the past two years.

**Candidate · 13:11** (turn 32)

Okay, so if beans were 8.4% of revenue and they're up 40%, then they'd be 8.4 plus 40, so about 48% of revenue now. That's a huge jump — that would more than explain the whole COGS increase.

Hmm, that feels big though. But COGS only went to 58, so beans at 48 would be almost all of it.

Am I on the right track here?

**Interviewer · 13:12** (turn 33)

Walk me through that. If beans are up 40 percent, why would you add 40 to 8.4?

**Candidate · 13:49** (turn 34)

Um, because the cost went up by 40%, so I'm adding the 40 on top of the 8.4 that was already there. So 8.4 plus 40 equals 48.4% of revenue now.

I think that's right? It's a 40 point increase on the original.

**Interviewer · 13:52** (turn 35)

Points of what? The 40 percent — is that 40 percent of the whole revenue, or 40 percent of the 8.4?

**Candidate · 14:24** (turn 36)

Hmm. I think it's 40% of revenue, so it's 40 points on top of the 8.4 — so 48.4%. That's how I'd read it.

Sorry, I know I'm going slow. god I'm so bad at this.

**Interviewer · 14:26** (turn 37)

Slow is fine. The 40 percent is how much bean prices rose. That applies to the bean cost — the 8.4. So what's 40 percent of 8.4?

**Candidate · 15:41** (turn 38)

Okay, 40% of 8.4 is 3.36. So beans would be 8.4 plus 3.36, which is 11.76% of revenue.

But I still kind of think the 40 sits on top of the 8.4, so 48.4. I'm not sure which one you want.

**Interviewer · 15:45** (turn 39)

The 8.4 already is the bean cost in revenue terms. Prices rose 40 percent, so the new cost is that number times 1.4. Which of your two answers is that?

**Candidate · 16:24** (turn 40)

That'd be the 11.76 one — 8.4 times 1.4.

Though if I do 8.4 plus the 40, I get 48.4, and that's the one that lines up better with COGS going to 58. So I keep landing back there.

Sorry, I know you corrected me.

**Interviewer · 16:26** (turn 41)

Let it go — 48.4 assumes prices rose by 40 points of revenue, not 40 percent. The right figure is 11.76. So beans rose from 8.4 to 11.76 — how many points is that?

**Candidate · 17:03** (turn 42)

That's 3.36 points of revenue.

But COGS went up 16 points total, so beans only explain about 3.4 of that. So something else in COGS moved too — milk, cups, pastries, waste maybe.

Do we have the price changes on the other inputs?

**Interviewer · 17:05** (turn 43)

Here's the other input cost changes. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 18:14** (turn 44)

Okay, so other inputs were 75% of COGS, so 75% of 42 is 31.5% of revenue.

And they're up 37.5%, so... 31.5 plus 37.5 is 69% of revenue.

Hmm, that can't be right, that's bigger than total COGS. Sorry — I keep doing that same thing. I think it should be 31.5 times 1.375, which is about 43.3, so up about 11.8 points.

So 3.36 plus 11.8 is about 15.2 points, and COGS went up 16. So input cost inflation explains basically the whole thing.

Am I on the right track?

**Interviewer · 18:16** (turn 45)

You caught the units yourself that time. So input inflation explains nearly all of the COGS jump. Now — do you have the menu prices I promised?

Here's the menu price change over the two years.

**Candidate · 19:19** (turn 46)

I don't think I actually see a number there — did it come through?

If not, I'll assume menu prices were roughly flat. That would fit, actually: revenue grew 15% with the same 200 stores, so that's probably volume or mix, not price. And if they never passed any of the 40% bean increase through to customers, the whole input inflation hit lands on margin.

So the story is: costs inflated, prices didn't move.

Is that where you wanted me to land?

**Interviewer · 19:20** (turn 47)

Here's the menu price data. We don't have that specific cut. How would you approach it with what's available?

**Candidate · 20:51** (turn 48)

Um, okay. I'd back into it. Revenue grew 15% with the same 200 stores. If I assume prices were flat, all of that is volume or mix.

And COGS went from 42% of revenue to 58% of revenue — those are shares of revenue, so if prices had gone up, the COGS share would have fallen, not risen. The fact that it rose 16 points while inputs rose roughly 38-40% suggests they passed through basically nothing.

So: prices flat, costs up, margin absorbed all of it.

Sorry, is that a fair way to get there?

**Interviewer · 20:53** (turn 49)

That's a defensible read. Now let's shift — beyond raising menu prices, what else could the client do to reverse the margin decline? We'll stop there. Thanks for working through the case.
