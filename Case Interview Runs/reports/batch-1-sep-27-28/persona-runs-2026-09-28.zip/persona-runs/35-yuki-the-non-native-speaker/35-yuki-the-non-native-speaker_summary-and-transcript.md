# Live run — Brew & Bean Profitability

- Session: `9a873577-d805-4f5f-afee-990321eab5bb` · case `prof-001` · status **completed** · 2026-09-28
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **35. Yuki — the Non-Native Speaker**
- Tests: Rule 13 stall triggers (linguistic hesitation is not analytical stalling) and the judge's Communication dimension: fluency must not be scored as reasoning quality. A rescue here is a fail.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `menu_price_change`, `non_bean_input_change`, `bean_share_of_cogs`, `bean_price_change`
- Force-released before the recommendation ask: none
- Scoring QA: `{"artifactTypes":[],"gapClaimDrops":4,"verifierDrops":0,"evidenceStrips":0,"dataRequestGaps":0,"reconcileMerges":1,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":3,"crossDimensionRepeats":0,"dataRequestsNotInCase":2}`
- Assists / interventions: load_shed@21

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | refuse | — | breakdown of new versus existing store openings in the last two years | no |
| 5 | release | cogs_pct, labor_pct, overhead_pct | Cost of goods, labor, rent, and overhead as percent of revenue, comparing two years ago versus now | yes |
| 7 | release | menu_price_change | Menu price history over the two-year period; whether Brew and Bean raised prices | no |
| 9 | none | bean_price_change | Bean cost per pound over the two-year period | no |
| 9 | none | — | COGS per transaction over the two-year period | no |
| 9 | release | menu_price_change | Menu price data over the two-year period | yes |
| 15 | release | non_bean_input_change | Breakdown of COGS changes for dairy, packaging, and food costs over the past two years | yes |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 11 | 85321 | 662 | $0.443 |
| data_request | 13 | 11098 | 1298 | $0.018 |
| coverage | 10 | 16807 | 880 | $0.021 |
| judge | 1 | 10971 | 3872 | $0.152 |
| verifier | 1 | 4918 | 498 | $0.037 |
| reconcile | 1 | 2468 | 649 | $0.029 |
| candidate simulator (claude-opus-5) | 11 | 27923 | 3526 | $0.228 |

- App cost (interviewer + scoring): **$0.70** · with simulator: **$0.93** · list prices, uncached
- Wall time: 20:06

## Feedback

**Top improvement:** Anchor your sizing in dollars and derive your pricing recommendation explicitly: quantify the ~$77M annual margin erosion (16 points on today's revenue) and show the SKU-level math behind the price increase rather than asserting a ~20% blanket figure — that turns a strong qualitative case into an airtight quantified one.

### Problem Structuring — strong
_Coverage caveat: Part of this dimension's evidence rested on data the candidate asked for but the interviewer never provided — that gap is attributed to session coverage, not counted against the candidate._
- ✅ Opened by restating the objective and immediately framing profit as revenue minus cost with a directional hypothesis before asking for data.
  > So this is — profit is revenue minus cost, and since revenue is going up, the problem is more likely on cost side. But I should still check revenue quality.
- ✅ Broke the problem into tailored, coffee-specific sub-buckets across revenue (volume/price/mix) and cost (variable inputs, fixed overhead).
  > First, revenue: is the growth coming from more store, more customer, or price?
  > Variable would be coffee bean, milk, cup, and labor per hour. Fixed would be rent, salary of manager, corporate overhead, and marketing.
- ✅ When challenged on MECE, added genuinely missing dimensions — below-the-line items and mix — rather than reshuffling.
  > Net margin is after these, so it can fall even if operating is fine. So I should add financing and tax as separate bucket.
  > I should also add mix. Maybe they sell more of the cheap item, like drip coffee, less of the high margin one

### Quantitative & Analytical Rigor — strong
_Coverage caveat: Part of this dimension's evidence rested on data the candidate asked for but the interviewer never provided — that gap is attributed to session coverage, not counted against the candidate._
- ✅ Correctly decomposed the bean contribution using proper nested-percentage conversion from share-of-COGS to points of revenue.
  > Bean is twenty-five percent of that, so 0.25 times 42 equals 10.5 point of revenue.
  > So bean explain only 4.2 of 16 — about twenty-six percent. Three quarter of the problem is somewhere else.
- ✅ The candidate's margin computations were accurate and the pieces were cross-checked to reconcile with the exhibit totals, but the candidate never sized the actual dollar margin impact and some per-store math was off — anchor sizing in dollars where possible.
  > So increase from other input is 11.8 point. And bean was 4.2. Together 4.2 plus 11.8 equal 16 point. And 14.7 plus 43.3 equal 58. That match the exhibit exactly.
  > That is why — sorry, can I ask — do we have the bean cost per pound, or COGS per transaction, over the same period?
- ✅ Set up the per-cup index cleanly to derive the ~38% input inflation figure with stated approach before computing.
  > If I index revenue per cup at 100 two years ago, COGS per cup is 42... COGS is 58. So the material cost per cup rise by 16 on a base of 42 — that is about thirty-eight percent increase in input cost.

### Data & Exhibit Interpretation — strong
- ✅ Read the cost exhibit systematically, isolated COGS as the driver, and quantified its share of the total decline.
  > Labor is flat, twenty-two percent all three year. Overhead move twelve to fourteen, so two point up, small. COGS go forty-two, fifty, fifty-eight — that is sixteen point increase.
  > So COGS explain sixteen of eighteen, almost ninety percent. That is clearly the driver.
- ✅ Noticed the smooth year-over-year progression as a signal distinguishing structural inflation from a one-time shock.
  > And it's steady, eight point each year, not one shock.
- ✅ Caught the interviewer presenting the wrong exhibit and flagged it rather than mis-reading it.
  > I think that is the same cost exhibit again, not the price one — but okay, I don't want to stuck here.

### Business Judgment & Insight — strong
- ✅ Correctly reasoned that procurement alone cannot offset a ~40% commodity move, so pricing must carry most of the recovery.
  > So the fix must be mostly on price, not only on procurement, because procurement cannot undo a forty percent commodity move.
- ✅ Surfaced the elasticity risk of raising price given growth had been volume-driven, and proposed a pilot to mitigate.
  > Risk: volume loss, since growth was all volume, not price. So I test in ten, twenty store first and measure elasticity.
- ✅ Recognized which levers were and weren't worth attacking, noting labor was already lean and overhead offered only marginal gains.
  > Labor is flat at twenty-two so it is not broken
  > Realistically though, these give maybe five, six point. Price must carry the rest.
- 💡 The candidate recommended a targeted price increase but defaulted to a roughly uniform ~20% before nuancing; a sharper read would lead with SKU-level elasticity.
  > Better: I'd take the largest increases on high-margin specialty and alternative-milk drinks where demand is least elastic, and protect the entry-level drip that anchors traffic — beans are only a quarter of the problem, so pricing has to be surgical, not blanket.

### Creativity & Brainstorming — strong
_Coverage caveat: Part of this dimension's evidence rested on data the candidate asked for but the interviewer never provided — that gap is attributed to session coverage, not counted against the candidate._
- ✅ Organized the brainstorm into four clean, non-overlapping levers before listing ideas.
  > Let me structure in four lever, outside of price.
  > First, procurement... Second, product cost engineering... Third, mix... Fourth, the non-COGS line.
- ✅ Included non-obvious ideas like alternative-milk surcharges and drink reformulation to shift toward lower-input-cost products.
  > And if oat milk is the problem, add a surcharge, which is technically price but it is mix too.
  > Also reformulate: push the drink that use less of the expensive input.

### Synthesis & Recommendation — strong
_Coverage caveat: Part of this dimension's evidence rested on data the candidate asked for but the interviewer never provided — that gap is attributed to session coverage, not counted against the candidate._
- ✅ Led answer-first with a committed, specific recommendation and timing.
  > My recommendation: Brew and Bean should raise menu price, on a targeted basis, this quarter — that is the only lever big enough to close the gap.
- ✅ Supported the recommendation with the quantified decomposition, named the elasticity risk, and gave concrete next steps.
  > Inside that, bean give 4.2 point and all other input give 11.8 point. So it is not a supplier problem, it is broad input inflation
  > Next step: two week price test, plus parallel procurement and waste workstream to capture five, six point more.

### Communication & Delivery — strong
- ✅ Consistently signposted and narrated structure before diving into detail throughout the case.
  > Let me structure in four lever, outside of price.
  > Let me check this against the numbers.
- ✅ Used hypothesis-driven, top-down phrasing and confirmed understanding before proceeding.
  > So my hypothesis: input cost inflation — bean, milk, maybe cup — absorbed fully by the company.
  > let me repeat back first, to be sure I understand.

### Pushback, Composure & Case Leadership — strong
- ✅ Responded to the MECE challenge substantively by identifying two real gaps rather than becoming defensive or reflexively agreeing.
  > First, I said cost is fixed and variable, but I forget the — how to say — the things below operating line.
  > Is that more complete, or you see another gap?
- ✅ Handled the wrong-exhibit confusion with composure, made a reasoned assumption to keep momentum, and validated it when correct data arrived.
  > I make an assumption and keep going: I assume menu price stayed roughly flat
  > Okay, good — that confirm my assumption, so I feel comfortable.
- ✅ Drove the case forward proactively, repeatedly proposing the next data pull and next analytical step.
  > Then I would decompose: how much of the sixteen point is pure price of input, how much is mix shift, how much is waste.
  > Do we have the split?

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

How would you like to approach this? Feel free to take a moment to gather your thoughts first.

**Candidate · 1:55** (turn 1)

Okay. So, let me repeat back first, to be sure I understand. Brew & Bean, 200 store, revenue is growing fifteen percent, but net margin fall from 24 to 6. So this is — profit is revenue minus cost, and since revenue is going up, the problem is more likely on cost side. But I should still check revenue quality.

My approach, I break in two branch. First, revenue: is the growth coming from more store, more customer, or price? Because if we open many new store, new store maybe not profitable yet, and that drag the margin. Second, cost: I split fixed and variable. Variable would be coffee bean, milk, cup, and labor per hour. Fixed would be rent, salary of manager, corporate overhead, and marketing.

Can I ask — do we know how many of the 200 locations are new, opened in last two years?

**Interviewer · 1:58** (turn 2)

That's a fair scoping question. I don't have a breakdown of new versus existing store openings.

Before we dig in, is your framework MECE — what's missing?

**Candidate · 3:41** (turn 3)

Okay. Let me think what is missing.

I think... two thing. First, I said cost is fixed and variable, but I forget the — how to say — the things below operating line. Interest, if they take debt to expand, and tax. Net margin is after these, so it can fall even if operating is fine. So I should add financing and tax as separate bucket.

Second, is not really missing but — inside revenue I only said volume and price. I should also add mix. Maybe they sell more of the cheap item, like drip coffee, less of the high margin one, like latte or food. That change margin without change total revenue.

And then external context, sitting over everything — competitor, input price like coffee bean commodity, wage regulation. That is not a bucket exactly, it's more the driver behind the buckets.

Is that more complete, or you see another gap?

**Interviewer · 3:42** (turn 4)

That's more complete. Where would you start digging first, and why?

**Candidate · 5:28** (turn 5)

I start on cost side, and specifically I want the cost as percent of revenue, two years ago versus now.

The reason — the drop is very big, eighteen point of margin. Revenue grow fifteen percent, so if price and volume were both fine, some cost line must expand a lot in relative term. And if I get the percentage breakdown for both year, I can immediately see which line move, instead of guessing one by one. It's the fastest way to narrow.

So do we have that — cost of goods, labor, rent, overhead, as percent of revenue, then and now?

And after I find the big mover, I would ask what is inside it. For example if it's COGS, is it bean price up, or waste, or mix.

**Interviewer · 5:30** (turn 6)

I have a cost structure exhibit that covers exactly that. Take a look.

**Candidate · 7:16** (turn 7)

Okay, so I read the exhibit. Labor is flat, twenty-two percent all three year. Overhead move twelve to fourteen, so two point up, small. COGS go forty-two, fifty, fifty-eight — that is sixteen point increase. And total margin fall eighteen point. So COGS explain sixteen of eighteen, almost ninety percent. That is clearly the driver.

And it's steady, eight point each year, not one shock.

So now I want to go inside COGS. Two big possibility. One, input cost per unit go up — coffee bean is a commodity, price can move a lot, also milk, also packaging. Two, the price they charge did not go up, so even same bean cost, the ratio get worse.

That is why — sorry, can I ask — do we have the menu price history? Did Brew and Bean raise price in these two years?

**Interviewer · 7:17** (turn 8)

Here's the menu price history.

**Candidate · 8:48** (turn 9)

I think that is the same cost exhibit again, not the price one — but okay, I don't want to stuck here. I make an assumption and keep going: I assume menu price stayed roughly flat, because if they had raised price meaningfully, COGS as percent of revenue would not climb so smoothly every year.

So under that assumption — revenue grew fifteen percent over two year, which is modest, and labor stay exactly twenty-two percent. That is actually a clue. Labor flat means volume and price move together in normal way; labor usually scale with transaction. But COGS jump sixteen point. So the cost per cup of the material go up, and it was not passed to customer.

So my hypothesis: input cost inflation — bean, milk, maybe cup — absorbed fully by the company.

Do we have the bean cost per pound, or COGS per transaction, over the same period?

**Interviewer · 8:50** (turn 10)

Let me correct one thing — I have the menu price data. Here it is. Menu prices have not changed in two years.

**Candidate · 10:20** (turn 11)

Okay, good — that confirm my assumption, so I feel comfortable.

Let me try quantify. If I index revenue per cup at 100 two years ago, COGS per cup is 42. Price is flat, so revenue per cup is still 100 today, but COGS is 58. So the material cost per cup rise by 16 on a base of 42 — that is about thirty-eight percent increase in input cost. That is big but plausible for coffee bean and dairy in two year.

And it tell me revenue growth of fifteen percent came from volume, not price, because price is flat. So they sell more cup, at worse and worse margin per cup. Growth is actually making it a bit worse, unless — sorry, unless fixed cost leverage help, but overhead went up not down, so no.

So the root cause: input cost inflation, fully absorbed, zero price pass-through for two years.

Do you want me go to recommendation now?

**Interviewer · 10:22** (turn 12)

Before that — let's isolate what inside COGS actually moved. What data would you pull?

**Candidate · 12:07** (turn 13)

I would pull the COGS split by line item, for both year, per unit. So:

One, green coffee bean — cost per pound, and how many pound per cup, because waste can change too.

Two, dairy — milk, cream, and alternative milk like oat, almond. Those alternative are much more expensive, and if customer shift to them and the store do not charge enough surcharge, that raise COGS with no price change.

Three, packaging — cup, lid, sleeve, straw.

Four, food and pastry, if they sell food. Food margin is usually worse than drink, so if food become bigger part of mix, blended COGS go up.

Five, waste and spoilage rate, and any theft or free-drink policy.

Then I would decompose: how much of the sixteen point is pure price of input, how much is mix shift, how much is waste. Because the fix is different — for input price you negotiate or hedge or raise menu price, for mix you reprice the oat milk, for waste you fix operation.

Do we have the split?

**Interviewer · 12:09** (turn 14)

Let's start with the bean piece. Here's the share of COGS and the bean price change. Coffee beans were 25% of COGS two years ago. Raw coffee bean costs are up 40% over the past two years.

**Candidate · 14:00** (turn 15)

Let me compute.

Two years ago COGS is 42 point of revenue. Bean is twenty-five percent of that, so 0.25 times 42 equals 10.5 point of revenue.

Bean price up forty percent, and volume per cup same, price flat — so bean become 10.5 times 1.4, equal 14.7 point. So the increase from bean is 14.7 minus 10.5, that is 4.2 point.

But total COGS increase is sixteen point. So bean explain only 4.2 of 16 — about twenty-six percent. Three quarter of the problem is somewhere else.

That is important. If we only hedge the bean, we recover four point of margin, we go from six to ten. Not back to twenty-four.

So the remaining almost twelve point must sit in dairy, packaging, food mix, or waste. My instinct is the alternative milk mix and the food, because those move quietly. Can we see the dairy and food lines?

**Interviewer · 14:02** (turn 16)

Here's the other input cost data. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 15:52** (turn 17)

Let me check this against the numbers.

Other input is the remaining seventy-five percent of COGS. So 0.75 times 42 equals 31.5 point of revenue two years ago.

Up 37.5 percent: 31.5 times 1.375. Let me do it — 31.5 plus 31.5 times 0.375. 31.5 times 0.375 is about 11.8. So new is 43.3 point.

So increase from other input is 11.8 point. And bean was 4.2. Together 4.2 plus 11.8 equal 16 point. And 14.7 plus 43.3 equal 58. That match the exhibit exactly.

So now the picture is complete and it is simple: every input line inflate roughly thirty-eight, forty percent, and menu price did not move at all. It is not one bad supplier, it is broad input inflation with zero pass-through. So the fix must be mostly on price, not only on procurement, because procurement cannot undo a forty percent commodity move.

Should I go to the recommendation?

**Interviewer · 15:54** (turn 18)

Beyond pricing, what else could the client do to recover margin? Give me a structured set.

**Candidate · 17:24** (turn 19)

Okay. Let me structure in four lever, outside of price.

First, procurement. Long-term contract or hedging on bean, so they are not exposed to spot. Consolidate volume across 200 store for better term. Second source for dairy and packaging. Maybe re-spec the cup, cheaper lid.

Second, product cost engineering. Portion control — grams of bean per shot, how much milk in each size. Reduce waste and spoilage, especially pastry that expire. Also reformulate: push the drink that use less of the expensive input.

Third, mix. Actively steer customer to high-margin item — drip coffee, or the drink with less dairy. Bundle, loyalty reward on those. And if oat milk is the problem, add a surcharge, which is technically price but it is mix too.

Fourth, the non-COGS line. Overhead went twelve to fourteen, that is two point, worth attacking — corporate cost, marketing efficiency. Labor is flat at twenty-two so it is not broken, but scheduling optimization could still give some.

Realistically though, these give maybe five, six point. Price must carry the rest.

**Interviewer · 17:26** (turn 20)

Now give me your recommendation to the CEO.

**Candidate · 18:56** (turn 21)

My recommendation: Brew and Bean should raise menu price, on a targeted basis, this quarter — that is the only lever big enough to close the gap.

The reason. Margin fall eighteen point, and COGS explain sixteen of it. Inside that, bean give 4.2 point and all other input give 11.8 point. So it is not a supplier problem, it is broad input inflation of roughly forty percent, and menu price has not moved in two year. Even perfect procurement cannot recover forty percent commodity move.

Sizing: to get COGS from 58 back to about 45 point, we need roughly twenty percent price increase. I would not do it flat — do it by item and by market, protect the entry drink, take more on the specialty and the alternative milk.

Risk: volume loss, since growth was all volume, not price. So I test in ten, twenty store first and measure elasticity.

Next step: two week price test, plus parallel procurement and waste workstream to capture five, six point more.

**Interviewer · 18:59** (turn 22)

That's a complete recommendation. We'll stop there — a full written report will follow.

Thanks for working through this. That's the end of the case.
