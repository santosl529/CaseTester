# Live run — Brew & Bean Profitability

- Session: `c95b8e6a-3e5f-4ca5-8300-763920c8395a` · case `prof-001` · status **completed** · 2026-09-30
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **3. Ines — the Clarifier**
- Tests: Rule 13 clarifying-question budget (N=2 default): tests whether a legitimately thorough candidate trips the ladder. If she does, N is too low or the quality guard is needed after all.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `stores_count`, `cogs_pct`, `labor_pct`, `bean_share_of_cogs`, `bean_price_change`, `non_bean_input_change`, `overhead_pct`, `menu_price_change`
- Force-released before the recommendation ask: `[{"phase":"BRAINSTORM","itemIds":["menu_price_change"],"trigger":"model_ask"}]`
- Scoring QA: `{"caveatFloors":0,"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"markClaimDrops":0,"dataRequestGaps":0,"reconcileMerges":0,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":0,"dataRequestsNotInCase":5,"interviewerErrorMarks":0}`
- Assists / interventions: load_shed@27

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | refuse | — | Store-level breakdown of net profit margin decline (whether concentrated in subset of stores or chain-wide) | no |
| 3 | release | stores_count | Whether store count changed over the two-year period | yes |
| 5 | refuse | — | Whether the business model or format changed, including additions like food, delivery/app channels, shifts in hours, or new product lines | no |
| 7 | none | cogs_pct, labor_pct, overhead_pct | P&L as a percent of revenue for both years to identify which line item moved | no |
| 9 | clarify | cogs_pct, labor_pct, overhead_pct | Full P&L statement as a percent of revenue for both years (current and two years ago), including all operating and non-operating line items | no |
| 11 | release | — | Definition and composition of COGS at Brew & Bean — whether it includes in-store labor or only product costs (beans, dairy, cups, syrups) | no |
| 13 | release | bean_share_of_cogs, non_bean_input_change | COGS breakdown by input type (coffee beans, dairy, cups/packaging) | no |
| 15 | none | menu_price_change | Menu price history over the two years | no |
| 15 | none | bean_share_of_cogs | Bean share of COGS today (current year) | yes |
| 17 | none | bean_share_of_cogs | Coffee beans as a share of COGS today | yes |
| 19 | release | non_bean_input_change | Cost changes for dairy, packaging, and food inputs over the past two years | yes |
| 21 | refuse | menu_price_change | History of price increases and their impact on customer traffic / price sensitivity | no |
| 23 | refuse | — | Constraints on menu pricing (franchise agreements, contracts, or brand positioning limits) | no |
| 25 | refuse | — | CEO's target margin and timeframe for recovery | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 14 | 108566 | 939 | $0.566 |
| data_request | 14 | 11439 | 1123 | $0.017 |
| coverage | 13 | 22519 | 1018 | $0.028 |
| judge | 1 | 11713 | 3723 | $0.152 |
| verifier | 1 | 5500 | 337 | $0.036 |
| reconcile | 1 | 2205 | 493 | $0.023 |
| candidate simulator (claude-opus-5) | 14 | 35054 | 4025 | $0.276 |

- App cost (interviewer + scoring): **$0.82** · with simulator: **$1.10** · list prices, uncached
- Wall time: 20:04

## Feedback

**Top improvement:** Tighten the sizing logic behind the price recommendation: rather than anchoring on the ~38% needed to fully restore COGS-to-revenue and then phasing arbitrarily, model the near-term margin impact of a targeted increase directly (input costs are fixed short-term, so most of a price rise drops to margin) and concentrate it on low-elasticity specialty SKUs — this converts an already-strong recommendation into a precisely quantified one.

### Problem Structuring — strong
- ✅ Restated the situation and prioritized where the answer likely lives before diving in, tying the weighting to the arithmetic.
  > Since revenue is up 15% on a flat footprint and margin fell 18 points, the arithmetic says costs grew much faster than revenue — so I'd weight the cost side, but I'd still verify revenue quality first.
- ✅ Laid out clean, tailored, non-overlapping buckets with sub-points specific to a coffee chain.
  > Costs: I'd split fixed versus variable. Variable — coffee beans, milk, cups, and store labor hours. Fixed — rent, salaried management, corporate overhead, marketing.
  > Revenue: price versus volume. Did the 15% come from more transactions, or from raising menu prices?
- ✅ Closed the MECE gap intelligently when challenged, adding the below-the-line branch and flagging a double-count risk.
  > I'm missing everything below it: interest expense... plus depreciation and amortization, taxes, and any one-time or non-recurring charges
  > discounts technically sit in revenue as net price realization, so I want to be careful not to double-count them

### Quantitative & Analytical Rigor — strong
- ✅ Correctly performed the nested-percentage conversion from share-of-COGS to points-of-revenue, the case's core math trap.
  > beans were 25% of that, so beans = 0.25 × 42 = 10.5% of revenue. Everything else in COGS was 42 − 10.5 = 31.5% of revenue.
- ✅ Set up a benchmark test first, then computed the bean contribution accurately and interpreted its magnitude relative to the problem.
  > beans become 10.5 × 1.4 = 14.7% of revenue. That's a 4.2-point increase — real, but only about a quarter of the 16-point COGS move.
- ✅ Reconciled the full COGS move cleanly, closing to exactly 16 points and drawing the implication that revenue growth was volume-driven.
  > Non-bean inputs were 31.5% of revenue; up 37.5% gives 31.5 × 1.375 = 43.3%, an 11.8-point increase. Add the 4.2 points from beans and I get 16.0 points — exactly the COGS move.
- ⚠️ The recommendation sized the price increase off a full COGS restoration to 42%, which conflates restoring COGS-as-a-share with margin recovery and glosses that a 38% price rise would also change volume and mix; the 10-12% phased figure is reasonable but the '38% to restore' anchor is a crude framing.
  > to restore COGS to 42% of revenue on today's cost base, we'd need roughly a 38% price increase, which is too steep at once
- 💡 When sizing the recommended price move in turn 27, the candidate anchored on '38% to fully restore' then arbitrarily phased to 10-12% for '6 points of margin'.
  > Better: A cleaner size: a ~10% price increase on today's revenue base drops nearly straight to the bottom line since input costs are fixed in the near term, recovering roughly 10 points of margin — but I'd model realistic elasticity so net traffic loss doesn't erode that, and target high-margin, less-elastic specialty SKUs rather than a blanket rise.

### Data & Exhibit Interpretation — strong
- ✅ Immediately isolated COGS as the driver the moment the cost lines were revealed, quantifying its dominance.
  > That's the story right there — 16 of the 18 points sit in COGS, so the other two operating lines are almost a rounding error by comparison.
- ✅ Tested whether a single input could explain the whole move rather than stopping at the bean spike, exactly the strong-candidate behavior.
  > So coffee inflation is a contributor, not the root cause. There are roughly 12 points unexplained sitting in dairy, cups, and food. What did those inputs do?
- ✅ Read the exhibit systematically for shape and trajectory, extracting that this was steady inflation not a one-time shock.
  > it's a steady two-year bleed, not a one-time shock — 42 to 50 to 58 — which tells me this is ongoing inflation management, not a single bad contract

### Business Judgment & Insight — strong
- ✅ Proactively scoped whether pricing was even a permissible lever before building a recommendation on it.
  > is there any constraint on pricing I should know about — franchise agreements, contracts, or a brand positioning the CEO won't move on?
- ✅ Named the key commercial risk (no elasticity data) and paired it with a concrete, low-risk mitigation.
  > no elasticity data, so a step change could break traffic — test in 20 stores first
- ✅ Surfaced the competitive-context angle and the overhead creep as a distinct, actionable pool of margin.
  > competitors may have already priced up, which would mean we're under-market
  > reverse the overhead creep — 12 to 14 points is 2 points of margin sitting in corporate, unrelated to inflation
- 💡 At turn 25/27 the candidate recommended raising prices broadly and phasing, but never distinguished elastic vs. inelastic SKUs.
  > Better: I'd concentrate the increase on high-margin specialty drinks where demand is least elastic and hold or barely move commodity drip, protecting traffic while capturing the most margin.

### Creativity & Brainstorming — strong
_Coverage caveat: The brainstorm was administered but compressed during the recommendation phase under time pressure; the rating reflects the solid structured breadth the candidate produced in that window._
- ✅ Organized the brainstorm into explicit buckets before listing ideas.
  > Three buckets beyond price.
  > Two, cost avoidance inside the same inputs.
- ✅ Produced diverse ideas including non-obvious ones tied to the specific cost driver.
  > Push high-margin items — food attach, drip coffee over milk-heavy espresso drinks, since dairy is in the inflating basket
  > Lock in forward contracts or hedge green coffee rather than buying spot, which is likely what exposed them

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a committed, specific recommendation.
  > My recommendation: Brew & Bean should raise menu prices, phased, and pair it with supplier renegotiation.
- ✅ Supported the conclusion with the reconciled math and named a clear insight about why margin fell.
  > Margin didn't fall because the business got worse — it fell because roughly 38% input inflation was absorbed entirely by the P&L over two years while menu prices sat flat.
- ✅ Included risks and concrete next steps within a tight structure.
  > Risks: no elasticity data, so a step change could break traffic — test in 20 stores first.
  > Next steps: price test, supplier renegotiation, hedge green coffee, and audit the overhead creep from 12 to 14.

### Communication & Delivery — strong
- ✅ Consistently top-down and signposted, stating structure before detail.
  > Two branches.
  > Three buckets beyond price.
- ✅ Used hypothesis-driven phrasing throughout, tying each data request to a decision.
  > my hypothesis is COGS inflation or wage inflation
  > A single-input spike points to sourcing or hedging; broad inflation points to pricing.
- ✅ Handled a mid-calculation correction cleanly without losing composure or the thread.
  > Sorry, I was getting ahead of myself — let me redo it cleanly.

### Pushback, Composure & Case Leadership — strong
- ✅ Responded to the MECE challenge by genuinely improving the structure rather than caving or defending rigidly.
  > Fair challenge. Since we're measuring net margin, not operating margin, my two branches only cover the operating line.
- ✅ When challenged on the units of the number, acknowledged and re-derived cleanly rather than bluffing.
  > Sorry, I was getting ahead of myself — let me redo it cleanly.
  > For beans alone to explain all 16 points, beans today would need to be 10.5 + 16 = 26.5% of revenue.
- ✅ Drove the case forward proactively, repeatedly proposing the next data need tied to a hypothesis.
  > What did those inputs do?
  > do we know how price-sensitive the customer is — any history of a price increase and what happened to traffic?

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a moment, then walk me through how you'd approach this.

**Candidate · 0:56** (turn 1)

Before I lay out a structure, I want to make sure I understand the situation. When you say net profit margin fell from 24% to 6% — is that a chain-wide average, or is the decline concentrated in a subset of the 200 locations? I ask because if it's, say, the newer stores dragging down a healthy base, that's a very different problem from a cost shock hitting every store equally.

**Interviewer · 0:57** (turn 2)

That's a chain-wide average; I don't have a store-level cut of margin. Go on — what else do you want to clarify?

**Candidate · 1:55** (turn 3)

Got it — I'll treat it as broadly chain-wide then.

Second question: over these two years, has the store count changed? Revenue grew 15%, and I want to know whether that came from opening new locations or from existing stores selling more. A 15% top-line built on, say, 30 new stores would imply same-store revenue is actually flat or down, and it would also bring a wave of new fixed costs and buildout expense.

**Interviewer · 1:57** (turn 4)

Here's the store count over the period: 200 stores today — and it was 200 stores two years ago, so the footprint hasn’t changed.

**Candidate · 3:19** (turn 5)

That's helpful — so it's all same-store growth, and the fixed footprint means rent and store-level overhead shouldn't have jumped from expansion. That points me toward either pricing/mix on the revenue side or cost inflation.

Third question: has the business model or format changed at all over these two years? I'm thinking things like adding food or a delivery/app channel, shifting hours, or moving into a new product line. A 15% same-store revenue lift usually has a story behind it, and if the growth came from a structurally lower-margin channel — delivery with platform fees, for instance — the margin decline could be a mix problem rather than a cost problem.

**Interviewer · 3:22** (turn 6)

No major format or channel change; assume the same business model. Let's get into it — walk me through how you'd structure this problem.

**Candidate · 4:52** (turn 7)

Okay. Since revenue is up 15% on a flat footprint and margin fell 18 points, the arithmetic says costs grew much faster than revenue — so I'd weight the cost side, but I'd still verify revenue quality first.

Two branches.

Revenue: price versus volume. Did the 15% come from more transactions, or from raising menu prices? That matters because a price-driven lift with flat volume can mask falling traffic, and a volume-driven lift means we're selling more units at a squeezed unit margin.

Costs: I'd split fixed versus variable. Variable — coffee beans, milk, cups, and store labor hours. Fixed — rent, salaried management, corporate overhead, marketing. With 200 stores constant, I'd expect rent to be fairly stable, so my hypothesis is COGS inflation or wage inflation.

To start: do we have the P&L as a percent of revenue for both years, so I can see which line moved?

**Interviewer · 4:53** (turn 8)

Is that structure MECE — what's missing from those two branches?

**Candidate · 6:23** (turn 9)

Fair challenge. Since we're measuring net margin, not operating margin, my two branches only cover the operating line. I'm missing everything below it: interest expense — if they took on debt, say for remodels or working capital, that hits net directly — plus depreciation and amortization, taxes, and any one-time or non-recurring charges like an impairment or a legal settlement. An 18-point swing is large enough that a below-the-line item could be a real contributor.

I'd also flag that "costs" should include shrink, waste, and discounting — discounts technically sit in revenue as net price realization, so I want to be careful not to double-count them.

So: revenue quality, operating costs fixed versus variable, and non-operating items. Can I see the P&L as a percent of revenue for both years?

**Interviewer · 6:25** (turn 10)

Here's the cost structure as a share of revenue. I'll give you the three operating lines. COGS is 58% of revenue today, up from 42% two years ago.

**Candidate · 7:28** (turn 11)

That's the story right there — 16 of the 18 points sit in COGS, so the other two operating lines are almost a rounding error by comparison.

Before I start diagnosing, a scoping question on that line: what sits inside COGS for Brew & Bean? Specifically, does it include in-store labor, or is this purely product cost — beans, dairy, cups, syrups? Coffee chains split that differently, and whether I'm chasing commodity inflation or wage inflation depends entirely on the answer.

**Interviewer · 7:30** (turn 12)

Treat COGS as product cost only — beans, dairy, cups, food. Labor sits in its own line. What do you want next? Labor is 22% of revenue, and it’s been stable.

**Candidate · 8:33** (turn 13)

Good — labor stable at 22% confirms it's a product-cost problem, not a wage problem.

Next scoping question: do we have a split of that COGS line by input — roughly what share is green coffee beans versus dairy versus cups and packaging? I want to know whether one input drove the whole 16 points or whether it's broad-based inflation across the basket, because the fix is very different. A single-input spike points to sourcing or hedging; broad inflation points to pricing.

**Interviewer · 8:35** (turn 14)

Here's the COGS breakdown by input. First, beans: Coffee beans were 25% of COGS two years ago.

**Candidate · 10:06** (turn 15)

So two years ago beans were 25% of a 42% COGS line — that's 0.25 × 42 = 10.5% of revenue going to green coffee.

What's the bean share of COGS today? If beans are now, say, 50% of a 58% COGS line, that's 29% of revenue — a 19-point swing, which would more than account for the entire COGS increase on its own and mean dairy and packaging were actually flat or down as a share.

And one more thing I'd want alongside it: do we have the menu-price history over the two years? If bean costs spiked and Brew & Bean held prices flat, that's the whole margin story, and it also tells me how much pricing headroom we have left.

**Interviewer · 10:08** (turn 16)

Points of what — you said beans were ten and a half percent of revenue; walk me through where that lands versus the sixteen-point COGS move.

**Candidate · 11:38** (turn 17)

Sorry, I was getting ahead of myself — let me redo it cleanly.

Two years ago: COGS was 42% of revenue, beans were 25% of that, so beans = 0.25 × 42 = 10.5% of revenue. Everything else in COGS was 42 − 10.5 = 31.5% of revenue.

Today COGS is 58% of revenue, so the total move is 16 points of revenue.

For beans alone to explain all 16 points, beans today would need to be 10.5 + 16 = 26.5% of revenue. As a share of today's COGS, that's 26.5 ÷ 58 ≈ 46%.

So the test is simple: if beans are now roughly 46% of COGS, commodity coffee is the entire story and the other inputs held flat. If they're meaningfully below that, something else — dairy or packaging — is contributing too. What's the bean share today?

**Interviewer · 11:40** (turn 18)

Here's the rest of the COGS breakdown — bean price change and the other inputs. I'll give you the bean price move first, then the non-bean inputs. Raw coffee bean costs are up 40% over the past two years.

**Candidate · 13:00** (turn 19)

Let me test that against my benchmark. If beans were 10.5% of revenue and the input price rose 40%, then holding menu prices and mix constant, beans become 10.5 × 1.4 = 14.7% of revenue. That's a 4.2-point increase — real, but only about a quarter of the 16-point COGS move.

And that's the generous version. If some of the 15% revenue growth came from higher menu prices, the denominator is bigger and beans would land even lower as a share.

So coffee inflation is a contributor, not the root cause. There are roughly 12 points unexplained sitting in dairy, cups, and food. What did those inputs do?

**Interviewer · 13:02** (turn 20)

Here's what the other inputs did — dairy, packaging, and food. Here you go: Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 14:32** (turn 21)

That closes the gap. Non-bean inputs were 31.5% of revenue; up 37.5% gives 31.5 × 1.375 = 43.3%, an 11.8-point increase. Add the 4.2 points from beans and I get 16.0 points — exactly the COGS move.

That's a clean reconciliation, and it carries an important implication: the arithmetic only works if the revenue denominator didn't get inflated by price. So menu prices have been essentially flat, and the entire 15% revenue growth is volume — more transactions, or bigger tickets by unit, not by price. Brew & Bean has absorbed roughly 38% broad-based input inflation without passing any of it through.

Before I recommend: do we know how price-sensitive the customer is — any history of a price increase and what happened to traffic? For a specialty brand that's the key unknown.

**Interviewer · 14:35** (turn 22)

I don't have elasticity or a price-test history. Let me hand you the exhibit on the cost structure over time.

**Candidate · 15:56** (turn 23)

The exhibit confirms the shape: 18 points of margin lost, 16 from COGS and 2 from overhead creeping 12 to 14. Labor is the one disciplined line. And it's a steady two-year bleed, not a one-time shock — 42 to 50 to 58 — which tells me this is ongoing inflation management, not a single bad contract.

Two things before I commit to a recommendation.

First: is there any constraint on pricing I should know about — franchise agreements, contracts, or a brand positioning the CEO won't move on? I'd want to know whether price is actually a lever we're allowed to pull before I build a recommendation around it.

**Interviewer · 15:58** (turn 24)

No pricing constraint — price is on the table. Beyond pricing, what else could Brew and Bean do to rebuild margin? Give me a structured set of levers.

**Candidate · 17:29** (turn 25)

Three buckets beyond price.

One, input cost. Renegotiate supplier contracts and consolidate volume — 200 stores is real buying power. Lock in forward contracts or hedge green coffee rather than buying spot, which is likely what exposed them. Dual-source dairy and commoditize packaging away from branded cups.

Two, cost avoidance inside the same inputs. Reduce waste and shrink — brewed coffee dumped at end of day, spoiled milk. Right-size portions and standardize recipes. Audit free refills and comp policy.

Three, mix and revenue quality. Push high-margin items — food attach, drip coffee over milk-heavy espresso drinks, since dairy is in the inflating basket. Loyalty to drive attach rather than discount.

And reverse the overhead creep — 12 to 14 points is 2 points of margin sitting in corporate, unrelated to inflation.

One last thing before I recommend: does the CEO have a target margin and a timeframe? Whether we need 6 to 15 in a year or back to 24 eventually changes how aggressive I get on price.

**Interviewer · 17:32** (turn 26)

No stated target — assume the CEO wants meaningful margin recovery over a reasonable horizon. Before we wrap, on what you asked about earlier: Menu prices have not changed in two years. So give me your recommendation to the CEO.

**Candidate · 19:02** (turn 27)

My recommendation: Brew & Bean should raise menu prices, phased, and pair it with supplier renegotiation. Margin didn't fall because the business got worse — it fell because roughly 38% input inflation was absorbed entirely by the P&L over two years while menu prices sat flat.

The math: COGS went 42 to 58 points of revenue. Beans up 40% explains 4.2 points; dairy, packaging and food up 37.5% explains 11.8. That's all 16. Meanwhile volume grew 15% with no price increase — evidence demand is healthy and there's likely headroom.

Sizing it: to restore COGS to 42% of revenue on today's cost base, we'd need roughly a 38% price increase, which is too steep at once. I'd phase 10–12% now, targeting about 6 points of margin, then reassess.

Risks: no elasticity data, so a step change could break traffic — test in 20 stores first. And competitors may have already priced up, which would mean we're under-market.

Next steps: price test, supplier renegotiation, hedge green coffee, and audit the overhead creep from 12 to 14.

**Interviewer · 19:04** (turn 28)

Good — that's a complete recommendation. That's where we'll stop. Thank you for working through the case; a full written report with detailed feedback will follow.
