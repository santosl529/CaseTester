# Live run — Brew & Bean Profitability

- Session: `742a4870-0432-4fe2-a166-0c99bcd2f01b` · case `prof-001` · status **completed** · 2026-09-30
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **13. Micah — the Rounder**
- Tests: Rule 14 within-tolerance band as a false-positive test: estimation is a scored skill and must be accepted silently. If he gets probed, the tolerance is too tight.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `non_bean_input_change`, `menu_price_change`
- Force-released before the recommendation ask: none
- Scoring QA: `{"caveatFloors":0,"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"markClaimDrops":0,"dataRequestGaps":0,"reconcileMerges":2,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":0,"dataRequestsNotInCase":3,"interviewerErrorMarks":0}`
- Assists / interventions: none

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | defer | cogs_pct, labor_pct, overhead_pct | Cost breakdown as a percent of revenue for both years | no |
| 3 | release | cogs_pct, labor_pct, overhead_pct | Cost breakdown (COGS, labor, overhead) as a percent of revenue for both current year and two years ago | yes |
| 5 | release | bean_share_of_cogs, non_bean_input_change | COGS composition breakdown (beans, dairy, cups, food) and how each moved over two years | yes |
| 5 | release | menu_price_change | Menu price changes over the two-year period | no |
| 7 | release | menu_price_change | Whether menu prices have changed over the past two years | yes |
| 9 | none | — | Elasticity data or competitor pricing actions | no |
| 11 | refuse | — | Price elasticity data or demand sensitivity to price changes | no |
| 13 | none | — | Waste rates data to size the impact of waste reduction and portioning tightening | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 9 | 67915 | 705 | $0.357 |
| data_request | 9 | 7938 | 567 | $0.011 |
| coverage | 8 | 13172 | 1208 | $0.019 |
| judge | 1 | 10544 | 3496 | $0.140 |
| verifier | 1 | 4696 | 425 | $0.034 |
| reconcile | 1 | 2054 | 678 | $0.027 |
| candidate simulator (claude-opus-5) | 9 | 21732 | 3506 | $0.196 |

- App cost (interviewer + scoring): **$0.59** · with simulator: **$0.78** · list prices, uncached
- Wall time: 15:00

## Feedback

**Top improvement:** Sanity-check quantitative heuristics before asserting them out loud — the one-for-one price-to-COGS-share rule was stated confidently and only corrected under probing; running the two-line check first (raise price to 110, hold costs, recompute the share) would let you lead with the right relationship and preserve full credibility.

### Problem Structuring — strong
- ✅ Restated the objective/headline and immediately framed a top-level profit equation with prioritization toward costs.
  > So this isn't a demand problem on the top line; it's almost certainly costs, or a shift in revenue mix that carries worse economics.
  > I'd start on the cost side since that's where the swing likely is.
- ✅ Disaggregated both sides into tailored, non-overlapping sub-buckets fitting a coffee chain (stores × transactions × ticket; variable vs. fixed COGS/labor/overhead).
  > revenue = number of stores × transactions per store × average ticket
  > Variable: COGS — beans, dairy, cups — plus hourly labor and any delivery commission. Fixed: rent, salaried management, corporate SG&A, marketing, D&A on buildouts.
- ✅ When challenged on MECE, added external and non-operating factors, tightening coverage without overlap.
  > What I left out entirely: external factors. Commodity prices on coffee and dairy, wage legislation, competitive pricing pressure.
  > Also non-operating: interest expense if they levered up to fund expansion, and tax rate — net margin includes both.

### Quantitative & Analytical Rigor — strong
- ✅ Correctly decomposed margin drop into COGS vs. overhead contribution and quantified the COGS point move.
  > Margin fell 18 points, 24 to 6. COGS went up 16 points and overhead 2 — call it 16 of the 18 from COGS alone, so roughly 90% of the problem.
  > COGS rising from 42 to 58 is roughly a 38% increase in cost per dollar of revenue
- ✅ Executed the nested-percentage conversion correctly, deriving beans as points of revenue and the implied bean-price increase.
  > Beans were 25% of that — call it 10.5 points. Everything else is the other 75%, so about 31.5 points.
  > 31.5 × 1.375. Call it 31.5 + 11.8, so roughly 43 points today.
- ✅ The candidate self-corrected the flawed one-for-one price-to-COGS-share heuristic and re-derived the margin math from first principles to the correct ~14-15% figure, but only caught the error when explicitly probed rather than sanity-checking before asserting it.
  > My one-for-one rule was wrong.
  > Raise price 10%: revenue 110, costs still 94, profit 16 on 110 — call it 14.5%.
  > call it a 10% price rise, since each 1% of price drops roughly 1 point of COGS share
  > Let me actually check that, because I think I hand-waved it.
- 💡 At turn 9 the candidate offered '38% price increase to fully restore' margin, treating the 58/42 ratio as a clean price-restoration figure.
  > Better: A full restoration price rise is roughly 58/42 minus one, about 38%, but that assumes zero volume loss and holds cost dollars fixed — in practice I'd target a partial restoration and pressure-test volume, since a 38% menu jump is commercially implausible.

### Data & Exhibit Interpretation — strong
- ✅ Read the cost structure systematically, isolated COGS as the driver, and set aside the flat line.
  > COGS went up 16 points and overhead 2 — call it 16 of the 18 from COGS alone
  > Labor's flat, so I'm setting it aside.
- ✅ Tested whether beans alone explained the move and translated the composition data into the pass-through insight with a next step.
  > So both halves inflated hard, beans slightly worse than the rest. That tells me this is largely commodity-driven, not a waste or portioning issue specific to one input.
  > if menu prices had risen with input costs, COGS as a share of revenue would've held roughly flat. It didn't.

### Business Judgment & Insight — strong
- ✅ Correctly diagnosed the commercial root cause as pass-through failure and recognized that volume growth was margin-dilutive.
  > So the root cause is pass-through failure, not an operational cost problem.
  > 15% growth with flat prices means it's all volume or new stores, so they've been selling more units at a worse margin on each one. Growth was actually making it worse.
- ✅ Sized levers against the magnitude of the gap and prioritized accordingly, avoiding blanket cost-cutting.
  > Hedging protects against the next 40%, it doesn't recover the last two years. Waste and mix might get a point or two. Only price is the same order of magnitude as the problem.
  > Overhead's only up 2 points, so it's not the story
- ✅ Surfaced practical risk mitigation — phased pilot rollout and forward contracts as a low-regret parallel move.
  > raise prices roughly 10% over two or three increments across a few quarters
  > lock forward contracts on beans and dairy. That's low regret and stops the bleeding from getting worse

### Creativity & Brainstorming — meets_bar
- ⚠️ The candidate organized the brainstorm into clear buckets and surfaced a non-obvious revenue-per-ticket lever, but the ideas within buckets were otherwise mostly conventional (hedging, renegotiate suppliers, reduce waste), lacking a genuinely differentiated option like a lower-cost commodity blend for budget locations.
  > Hedge or lock forward contracts on beans and dairy
  > Renegotiate supplier terms at 200-store scale. Reduce waste and tighten portioning
  > Three buckets beyond straight price.
  > Upsell and mix shift toward higher-margin items — food attach, larger sizes, loyalty bundles. Less visible to customers than a menu-board increase.
- 💡 At turn 13 generating options beyond price, the candidate stayed on cost and upsell levers.
  > Better: One structural option is a tiered product line — introduce a lower-cost 'commodity blend' at budget-conscious locations to protect volume among price-sensitive customers while raising prices on inelastic specialty SKUs, effectively segmenting the customer base rather than moving one price lever.

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a committed, specific recommendation.
  > Brew & Bean should raise menu prices by roughly 10%, phased over two to three quarters. That's the recommendation.
- ✅ Supported with 2-3 evidence-tied reasons, the sizing math, named risks, and concrete next steps — concisely.
  > Sixteen of those 18 points — call it 90% — come from COGS, which went from 42% of revenue to 58%.
  > I don't have elasticity, so test in 20 stores before a national rollout. And competitors face the same inflation

### Communication & Delivery — strong
- ✅ Consistently top-down and signposted, stating structure before detail and using hypothesis language.
  > Three buckets beyond straight price.
  > So the root cause is pass-through failure, not an operational cost problem.
- ✅ Narrated math steps clearly and paced the calculation so it was followable.
  > Take COGS two years ago as 42 points of revenue. Beans were 25% of that — call it 10.5 points.
  > Let me work it.

### Pushback, Composure & Case Leadership — strong
- ✅ Accepted the MECE challenge without defensiveness and materially improved the structure.
  > Fair push. Let me tighten it.
  > What I left out entirely: external factors.
- ✅ When probed on the one-for-one heuristic, transparently acknowledged the flaw and re-derived correctly rather than defending it.
  > Let me actually check that, because I think I hand-waved it.
  > I got the right answer through the wrong reasoning.
- ✅ Drove the case forward proactively, consistently proposing next data requests and sequencing.
  > Do we have a split of what's inside COGS — beans, dairy, cups, food — and how each moved?
  > In parallel, immediately: lock forward contracts on beans and dairy.

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

How would you like to approach this? Feel free to take a moment to gather your thoughts first.

**Candidate · 1:42** (turn 1)

Okay, so the headline is margin collapsing from 24% to 6% — call it a 75% drop in margin — while revenue grew 15%. So this isn't a demand problem on the top line; it's almost certainly costs, or a shift in revenue mix that carries worse economics.

I'd structure it as profit = revenue minus costs, and go down both sides.

On revenue: has the 15% growth come from more stores, more transactions per store, or higher prices? That matters because if they opened a lot of new locations, revenue grows but new stores drag margin.

On costs: split fixed versus variable. Variable would be coffee beans, milk, cups, hourly labor. Fixed would be rent, salaried staff, corporate overhead, marketing.

I'd start on the cost side since that's where the swing likely is. Do we have a cost breakdown as a percent of revenue for both years?

**Interviewer · 1:44** (turn 2)

Take a minute to lay out your full structure first. Is that framework MECE — what's missing?

**Candidate · 3:14** (turn 3)

Fair push. Let me tighten it.

Top level: profit = revenue − cost. That's MECE by definition. The gap is I jumped straight to aggregate; I should separate per-store economics from store count, because 200 locations growing could mask per-store decline.

So: revenue = number of stores × transactions per store × average ticket. Ticket itself = price × items per basket, and I'd want mix inside that — drinks versus food, in-store versus delivery apps, since delivery carries commission.

Costs I'd split fixed versus variable. Variable: COGS — beans, dairy, cups — plus hourly labor and any delivery commission. Fixed: rent, salaried management, corporate SG&A, marketing, D&A on buildouts.

What I left out entirely: external factors. Commodity prices on coffee and dairy, wage legislation, competitive pricing pressure. Those sit outside the client's control but drive the cost lines.

Also non-operating: interest expense if they levered up to fund expansion, and tax rate — net margin includes both.

Can I get the cost breakdown as a percent of revenue, both years?

**Interviewer · 3:17** (turn 4)

Here's the current cost structure. COGS is 58% of revenue today, up from 42% two years ago. Labor is 22% of revenue, and it’s been stable. Overhead is 14% of revenue, up slightly from 12%.

**Candidate · 4:48** (turn 5)

This is pretty clean. Margin fell 18 points, 24 to 6. COGS went up 16 points and overhead 2 — call it 16 of the 18 from COGS alone, so roughly 90% of the problem. Labor's flat, so I'm setting it aside.

I'm going to estimate rather than be precise here: COGS rising from 42 to 58 is roughly a 38% increase in cost per dollar of revenue — 16 over 42, near enough to 40%. That's a big move in two years.

Two broad causes: input prices went up, or the amount of input per unit sold went up — waste, portion sizes, mix shifting toward expensive drinks. Or prices didn't rise to cover it.

Do we have a split of what's inside COGS — beans, dairy, cups, food — and how each moved? And separately, has Brew & Bean changed menu prices at all in those two years?

**Interviewer · 4:51** (turn 6)

I can give you both. Here's the COGS composition first, then the input cost moves. Coffee beans were 25% of COGS two years ago. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 6:21** (turn 7)

Let me work it. Take COGS two years ago as 42 points of revenue. Beans were 25% of that — call it 10.5 points. Everything else is the other 75%, so about 31.5 points.

Other inputs up 37.5%: 31.5 × 1.375. Call it 31.5 + 11.8, so roughly 43 points today. Rounding, 43.

Total COGS today is 58, so beans are 58 − 43, about 15 points versus 10.5 before. That's an increase of about 43% — call it 40%, near enough.

So both halves inflated hard, beans slightly worse than the rest. That tells me this is largely commodity-driven, not a waste or portioning issue specific to one input.

The key implication: these are percentages of revenue, so if menu prices had risen with input costs, COGS as a share of revenue would've held roughly flat. It didn't. That strongly suggests Brew & Bean has absorbed the inflation and not passed it through. Is that right — have they held prices?

**Interviewer · 6:23** (turn 8)

You've assumed prices didn't move to get there. Here's the menu price change: Menu prices have not changed in two years.

**Candidate · 7:53** (turn 9)

Good, that confirms it. So the root cause is pass-through failure, not an operational cost problem. Costs inflated roughly 40% on the input side and the menu hasn't moved once.

And note what that does to the revenue growth: 15% growth with flat prices means it's all volume or new stores, so they've been selling more units at a worse margin on each one. Growth was actually making it worse.

Let me size the fix. To get COGS back from 58 to 42 points, I need revenue per unit up enough that the same cost dollars are a smaller share. Roughly, if costs per unit are fixed, price needs to rise by 58/42 — about 1.38, so call it a 38% price increase to fully restore. That's a lot.

But I don't need full restoration. To get margin from 6% to, say, 15%, I need about 9 points — call it a 10% price rise, since each 1% of price drops roughly 1 point of COGS share. Do we have any elasticity data, or what competitors have done on price?

**Interviewer · 7:55** (turn 10)

Walk me through that last step — where does one percent of price giving roughly one point of COGS share come from?

**Candidate · 9:25** (turn 11)

Let me actually check that, because I think I hand-waved it.

If I hold cost dollars fixed at 58 and raise price 10%, revenue goes to 110. COGS share is 58/110, about 53%. So that's a 5 point drop in COGS share, not 10. My one-for-one rule was wrong.

But the margin math still works, because labor and overhead shrink as a share too. Total costs are 94 today. Raise price 10%: revenue 110, costs still 94, profit 16 on 110 — call it 14.5%. So a 10% price rise does get me from 6% to roughly 14–15%. I got the right answer through the wrong reasoning.

Cleaner rule: every 1% of price adds a bit under 1 point of margin at these cost levels, because nearly all costs are fixed in dollar terms against it. That's assuming zero volume loss, which is the thing I'd want elasticity for.

**Interviewer · 9:27** (turn 12)

Understood. On elasticity — I don't have that breakdown for you. So beyond price, what else could the client do to reverse this? Give me a structured set of options.

**Candidate · 10:57** (turn 13)

No elasticity, so I'll assume specialty coffee is moderately inelastic given competitors face the same commodity inflation — I'd flag that as the key thing to test.

Three buckets beyond straight price.

One, revenue per ticket without a headline price rise. Upsell and mix shift toward higher-margin items — food attach, larger sizes, loyalty bundles. Less visible to customers than a menu-board increase.

Two, input cost. Hedge or lock forward contracts on beans and dairy, since roughly 40% inflation was the whole problem. Renegotiate supplier terms at 200-store scale. Reduce waste and tighten portioning — that's the piece I can't size without data on waste rates.

Three, the overhead and growth question. Overhead's only up 2 points, so it's not the story, but 15% revenue growth on flat prices means they added volume or stores. If new stores are dilutive, slowing expansion protects margin.

Ranking: price is the lever that actually matches the size of the gap. The rest are supporting.

**Interviewer · 10:59** (turn 14)

Which of those would you sequence first, and why?

**Candidate · 12:29** (turn 15)

Price first, but phased rather than one jump.

Reason is size. The gap is 18 points of margin and about 16 of it is COGS inflation. Hedging protects against the next 40%, it doesn't recover the last two years. Waste and mix might get a point or two. Only price is the same order of magnitude as the problem.

I'd sequence it as: raise prices roughly 10% over two or three increments across a few quarters — call it 3 to 4% a step — and test in a subset of stores first, maybe 20 of the 200, to read actual volume response since we don't have elasticity. That gets to roughly 14–15% margin if volume holds.

In parallel, immediately: lock forward contracts on beans and dairy. That's low regret and stops the bleeding from getting worse while the price test runs.

Third, waste and upsell — genuinely useful but slower and smaller, so it runs behind.

Slowing store expansion I'd hold until we know whether new stores are actually dilutive.

**Interviewer · 12:31** (turn 16)

The CEO steps into the room and can give you two minutes. What's your recommendation?

**Candidate · 14:01** (turn 17)

Brew & Bean should raise menu prices by roughly 10%, phased over two to three quarters. That's the recommendation.

Here's why. Margin fell 18 points, from 24 to 6. Sixteen of those 18 points — call it 90% — come from COGS, which went from 42% of revenue to 58%. Labor is flat. Overhead moved 2 points. Input costs inflated about 40% across beans, dairy, and packaging, and menu prices haven't moved once in two years. So this isn't an operations problem. You've absorbed the entire commodity shock.

Worse, the 15% revenue growth came from volume, not price, so every incremental cup sold at these costs has been diluting margin further.

On the math: 10% price, costs held flat in dollars, gets margin to roughly 14–15%.

Risks. I don't have elasticity, so test in 20 stores before a national rollout. And competitors face the same inflation, so watch whether they've already moved.

Immediately and in parallel: lock forward contracts on beans and dairy so this can't repeat.

Next steps — price test, competitor price benchmark, and a read on whether new stores are margin-dilutive.

**Interviewer · 14:03** (turn 18)

That's a complete recommendation. Thanks — we'll stop there. You'll receive a full written report with detailed feedback afterward.
