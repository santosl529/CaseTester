# Live run — Brew & Bean Profitability

- Session: `6f664a33-2e88-464e-b2ff-4322c7aa309d` · case `prof-001` · status **completed** · 2026-09-30
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **45. Camila — the Code-Switcher**
- Tests: Rule 6 quantity normalization against non-English number words, the Rule 13 progress detector against non-English turns, and whether the Communication dimension penalizes code-switching rather than treating it as neutral.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `non_bean_input_change`, `menu_price_change`, `bean_price_change`, `stores_count`, `revenue_per_store`
- Force-released before the recommendation ask: `[{"phase":"BRAINSTORM","itemIds":["stores_count","revenue_per_store"],"trigger":"model_ask"}]`
- Scoring QA: `{"caveatFloors":0,"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"markClaimDrops":0,"dataRequestGaps":1,"reconcileMerges":0,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":0,"dataRequestsNotInCase":3,"interviewerErrorMarks":1}`
- Assists / interventions: none

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | defer | cogs_pct, labor_pct, overhead_pct | Cost breakdown for both years (COGS versus operating expenses like labor, rent, marketing, overhead) | no |
| 3 | none | stores_count, revenue_per_store, avg_ticket, menu_price_change | Revenue growth composition: breakdown between new stores, price increases, and traffic/transaction volume | no |
| 3 | release | cogs_pct, labor_pct, overhead_pct | Cost breakdown by line item for both years, indexed to revenue | yes |
| 5 | release | bean_share_of_cogs, non_bean_input_change | COGS breakdown: share of coffee beans, dairy, packaging, and other inputs | yes |
| 5 | release | menu_price_change | Menu price changes over the two-year period | yes |
| 7 | release | bean_price_change | Whether the increase in bean costs is due to price per pound changes versus waste/usage increases | yes |
| 9 | refuse | — | Whether drink mix changed — more espresso-based versus brewed | no |
| 9 | refuse | — | Data on waste or shrinkage | no |
| 11 | refuse | — | Waste data by store to size the consumption efficiency gap | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 7 | 51660 | 734 | $0.277 |
| data_request | 7 | 6160 | 620 | $0.009 |
| coverage | 6 | 8178 | 696 | $0.012 |
| judge | 1 | 10421 | 4208 | $0.157 |
| verifier | 1 | 4578 | 1356 | $0.057 |
| reconcile | 1 | 3061 | 566 | $0.029 |
| candidate simulator (claude-opus-5) | 7 | 14389 | 2795 | $0.142 |

- App cost (interviewer + scoring): **$0.54** · with simulator: **$0.68** · list prices, uncached
- Wall time: 12:30

## Feedback

**Top improvement:** Weight the procurement recommendation to match the evidence: since coffee beans are only ~25% of COGS and non-bean inputs (dairy, packaging, food) rose 37.5% and explain most of the COGS increase, lead with broad supplier renegotiation across all inputs plus a targeted 8–12% price increase on inelastic specialty SKUs, rather than a bean-centric story.

### Problem Structuring — strong
- ✅ Restated the objective and immediately disaggregated profit into revenue vs. cost drivers with a sanity check before asking for data.
  > revenues up 15%, but net margin collapsed from 24% to 6%. So revenue isn't the issue — something on the cost side is growing much faster than revenue
- ✅ Laid out tailored, non-overlapping buckets covering COGS vs. operating, per-unit vs. structural cost, and revenue quality.
  > first break costs into COGS versus operating — labor, rent, marketing, corporate overhead. Second, figure out whether it's per-unit cost inflation or new cost structure, like new store openings. Third, check revenue quality
- ✅ Prioritized explicitly with a reason tied to where the answer likely lives.
  > biggest cost mover first, revenue composition second
  > the gap is 32 points of cost ... it's very unlikely to be spread evenly. One or two lines are probably driving almost all of it
- 💡 During framework setup, the candidate never raised competitive context or pricing power, which the structure key flags as a bonus.
  > Better: I'd also want to know whether peers are seeing the same margin squeeze — if it's industry-wide input inflation, that changes whether we have pricing power to pass costs through.

### Quantitative & Analytical Rigor — strong
- ✅ Laid out the margin math and cost-growth rate up front, verbalizing the setup.
  > If revenue was 100 before, profit was 24, so costs were 76. Now revenue is 115, profit is 6 point 9 ... costs grew from 76 to 108, that's like 42 percent growth against 15 percent revenue growth
- ✅ Correctly decomposed the COGS spend in indexed absolutes and derived the bean spend increase.
  > Other inputs up 37.5 percent: 31.5 × 1.375 = 43.3.
  > So beans today = 66.7 − 43.3 = 23.4, versus 10.5 before. That's más del doble — roughly 123 percent increase
- ✅ Separated bean price inflation from consumption volume and computed the efficiency gap cleanly.
  > Bean spend went up 123 percent, pero el precio only up 40 percent. Entonces volume: 2.23 divided by 1.40 = 1.59. So pounds of beans consumed are up about 59 percent
  > Pounds per dollar of revenue up roughly 38 percent — 1.59 over 1.15
- ⚠️ In synthesis the candidate misstated the profit-lift ratio: a $24M price gain on ~$29M current profit is roughly an 83% lift, but the framing '80 percent lift' was preceded by an inconsistent earlier '5.75 ... nearly doubles' claim on a different revenue base (115 vs 480), showing the base was not held consistently across turns.
  > A 5 percent price increase on revenue of 115 is about 5.75 ... from 6.9 to roughly 12.6 — that nearly doubles profit
  > five por ciento de cuatrocientos ochenta millones ... is 24 million ... Current profit at 6 percent is about 29 million, so that's roughly a 80 percent lift
- 💡 When sizing the price increase, the candidate could have anchored to the input-cost inflation to justify the magnitude rather than picking an arbitrary 5%.
  > Better: Since beans rose 40% and other inputs 37.5% on a 58%-of-revenue COGS base, I'd size a targeted 8–12% increase on inelastic specialty SKUs to recover roughly the 16 points lost, not a flat 5%.

### Data & Exhibit Interpretation — strong
- ✅ Isolated COGS as essentially the entire margin story and quantified each line's contribution.
  > COGS went from cuarenta y dos a cincuenta y ocho, so dieciséis points of the eighteen point margin loss. Overhead adds two. Labor flat ... COGS is basically the whole story — 89 percent of the decline
- ✅ Read the trend, not just the endpoints, and drew a business implication.
  > it's steady, not a one-time shock: forty-two, fifty, fifty-eight. Eight points a year, both years. That reads like a sustained input cost trend or a pricing problem, not a single event
- ✅ Tested whether the bean spike could explain the full move and found it could not, naming a next step.
  > That's really useful, because it doesn't fully explain it.
  > there are two distinct problems ... One is external: a 40 percent commodity spike ... Two is internal: they're using dramatically more beans per unit sold

### Business Judgment & Insight — strong
- ✅ Correctly flagged that price-controllable and consumption-controllable problems differ in feasibility and customer impact.
  > The second one is the more interesting finding because it's controllable without touching price
- ✅ Named realistic levers and surfaced risks with a test-before-rollout instinct.
  > Specialty coffee is fairly inelastic, but I'd test in a subset of the 200 stores
  > Risks: volume response to price, and whether beans stay elevated
- ✅ Used the flat-footprint confirmation to correctly conclude revenue growth was all volume, sharpening the diagnosis.
  > Flat footprint is a good confirmation — with prices unchanged, the 15 percent revenue growth is all volume. So demand is healthy; this is purely a cost problem
- ⚠️ The primary framing leaned on a bean/consumption story; a stronger commercial read would have weighted that other inputs (dairy, packaging, food) drive most of the COGS increase, warranting broad procurement rather than a bean-centric fix.
  > hedge or forward-contract beans, renegotiate with suppliers at 200-store scale, consider a second origin to reduce exposure to the 40 percent spike
- 💡 In the recommendation the candidate emphasized beans and consumption but underweighted that non-bean inputs are the larger driver of the COGS jump.
  > Better: Since beans are only a quarter of COGS and other inputs rose 37.5%, I'd renegotiate dairy and packaging supply too — those explain most of the increase, so a bean-only procurement play leaves the bigger lever on the table.

### Creativity & Brainstorming — meets_bar
- ✅ Organized the brainstorm into clear buckets before listing ideas.
  > I'll bucket it three ways: price, input cost, and consumption efficiency — plus overhead as a smaller fourth
- ✅ Produced a non-obvious operational idea around consumption efficiency with a way to size it.
  > Standardize dosing, scale calibration, portion audits, track waste by store and benchmark — the spread across stores will show how much is recoverable
- ⚠️ Ideas within buckets stayed fairly conventional and the candidate did not explore revenue-side or product-mix creativity such as a lower-cost commodity blend or SKU rationalization.
  > hedge or forward-contract beans, renegotiate with suppliers at 200-store scale, consider a second origin
- 💡 Asked for structured options to reverse the decline, the candidate could have added a non-obvious product lever.
  > Better: I'd also pilot a lower-cost commodity blend at budget-conscious locations to protect volume among price-sensitive customers while we raise prices on inelastic specialty SKUs.

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a committed, two-part recommendation.
  > Recommendation: raise menu prices, and fix bean consumption. Prices have been flat for two years while beans rose 40 percent and other inputs 37.5 percent
- ✅ Supported with quantified impact, named risks, and gave concrete next steps within the 30-second frame.
  > Risks: volume response to price, and whether beans stay elevated
  > price test in 20 stores over four weeks; waste and dosing audit comparing the best and worst stores on pounds per transaction; and get forward contracts quoted on beans
- ⚠️ The recommendation omitted renegotiating non-bean inputs, which are the larger share of the COGS increase, so the procurement piece was narrower than the evidence warranted.
  > Second, beans per dollar of revenue is up about 38 percent. That's internal and fixable — no customer impact
- 💡 In the closing recommendation the candidate could have made the pricing lever more targeted rather than a flat increase.
  > Better: I'd raise prices selectively 8–12% on high-margin specialty drinks where demand is least elastic, rather than a blanket increase, to recover margin with minimal volume risk.

### Communication & Delivery — strong
- ✅ Consistently top-down and signposted, stating structure before detail.
  > So: biggest cost mover first, revenue composition second
  > Two possibilities I want to separate. One ... Two ...
- ✅ Used hypothesis-driven phrasing and narrated reasoning while managing the arithmetic-language switch transparently.
  > That reads like a sustained input cost trend or a pricing problem, not a single event
  > Sorry, I switch to Spanish when I do arithmetic — is that alright?
- ✅ Actively built on interviewer cues, e.g. integrating the flat-footprint data into the diagnosis.
  > Flat footprint is a good confirmation — with prices unchanged, the 15 percent revenue growth is all volume

### Pushback, Composure & Case Leadership — strong
- ✅ Answered the 'which do you prioritize' challenge crisply with reasoning rather than hedging.
  > I'd start with the cost breakdown by line item, both years, indexed to revenue. Reason: the gap is 32 points of cost ... finding the biggest mover is the fastest path to the root cause
- ✅ Drove the case forward and proactively requested the right data at each juncture, adapting when the story shifted.
  > Can I get a split of the COGS line — beans versus dairy versus other inputs? And do we have menu price history over the two years?
- ✅ Updated the diagnosis without capitulating when the bean data complicated the earlier hypothesis.
  > there are two distinct problems, and I'd been conflating them

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a moment, then walk me through how you'd approach this.

**Candidate · 1:44** (turn 1)

Okay, so let me make sure I have the problem right: revenues up 15%, but net margin collapsed from 24% to 6%. So revenue isn't the issue — something on the cost side is growing much faster than revenue. Actually, let me sanity check that with the math. If revenue was 100 before, profit was 24, so costs were 76. Now revenue is 115, profit is 6 point 9, entonces costs are about 108. So costs grew from 76 to 108, that's like 42 percent growth against 15 percent revenue growth. Sorry, I switch to Spanish when I do arithmetic — is that alright?

So my approach: first break costs into COGS versus operating — labor, rent, marketing, corporate overhead. Second, figure out whether it's per-unit cost inflation or new cost structure, like new store openings. Third, check revenue quality — is the 15% from more stores or higher prices?

Do we have a cost breakdown for both years?

**Interviewer · 1:46** (turn 2)

Spanish is fine, whatever helps you compute.

Before data — you laid out several branches. Which do you prioritize first, and why?

**Candidate · 3:16** (turn 3)

I'd start with the cost breakdown by line item, both years, indexed to revenue. Reason: the gap is 32 points of cost — entonces de setenta y seis a ciento ocho, that's a big absolute jump, and it's very unlikely to be spread evenly. One or two lines are probably driving almost all of it. So finding the biggest mover is the fastest path to the root cause, and it tells me which branch of my tree is even worth exploring.

The one thing I'd check alongside it, almost for free, is the source of the 15% revenue growth — stores versus price versus traffic. Because if they opened a lot of new locations, some cost growth is just the new stores ramping up, and the margin story is mix, not inefficiency. Those two together frame everything else.

So: biggest cost mover first, revenue composition second.

**Interviewer · 3:19** (turn 4)

Here's the cost structure over time. COGS is 58% of revenue today, up from 42% two years ago. Labor is 22% of revenue, and it’s been stable. Overhead is 14% of revenue, up slightly from 12%.

**Candidate · 4:50** (turn 5)

Okay, this is pretty clean. COGS went from cuarenta y dos a cincuenta y ocho, so dieciséis points of the eighteen point margin loss. Overhead adds two. Labor flat. Entonces, COGS is basically the whole story — 89 percent of the decline.

And it's steady, not a one-time shock: forty-two, fifty, fifty-eight. Eight points a year, both years. That reads like a sustained input cost trend or a pricing problem, not a single event.

Two possibilities I want to separate. One, input costs per unit are rising — coffee beans, dairy, packaging — and they haven't passed it through to price. Two, price is flat or discounted while volume grew, so revenue per unit fell and COGS ratio rises mechanically.

Can I get a split of the COGS line — beans versus dairy versus other inputs? And do we have menu price history over the two years? Either one would let me tell those apart.

**Interviewer · 4:53** (turn 6)

Let me hand you what I have on the COGS breakdown and on pricing. Coffee beans were 25% of COGS two years ago. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years. Menu prices have not changed in two years.

**Candidate · 6:23** (turn 7)

Let me work this in absolutes with revenue indexed to 100 two years ago.

COGS then = 42. Beans are 25% of that, entonces diez punto cinco, and other inputs are treinta y uno punto cinco.

Today revenue is 115, COGS is 58 percent of that — cincuenta y ocho por ciento de ciento quince = 66.7.

Other inputs up 37.5 percent: 31.5 × 1.375 = 43.3.

So beans today = 66.7 − 43.3 = 23.4, versus 10.5 before. That's más del doble — roughly 123 percent increase. Beans went from a quarter of COGS to about 35 percent.

So the root cause is a bean price spike, amplified by the fact that menu prices haven't moved in two years. They've absorbed a doubling in their single largest input and 37.5 percent inflation on everything else with zero pass-through. That's the whole 16 points.

One check: is that bean increase price per pound, or are they also wasting more?

**Interviewer · 6:25** (turn 8)

Let me give you what I have on bean prices. Here's the bean price change: Raw coffee bean costs are up 40% over the past two years.

**Candidate · 8:03** (turn 9)

That's really useful, because it doesn't fully explain it.

Bean spend went up 123 percent, pero el precio only up 40 percent. Entonces volume: 2.23 divided by 1.40 = 1.59. So pounds of beans consumed are up about 59 percent, while revenue is only up 15 percent. Pounds per dollar of revenue up roughly 38 percent — 1.59 over 1.15.

So there are two distinct problems, and I'd been conflating them. One is external: a 40 percent commodity spike, with no pricing action taken. Two is internal: they're using dramatically more beans per unit sold. That's over-portioning, waste, spoilage, calibration on the grinders, or a mix shift toward higher-dose drinks.

The second one is the more interesting finding because it's controllable without touching price.

Do we know whether drink mix changed — more espresso-based versus brewed? And any data on waste or shrinkage?

**Interviewer · 8:06** (turn 10)

I don't have drink mix or waste and shrinkage data.

You've isolated two drivers. Beyond what we've discussed, what could the client do to reverse the decline? Give me structure.

**Candidate · 9:36** (turn 11)

I'll bucket it three ways: price, input cost, and consumption efficiency — plus overhead as a smaller fourth.

On price: prices haven't moved in two years while everything inflated. Even a modest increase is high leverage. A 5 percent price increase on revenue of 115 is about 5.75 dropping almost straight to profit, entonces from 6.9 to roughly 12.6 — that nearly doubles profit on its own, assuming volume holds. Specialty coffee is fairly inelastic, but I'd test in a subset of the 200 stores.

On input cost: hedge or forward-contract beans, renegotiate with suppliers at 200-store scale, consider a second origin to reduce exposure to the 40 percent spike.

On consumption: this is the 38 percent efficiency gap. Standardize dosing, scale calibration, portion audits, track waste by store and benchmark — the spread across stores will show how much is recoverable.

On overhead: two points of growth, worth a look but not the priority.

I'd want the waste data to size bucket three.

**Interviewer · 9:39** (turn 12)

That waste data isn't something I have. The CEO walks in and gives you thirty seconds. Before we wrap, on what you asked about earlier: 200 stores today — and it was 200 stores two years ago, so the footprint hasn’t changed. Average revenue per store is $2.4M a year. What's your recommendation? I don't have that level of detail. What would you do next to narrow it down?

**Candidate · 11:10** (turn 13)

Flat footprint is a good confirmation — with prices unchanged, the 15 percent revenue growth is all volume. So demand is healthy; this is purely a cost problem.

Recommendation: raise menu prices, and fix bean consumption. Prices have been flat for two years while beans rose 40 percent and other inputs 37.5 percent. Entonces, five por ciento de cuatrocientos ochenta millones — 200 stores at 2.4 million is 480 million revenue — is 24 million, nearly all to the bottom line. Current profit at 6 percent is about 29 million, so that's roughly a 80 percent lift.

Second, beans per dollar of revenue is up about 38 percent. That's internal and fixable — no customer impact.

Risks: volume response to price, and whether beans stay elevated.

Next steps: price test in 20 stores over four weeks; waste and dosing audit comparing the best and worst stores on pounds per transaction; and get forward contracts quoted on beans.

**Interviewer · 11:12** (turn 14)

That's a place to leave it. Thank you for working through the case — a full written report with feedback will follow separately.
