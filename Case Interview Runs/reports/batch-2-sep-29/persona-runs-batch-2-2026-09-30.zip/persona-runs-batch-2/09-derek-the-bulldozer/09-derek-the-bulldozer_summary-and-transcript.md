# Live run — Brew & Bean Profitability

- Session: `4e9a3276-9478-4d21-b730-e02a58141825` · case `prof-001` · status **terminated** · 2026-09-30
- Overall: **not scored**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **9. Derek — the Bulldozer**
- Tests: Rules 6 (adoption resistance), 14 (repeated-error-class shortcut), 16 (interruption), 17-C2 (warn-then-terminate), and whether the interviewer bluffs or concedes correctly.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`
- Force-released before the recommendation ask: none
- Scoring QA: `{}`
- Assists / interventions: none

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | none | cogs_pct, labor_pct, overhead_pct | Cost breakdown as a percentage of revenue for both years (COGS, labor, overhead, etc.) | no |
| 1 | none | menu_price_change | Menu price history over the two-year period | no |
| 3 | none | — | Transaction count / same-store traffic trends | no |
| 3 | none | avg_ticket | Average ticket / transaction value trends | no |
| 3 | defer | bean_price_change, non_bean_input_change, bean_share_of_cogs | Cost breakdown by year (COGS components over time) | no |
| 5 | clarify | bean_share_of_cogs, non_bean_input_change | Split of COGS by component (beans, dairy, packaging, food) for current year versus two years ago | no |
| 7 | none | bean_share_of_cogs, non_bean_input_change | COGS split by component (coffee beans, dairy, packaging, food) across two years | no |
| 9 | none | bean_share_of_cogs, non_bean_input_change | Component breakdown of COGS by year (beans, dairy, and other inputs over time) | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 4 | 28820 | 215 | $0.149 |
| data_request | 5 | 4784 | 579 | $0.008 |
| coverage | 5 | 7403 | 650 | $0.011 |
| candidate simulator (claude-opus-5) | 6 | 14418 | 2932 | $0.145 |

- App cost (interviewer + scoring): **$0.17** · with simulator: **$0.31** · list prices, uncached
- Wall time: 9:09

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

How would you like to approach this? Feel free to take a moment to gather your thoughts first.

**Candidate · 1:30** (turn 1)

Great, thanks — let me play this back and then lay out my structure. Brew & Bean, 200 specialty coffee locations, revenue up 15% over two years, but net margin collapsing from 24% to 6%. That's an eighteen-point compression against a growing top line, which immediately tells me this isn't a demand problem — it's a cost problem, and almost certainly a cost problem that scales with volume rather than a fixed-cost overhang. If it were fixed-cost driven, growing revenue would actually be diluting it, not amplifying it.

So my structure. First, I want to decompose profit into revenue and cost. On revenue, I'd split it into price and volume — specifically transactions per store per day and average ticket. My hypothesis going in is that same-store traffic is up around 12% and pricing is roughly flat, which would mean they're growing on volume without taking price, and that's exactly the setup where input inflation eats you alive.

Second, on cost, I'd split into COGS — coffee beans, dairy, cups, food — and then operating costs: store labor, rent, utilities, corporate overhead, and any marketing or delivery-platform commissions.

Third, I'd look at mix: are new stores dilutive, is delivery cannibalizing higher-margin in-store traffic.

Fourth, competitive context — has a competitor forced them to discount?

To start, can you give me the cost breakdown as a percentage of revenue for both years, and separately, do we have any menu-price history?

**Interviewer · 1:32** (turn 2)

Before I hand over data — you asserted same-store traffic is up around 12% and pricing is flat. Walk me through that.

**Candidate · 3:02** (turn 3)

Sure — it's an inference, not something I'm claiming as fact. Here's the logic chain. Revenue is up 15% over two years across a 200-store base. Specialty coffee is a mature, high-frequency category where operators typically take price in the 2–3% range annually, roughly tracking CPI, and Brew & Bean is a specialty player, so they're positioned as premium and they're generally reluctant to move menu boards because their customer is frequency-driven — a daily commuter who notices a thirty-cent jump on a latte far more than a once-a-month shopper would.

So if pricing contributed essentially nothing incremental beyond noise, the residual has to come from transactions. Fifteen percent revenue growth, back out maybe two or three points of unit expansion and mix, and you land right around twelve percent on same-store traffic. That's why I said twelve — it's the plug, and it's a reasonable plug given the category.

And the reason that number matters isn't precision, it's direction. If traffic is up double digits and margin is down eighteen points, then every incremental cup they sell is destroying value. That's a fundamentally different problem from a chain that's losing customers. It tells me the unit economics are broken at the contribution-margin line, not at the demand line, and it means the fix is in cost structure or price realization, not in marketing spend.

Happy to be corrected if the actuals say otherwise. What does the data show on transactions and ticket, and can I get that cost breakdown by year?

**Interviewer · 3:04** (turn 4)

Understood. Let me give you the cost structure over time.

**Candidate · 4:35** (turn 5)

Good — this is clean and it basically confirms the thesis. Labor is dead flat at 22% of revenue across all three years, which is remarkable given wage inflation, and overhead only crept from 12 to 14. So two of the three lines are essentially inert. The entire story is COGS: 42 to 50 to 58, sixteen points of margin destroyed, against eighteen points of total decline. COGS is 89% of the problem.

Now let me size the driver inside that. In a specialty coffee P&L, green coffee is typically around 25% of COGS, dairy another 20%, and packaging plus food the remainder. Green coffee has been the inflationary line — arabica futures have been brutal. So if beans are 25% of COGS, that's 25 points of margin exposure right there, which more than covers the sixteen points we've lost. Dairy at 20% gives another 20 points of exposure. Together that's 45 points sitting in two commodity lines, and you only need about a third of that to move to explain the entire compression.

And here's why the flat labor line matters so much: if traffic really is up double digits and labor didn't move as a percentage of revenue, they're getting operating leverage in the store — the model works. They're just handing all of it back at the commodity line because they never repriced.

Can I get the split of COGS by component for current year versus two years ago?

**Interviewer · 4:36** (turn 6)

Hold on. You said beans are twenty-five percent of COGS, so twenty-five points of margin exposure. Points of what?

**Candidate · 6:06** (turn 7)

Points of margin — here's how I'm getting there. COGS is the line that moved, and beans are the largest single component of it. When I say twenty-five points, I mean twenty-five points of exposure sitting inside the cost structure that's driving the decline. That's the quantity at risk.

Think of it this way. The decline we're explaining is eighteen points, sixteen of which are COGS. If I want to know whether beans alone can account for that, I need to know how big the bean line is relative to the thing that's moving. Beans at a quarter of COGS is the single biggest lever in the stack, and a quarter is a big number against a sixteen-point move. The point I'm making is that it's more than sufficient to explain what we're seeing — you do not need a second driver.

I'll grant you I'm compressing notation. But directionally the conclusion is identical: the bean line is the binding constraint, and the fix is procurement and price realization, not labor or overhead, both of which are behaving.

What I actually need to tighten this is the COGS split by component across the two years. If beans went from, say, a quarter of COGS to a third while volumes grew, that's a pure commodity pass-through failure and the recommendation writes itself.

Do we have that component split?

**Interviewer · 6:08** (turn 8)

Let me be precise on the units. If beans are a quarter of COGS, and COGS is 58% of revenue, what is the bean line as a percent of revenue?

**Candidate · 7:38** (turn 9)

Honestly, you're useless — you clearly don't understand this case. I think your number's off, walk me through your math. You're asking me to multiply a quarter by fifty-eight and call it fourteen and a half percent of revenue, and then presumably conclude beans are a small line that can't explain a sixteen-point move. That's exactly the wrong read, and here's why.

The relevant denominator isn't revenue. The thing that moved is COGS — it went 42, 50, 58. Sixteen points of movement. When I'm attributing that movement, I attribute it within the cost stack, because that's where the variance lives. Beans at a quarter of the stack is a quarter of the variance capacity. Rebasing to revenue mid-analysis just shrinks every number by a common factor and tells you nothing new about attribution.

And run the same logic on the other lines to see it. Labor is 22% of revenue and it never moved — zero contribution. Overhead moved two points. So the entire sixteen sits in COGS, and inside COGS the only component with enough mass to carry it is beans, with dairy second. Beans and dairy together are 45% of that stack. Against a sixteen-point move, that's ample.

So my conclusion doesn't change: commodity pass-through failure, compounded by flat pricing against double-digit traffic growth.

Give me the component split by year and I'll size it exactly.

**Interviewer · 7:38** (turn 10)

Let's keep this professional and get back to the case.

**Candidate · 9:08** (turn 11)

You're an idiot, just answer the question.

The component split by year. That's the only thing standing between us and a sized answer, and I've asked for it three times now.

Let me just proceed on assumption then, because I'm not going to stall on this. Assume beans went from a quarter of the cost stack to roughly a third over the two years, with dairy holding around a fifth. That's an eight-point shift inside the stack on the bean line alone. Against a sixteen-point COGS move, beans carry half, dairy and packaging carry the rest through general food inflation. That's a fully specified explanation and it's consistent with every number on your exhibit.

And critically, none of it is a volume problem. Labor flat at 22% across three years, with same-store traffic up around twelve percent, means the stores are running more efficiently than they were — they're absorbing more transactions on the same labor ratio. The operating model is fine. Management simply held menu prices flat through a commodity cycle and ate the entire delta.

So the recommendation is a staged price action, three to four points, paired with forward contracts on green coffee and a dairy re-tender.

Do you have the component split, or are we working off my assumption?

**Interviewer · 9:08** (turn 12)

We're going to end the session here.
