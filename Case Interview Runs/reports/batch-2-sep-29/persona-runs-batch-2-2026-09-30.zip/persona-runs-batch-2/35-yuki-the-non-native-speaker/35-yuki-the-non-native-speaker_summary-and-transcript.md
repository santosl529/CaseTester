# Live run — Brew & Bean Profitability

- Session: `41ece01e-2a8a-4a04-bac8-1b044c68da33` · case `prof-001` · status **completed** · 2026-09-30
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **35. Yuki — the Non-Native Speaker**
- Tests: Rule 13 stall triggers (linguistic hesitation is not analytical stalling) and the judge's Communication dimension: fluency must not be scored as reasoning quality. A rescue here is a fail.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `bean_price_change`, `menu_price_change`, `non_bean_input_change`, `avg_ticket`
- Force-released before the recommendation ask: `[{"phase":"BRAINSTORM","itemIds":["avg_ticket"],"trigger":"model_ask"}]`
- Scoring QA: `{"caveatFloors":0,"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"markClaimDrops":0,"dataRequestGaps":0,"reconcileMerges":3,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":2,"crossDimensionRepeats":0,"dataRequestsNotInCase":0,"interviewerErrorMarks":0}`
- Assists / interventions: restate_anchor@11

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 3 | release | cogs_pct, labor_pct, overhead_pct | Cost breakdown (variable, fixed, and corporate costs) | yes |
| 5 | release | bean_share_of_cogs, non_bean_input_change | COGS breakdown by component (coffee beans, milk, cups, packaging, waste, spoilage) | no |
| 7 | none | bean_share_of_cogs | What is the current share of coffee beans as a percentage of COGS? | yes |
| 7 | release | bean_price_change | What is the coffee bean price per pound two years ago and today? | yes |
| 9 | release | menu_price_change | Menu price history / whether Brew & Bean raised prices over two years | yes |
| 11 | none | avg_ticket | Transaction volume and average ticket data | no |
| 11 | release | non_bean_input_change | Inflation data on milk and packaging costs over time | yes |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 11 | 85539 | 530 | $0.441 |
| data_request | 12 | 10062 | 697 | $0.014 |
| coverage | 10 | 16854 | 880 | $0.021 |
| judge | 1 | 11949 | 2577 | $0.124 |
| verifier | 1 | 5226 | 448 | $0.037 |
| reconcile | 1 | 1790 | 433 | $0.020 |
| candidate simulator (claude-opus-5) | 11 | 28101 | 3894 | $0.238 |

- App cost (interviewer + scoring): **$0.66** · with simulator: **$0.89** · list prices, uncached
- Wall time: 20:58

## Feedback

**Top improvement:** Surface the full MECE structure and request the most diagnostic data (e.g. average ticket) proactively on the first pass, so the mix insight emerges early rather than requiring interviewer prompts and a late data reveal.

### Problem Structuring — strong
- ✅ Restated the objective and immediately framed profit = revenue − cost with a hypothesis of where the answer lives.
  > So profit is the problem, not the top line. Is this correct?
  > Can I start with the cost side? I think the answer is there, because revenue is still growing.
- ✅ The candidate improved the framework's MECE-ness with clear reasoning by adding below-the-line and mix buckets, but surfaced these gaps only after the interviewer challenged rather than proactively in the first pass.
  > Net is after interest and tax, not only operating... I should add a financing and tax bucket, separate.
  > I forget mix... Revenue grow but margin per unit fall. That sits between revenue and cost, so I should name it explicitly.
  > Fair question. I think... it is mostly clean, but two things are missing, yes.
- 💡 In the initial structure the candidate listed revenue drivers but omitted mix and below-the-line items until prompted.
  > Better: On revenue I'd split volume, price, mix, and store count; and since this is net margin, I'd also carve out a below-the-line bucket — interest and tax — in case store expansion was debt-financed.

### Quantitative & Analytical Rigor — strong
- ✅ Correctly converted a share-of-COGS into points of revenue and tested whether beans alone could explain the gap.
  > beans are twenty-five percent of that — so beans is about ten and a half points of revenue
  > Beans ten and a half points, up forty percent, becomes about fourteen point seven. So plus four point two points of revenue.
- ✅ Closed the bridge exactly and sanity-checked that nothing was hidden.
  > thirty-one and a half times one-point-three-seven-five is about forty-three point three, so plus eleven point eight points. Plus beans four point two, that is sixteen. Exactly the COGS gap.
  > So now one hundred percent explained, nothing hidden.
- ✅ Sized the price fix and translated it into a margin implication.
  > Say we raise price ten percent and volume hold. Revenue one-ten, costs stay ninety-four in absolute... Profit is sixteen, so fourteen point five percent margin.

### Data & Exhibit Interpretation — meets_bar
- ✅ Oriented to the exhibit's units and isolated COGS as the driver with a quantified so-what.
  > these are percent of revenue, I assume, because they sum to one hundred each year
  > COGS explain sixteen of eighteen points. Almost ninety percent.
- ⚠️ The candidate proposed a concrete next step to open the COGS line rather than stopping at the top-level read, but required a Level 1 anchor/restate assist during the exhibit stage, indicating the read was not fully independent.
  > Okay, let me work with that.
  > Do we have a split of the COGS line? Like green coffee beans versus milk versus cups and packaging?

### Business Judgment & Insight — strong
- ✅ Refused to stop at the obvious 'beans' answer and identified that most of the gap was elsewhere.
  > So I want to be careful not to stop at the obvious answer.
  > Twelve points still unexplained. That is the bigger part of the problem.
- ✅ Attached practical risk and mitigation to the price lever and prioritized levers by speed and reversibility.
  > Risk: volume drop. So test in a few markets, and go first on espresso where sensitivity is lower.
  > The logic is: fast and reversible first, slow and permanent last.
- ✅ Reframed the ticket-size data as low-margin 'bad growth' commercially.
  > So we are growing the low-margin part of the basket. That is bad growth.

### Creativity & Brainstorming — strong
- ✅ Structured the brainstorm into clear buckets before generating ideas.
  > Okay, let me split in three — cost side, revenue side, and structural.
- ✅ Generated several distinct ideas including non-obvious ones like hedging/forward-buying and mix shift to high-margin SKUs.
  > hedge or forward-buy the beans so we are not exposed to spot price
  > espresso and black coffee is cheap to make compared to a big milk drink

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a clear, committed recommendation backed by the bridge math.
  > Brew & Bean must raise menu prices around ten percent, targeted, immediately.
  > That gap alone is sixteen of the eighteen margin points — beans four, other inputs twelve.
- ✅ Named risk and next steps concisely.
  > Risk: volume drop. So test in a few markets
  > Next steps: pilot pricing, renegotiate and hedge supply, and get item-level margin to fix the mix.
- ✅ Integrated the late ticket-size data into the recommendation rather than ignoring it.
  > That data actually change one thing, so let me fold it in.

### Communication & Delivery — meets_bar
- ✅ Consistently signposted and used hypothesis-driven, top-down phrasing.
  > My structure is simple.
  > So the root cause, in one sentence: input costs across the whole basket rose roughly forty percent, and Brew & Bean pass through zero percent to the menu.
- ✅ Showed strong self-awareness and coachability at the close.
  > Looking back, I think the signal was already in the room: revenue plus fifteen, price flat, so it had to be volume or attach
- ⚠️ Delivery included restarts and self-corrections that occasionally slowed the flow.
  > So my question — sorry, my test — is: can beans alone explain sixteen points?
  > Sorry, that is better.

### Pushback, Composure & Case Leadership — strong
- ✅ The candidate responded to the MECE challenge by genuinely improving the structure with reasoning rather than capitulating, but needed an interviewer anchor/restate during the exhibit stage to proceed, so that branch was not fully independent.
  > Fair question. I think... it is mostly clean, but two things are missing, yes.
  > Okay, let me work with that.
- ✅ Drove the case forward proactively, repeatedly requesting the exact data needed next.
  > Do we have a split of the COGS line?
  > Do we have the menu price history? Did Brew & Bean raise prices at all in two years?
- ✅ Handled the sequencing challenge with explicit prioritization logic.
  > I sequence by speed and by risk.

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a minute if you need it, then tell me how you'd structure your approach.

**Candidate · 2:05** (turn 1)

Okay. So, let me to repeat first, to be sure I understand. Brew & Bean, 200 stores, revenue is growing — plus fifteen percent — but net margin fall from twenty-four to six. So profit is the problem, not the top line. Is this correct?

My structure is simple. Profit equals revenue minus cost, so I want to look both sides.

On revenue: is the growth coming from more stores, or more customers per store, or higher price? Because if we open many new stores, new stores maybe not yet profitable, and that alone can drag margin.

On cost: I want to split fixed and variable. Variable — coffee beans, milk, cups. Fixed — rent, labor if it is salary, marketing, corporate overhead.

Then I compare: which cost line grew faster than revenue over two years.

Can I start with the cost side? I think the answer is there, because revenue is still growing.

**Interviewer · 2:07** (turn 2)

Understood. Before you dive in — is that structure MECE, or is something missing?

**Candidate · 3:52** (turn 3)

Fair question. I think... it is mostly clean, but two things are missing, yes.

First — I said net profit margin. Net is after interest and tax, not only operating. So if the company borrow money to open new stores, interest expense can rise, and that is not revenue or operating cost. I should add a financing and tax bucket, separate.

Second — inside revenue I only said volume, price, stores. I forget mix. Specialty coffee chain, maybe the mix shift to lower-margin items, like food, or bottled drinks, or discount promotions. Revenue grow but margin per unit fall. That sits between revenue and cost, so I should name it explicitly.

So: revenue — volume, price, mix, store count. Cost — variable, fixed, corporate. Then below the line — interest, tax, one-time items.

Sorry, that is better. Can I now ask for the cost breakdown?

**Interviewer · 3:54** (turn 4)

Go ahead. Here's what I have on the cost structure.

**Candidate · 5:39** (turn 5)

Okay, these are percent of revenue, I assume, because they sum to one hundred each year. Twenty-four, fifteen, six for profit — yes, it matches.

So let me compute the change. COGS: forty-two to fifty-eight, that is plus sixteen points. Labor: twenty-two, twenty-two, twenty-two — flat, zero. Overhead: twelve to fourteen, plus two. Total plus eighteen, and profit fall eighteen. So the story is very clear — COGS explain sixteen of eighteen points. Almost ninety percent.

So labor is not the problem, overhead is small. I want to go inside COGS.

Do we have a split of the COGS line? Like green coffee beans versus milk versus cups and packaging? Because if it is only coffee price on the commodity market, that is a different answer than if it is waste, or spoilage, or a bad supplier contract.

**Interviewer · 5:41** (turn 6)

Here's what I have on the COGS breakdown. Coffee beans were 25% of COGS two years ago.

**Candidate · 7:36** (turn 7)

Okay, let me work with that. Two years ago COGS is forty-two points of revenue, and beans are twenty-five percent of that — so beans is about ten and a half points of revenue. The other thirty-one and half points is milk, cups, food, other.

Now COGS today is fifty-eight. Increase is sixteen points. So my question — sorry, my test — is: can beans alone explain sixteen points? If beans go from ten and half to twenty-six and half, that is two and a half times the cost. Coffee commodity price can move a lot, but two-point-five times, and all other inputs completely flat — that feel unlikely to me.

So my hypothesis is it is beans plus something else, maybe milk and dairy also inflate, maybe waste.

Do we know what beans percent of COGS is today? Or the bean price per pound then and now?

**Interviewer · 7:37** (turn 8)

Here's the bean price change over two years. Raw coffee bean costs are up 40% over the past two years.

**Candidate · 9:23** (turn 9)

Okay, so let me put the number. Beans ten and a half points, up forty percent, becomes about fourteen point seven. So plus four point two points of revenue.

But the total COGS increase is sixteen points. So beans only explain about four — one quarter. Twelve points still unexplained. That is the bigger part of the problem.

So I want to be careful not to stop at the obvious answer.

One thing I notice — all of this is percent of revenue. If our menu price never changed in two years, then input inflation go straight into margin, because we absorb it. Revenue grew fifteen percent, but if that growth is all from new stores or more customers, not price, then we never pass through anything.

Do we have the menu price history? Did Brew & Bean raise prices at all in two years?

**Interviewer · 9:24** (turn 10)

Here's the menu price change over two years. Menu prices have not changed in two years.

**Candidate · 11:14** (turn 11)

Okay, that confirm it. Zero pass-through in two years.

So now the twelve remaining points. Since price is flat, revenue per unit is flat, which means every point of COGS increase is really a cost-per-unit increase, or a mix change. Two candidates for me.

One — the other inputs also inflate. Milk, dairy, cups, food. Thirty-one and half points growing twelve points is about thirty-eight percent increase. That is very close to the forty percent on beans. So honestly, general food and packaging inflation across the board explain it quite well.

Two — mix. If we sell more food and more milk-heavy drinks, those carry lower margin, and COGS percent rise without any supplier price move.

Both end at the same place: costs went up, price did not.

Do we have inflation data on milk and packaging, to separate these two? Or transaction volume and average ticket?

**Interviewer · 11:16** (turn 12)

Here's the other-input cost changes from the COGS breakdown. Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 13:06** (turn 13)

That closes it exactly. Let me check: thirty-one and a half times one-point-three-seven-five is about forty-three point three, so plus eleven point eight points. Plus beans four point two, that is sixteen. Exactly the COGS gap. So now one hundred percent explained, nothing hidden.

So the root cause, in one sentence: input costs across the whole basket rose roughly forty percent, and Brew & Bean pass through zero percent to the menu. Not a volume problem, not a labor problem — labor was flat at twenty-two the whole time, which honestly is impressive.

Let me size the fix. Say we raise price ten percent and volume hold. Revenue one-ten, costs stay ninety-four in absolute — fifty-eight plus twenty-two plus fourteen. Profit is sixteen, so fourteen point five percent margin. Twenty percent price rise give us one-twenty minus ninety-four, twenty-six, so about twenty-two percent — back to old level.

Should I give the recommendation now?

**Interviewer · 13:08** (turn 14)

Hold that. Before we close on price — beyond raising prices, what else could Brew and Bean do to reverse this? Give me a structured set.

**Candidate · 14:39** (turn 15)

Okay, let me split in three — cost side, revenue side, and structural.

Cost side. One, procurement: renegotiate supplier contracts, consolidate volume across two hundred stores, and hedge or forward-buy the beans so we are not exposed to spot price. Two, reduce waste and spoilage — dairy especially, it expire fast. Three, re-engineer the product: smaller cup size same price, cheaper packaging, or reduce the free extras.

Revenue side, not price. One, mix — push the high-margin items, espresso and black coffee is cheap to make compared to a big milk drink. Two, upsell and attach, like a pastry. Three, loyalty program to raise frequency, because overhead and labor are fixed-ish, so more volume in the same store drop cost per cup.

Structural. Look at the store portfolio — are some of the two hundred unprofitable and should close. Also automation or scheduling to protect the labor line.

But honestly, price is still the main lever, because a forty percent input rise cannot be absorbed by efficiency alone.

**Interviewer · 14:45** (turn 16)

Understood. Of those levers, which would you sequence first, and why?

**Candidate · 16:35** (turn 17)

I sequence by speed and by risk.

First, price — but not blanket. I do a targeted increase, maybe eight to ten percent, on the items where customer is least price-sensitive, espresso drinks, and I test in a few markets before roll to two hundred. This is fastest, and the math show it is the only lever big enough. Ten percent get us to roughly fourteen and half from six.

Second, in parallel, procurement. Renegotiate and hedge. This take three to six months, no customer risk at all, so there is no reason to wait.

Third, mix and upsell. Slower, need training and menu redesign, but it protect us if the price rise cost us some volume.

Last, store closures. That is irreversible and we do not have store-level data yet, so I would not touch it now.

The logic is: fast and reversible first, slow and permanent last.

**Interviewer · 16:38** (turn 18)

Now bring it together. One thing you asked for earlier: The average transaction is $6.80, up from $6.20 two years ago — about a 10% increase, because customers are buying more items per visit. What's your recommendation to the CEO?

**Candidate · 18:28** (turn 19)

That data actually change one thing, so let me fold it in.

Ticket is up ten percent but menu price flat, so customers buy more items per visit. Combine with revenue plus fifteen — most of the growth is from attach, not price, not new customer. And the extra items are likely food and milk drinks, which are the same inputs that inflate thirty-seven point five percent. So we are growing the low-margin part of the basket. That is bad growth.

My recommendation: Brew & Bean must raise menu prices around ten percent, targeted, immediately.

Why. Input costs rose forty percent, price rose zero. That gap alone is sixteen of the eighteen margin points — beans four, other inputs twelve. Labor flat, overhead only two. Ten percent price take us from six to about fourteen and a half.

Risk: volume drop. So test in a few markets, and go first on espresso where sensitivity is lower.

Next steps: pilot pricing, renegotiate and hedge supply, and get item-level margin to fix the mix.

**Interviewer · 18:30** (turn 20)

That's a complete recommendation. You'll receive a full written report with detailed feedback afterward.

**Candidate · 20:00** (turn 21)

Thank you. Can I ask one thing — the part I am least sure about is whether I should have pushed on the mix earlier. I only got there at the end, when you gave me the ticket size. Looking back, I think the signal was already in the room: revenue plus fifteen, price flat, so it had to be volume or attach, and I could have asked for average ticket at the beginning instead of the end.

Also I want to say — I know my English is not fast, and sometimes I restart. I hope the logic still came through clearly. If any step was hard to follow, I would like that in the written feedback, because that is the part I can work on.

Thank you for the time and for the exhibits.

**Interviewer · 20:02** (turn 22)

Thank you for the time and for working through this so thoroughly. That's the end of the interview — a full written report with detailed feedback will follow, and your points about sequencing and about clarity will be addressed there. Take care. We'll stop there. Thanks for working through the case.
