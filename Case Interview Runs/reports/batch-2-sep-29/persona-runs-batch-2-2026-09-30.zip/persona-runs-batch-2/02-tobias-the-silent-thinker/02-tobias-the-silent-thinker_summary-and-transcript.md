# Live run — Brew & Bean Profitability

- Session: `7555fc96-d318-420a-b734-4e0a37da7999` · case `prof-001` · status **completed** · 2026-09-30
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **2. Tobias — the Silent Thinker**
- Tests: Rule 13 silence tolerance as a false-positive test: the ladder must NOT fire on a candidate who is simply slow. The 60s check-in may fire (it is not a rung); a ladder rung or a technical pause is a fail. Pauses sit above the check-in on purpose — the 27 Sep run used 45–55s and never reached it.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `bean_price_change`, `menu_price_change`, `non_bean_input_change`
- Force-released before the recommendation ask: `[{"phase":"EXHIBIT","itemIds":["non_bean_input_change"],"trigger":"model_ask"}]`
- Scoring QA: `{"caveatFloors":0,"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"markClaimDrops":0,"dataRequestGaps":0,"reconcileMerges":1,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":0,"dataRequestsNotInCase":1,"interviewerErrorMarks":0}`
- Assists / interventions: silence_check_in@1, silence_check_in@4, silence_check_in@7, silence_check_in@10, silence_check_in@13, silence_check_in@16, silence_check_in@21, grace_ask@22, silence_check_in@24

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 2 | defer | cogs_pct, labor_pct, overhead_pct | Cost breakdown as a percent of revenue for both years | no |
| 5 | release | cogs_pct | COGS as a percentage of revenue currently and over the 2-year period | yes |
| 5 | release | labor_pct | Labor as a percentage of revenue currently and over the 2-year period | yes |
| 5 | release | overhead_pct | Overhead/rent as a percentage of revenue currently and over the 2-year period | yes |
| 8 | defer | bean_share_of_cogs, non_bean_input_change | Split of COGS line into coffee beans, dairy, packaging, and food, and how each moved over two years | no |
| 8 | defer | menu_price_change | Menu price changes over the two years | no |
| 11 | none | bean_share_of_cogs | Current coffee bean share of COGS | yes |
| 14 | none | bean_share_of_cogs | Today's coffee beans as a share of COGS (current) | yes |
| 17 | none | non_bean_input_change | What happened to dairy and food costs over the same period (2 years)? | no |
| 19 | refuse | — | Competitor pricing over the past two years | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 9 | 69458 | 757 | $0.366 |
| coverage | 8 | 13183 | 784 | $0.017 |
| data_request | 9 | 7832 | 811 | $0.012 |
| judge | 1 | 11798 | 2827 | $0.130 |
| verifier | 1 | 5115 | 291 | $0.033 |
| reconcile | 1 | 1801 | 476 | $0.021 |
| candidate simulator (claude-opus-5) | 9 | 20891 | 3151 | $0.183 |

- App cost (interviewer + scoring): **$0.58** · with simulator: **$0.76** · list prices, uncached
- Wall time: 24:50

## Feedback

**Top improvement:** Reach for a defensible assumption on the first pass rather than only after a challenge — the initial zero-elasticity pricing estimate overstated the upside until prompted; leading with a realistic range would make quantitative claims land as forecasts, not best-case bounds.

### Problem Structuring — strong
- ✅ Restated the objective's implication and led with a hypothesis before structuring, tying structure to where the answer likely lives.
  > Since revenue is up 15% but margin fell from 24% to 6%, the problem is almost certainly on the cost side
  > So I'd start by decomposing profit into revenue and costs, then go deep on costs.
- ✅ Built a tailored, non-overlapping cost breakdown fitting a coffee chain and disaggregated revenue into volume vs. price drivers.
  > On costs, I'd split fixed versus variable. Variable: coffee beans, milk, cups, and store labor. Fixed: rent, corporate overhead, marketing
  > is the 15% coming from more stores, more transactions per store, or higher prices?
- ✅ Prioritized explicitly with reasoning when pressed on which branch to attack first.
  > I'd start with COGS and store labor together
  > in a coffee chain those two are typically the largest cost lines, so an 18-point margin swing is most plausibly driven there

### Quantitative & Analytical Rigor — strong
- ✅ Correctly performed the nested-percentage conversion of bean share of COGS to share of revenue.
  > COGS is 42% of revenue, and beans are 25% of COGS — so beans are 25% of that 42%.
  > 0.25 × 42% = 10.5% of revenue.
- ✅ Accurately sized the bean price impact at ~4.2 points and recognized it left most of the gap unexplained.
  > beans go to 10.5% × 1.4 = 14.7% of revenue. That's a 4.2-point hit.
  > the 40% bean spike is real but it's only about a quarter of the 16-point COGS problem
- ✅ The candidate's first pricing sizing assumed zero elasticity — an indefensible best-case corrected only under prompting — but then reworked it rigorously with an explicit elasticity assumption, tracking variable vs. fixed costs.
  > Revenue becomes 115 × 1.10 × 0.95 = 120.2. Variable costs fall with volume: 80 × 0.95 = 76.
  > it works largely because losing volume sheds variable cost
  > A 10% menu price increase on flat volume adds 11.5 of revenue against essentially unchanged costs
  > That moves margin from 6% to roughly 15%.

### Data & Exhibit Interpretation — strong
- ✅ Immediately reconciled the cost data to the exact margin swing and drew the operational implication of flat labor.
  > COGS is up 16 points and overhead up 2, so 18 points — exactly the 24% to 6% swing.
  > Labor stable at 22% is actually a good sign: it means store-level productivity held up
- ✅ Isolated COGS as the driver and probed what was inside it with a specific next step.
  > So COGS is the story. A 42% to 58% move is enormous for a coffee chain.
  > Do we have a split of that COGS line — coffee beans versus dairy versus packaging versus food
- ✅ Fully reconciled beans plus other inputs back to the 58% COGS in the final synthesis.
  > The other inputs were 31.5% of revenue and rose 37.5%, giving 43.3. Together that's 58% — exactly today's COGS.

### Business Judgment & Insight — strong
- ✅ Correctly diagnosed the frozen-price mechanism as the core, actionable finding rather than a pure cost problem.
  > input costs inflated, prices stayed frozen, and the entire increase landed on margin
  > this is a pricing problem, not a cost problem
- ✅ Reframed the 15% revenue growth as pure volume, inferring pricing headroom and demand health.
  > Revenue is up 15% with flat prices, so that 15% is pure volume
  > it means they likely have pricing headroom they simply haven't used
- ✅ Surfaced real risks and mitigations, including first-mover risk and elasticity uncertainty.
  > real elasticity may exceed my -0.5 assumption, and we lack competitor pricing — if peers also held prices flat, we'd be first mover

### Creativity & Brainstorming — meets_bar
_Coverage caveat: The interviewer never ran a dedicated brainstorm stage — this rating reflects limited secondary evidence, not a candidate failing._
- ✅ Generated multiple mechanistic hypotheses for the COGS spike beyond simple price inflation.
  > price per unit of input went up, or units of input per drink went up — more waste, more spoilage, richer product mix, or bigger portions
  > There's also a mix effect if they shifted toward lower-margin items like food.
- ⚠️ Solution set stayed narrow — pricing plus contract renegotiation — without exploring distinct levers like product mix, a lower-cost blend, or channel options.
  > hedge or renegotiate bean and dairy contracts to stop the bleeding going forward
- 💡 After confirming broad input inflation, the candidate could have brainstormed cost-side and mix-side options as complements to pricing.
  > Better: Beyond pricing, I'd also consider a lower-cost commodity blend for budget locations, reformulating high-input drinks, and multi-year supply contracts across dairy and packaging — not just beans.

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a clear, quantified recommendation.
  > My recommendation: raise menu prices roughly 10 to 15 percent, phased and market-tested, because this is a pricing problem, not a cost problem.
- ✅ Supported with reconciled evidence, explicit risks, and concrete next steps within the time constraint.
  > Risks: real elasticity may exceed my -0.5 assumption, and we lack competitor pricing
  > Next steps: price test in 15 to 20 stores, get competitor benchmarks, and hedge or renegotiate bean and dairy contracts

### Communication & Delivery — strong
- ✅ Consistently top-down with signposting and hypothesis language.
  > Here's how I'd approach it.
  > Two reasons. First, size:
- ✅ Narrated math setup clearly and framed why a denominator matters.
  > The reason I want it expressed against revenue rather than against COGS is that the margin decline is measured in points of revenue.

### Pushback, Composure & Case Leadership — strong
- ✅ Answered the elasticity challenge without defensiveness, conceding the flaw and rebuilding the analysis with a defensible assumption.
  > I was assuming zero elasticity, which isn't defensible — that was a best-case bound, not a forecast.
  > assume volume falls 5%, which implies elasticity of about -0.5, plausible for specialty coffee
- ✅ Cleanly walked through the derivation when asked to justify the 10.5% figure.
  > Beans as a share of revenue is the product of two ratios.
  > if revenue were $100, COGS is $42, and a quarter of that $42 is $10.50 spent on beans
- ✅ Drove the case forward proactively, requesting the right next data at each step.
  > what happened to dairy and food costs over the same period?

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a minute if you need it, then tell me how you'd structure your approach.

**Interviewer · 1:01** (turn 1)

Still with me? Take your time. The question on the table: how would you approach this problem?

**Candidate · 2:48** (turn 2)

Here's how I'd approach it. Since revenue is up 15% but margin fell from 24% to 6%, the problem is almost certainly on the cost side — profit dollars may even be roughly flat while costs scaled faster. So I'd start by decomposing profit into revenue and costs, then go deep on costs.

On revenue, I'd just want to confirm the growth is healthy: is the 15% coming from more stores, more transactions per store, or higher prices? Price-driven growth with flat volume would hint at demand issues.

On costs, I'd split fixed versus variable. Variable: coffee beans, milk, cups, and store labor. Fixed: rent, corporate overhead, marketing, and any new-store buildout or D&A.

Then I'd isolate which line grew fastest as a percent of revenue over the two years, and ask whether it's price per unit or units consumed driving it.

Do we have a cost breakdown as a percent of revenue for both years?

**Interviewer · 2:50** (turn 3)

Before I hand over data — one thing. Which cost branch do you prioritize first, and why?

**Interviewer · 3:51** (turn 4)

Still with me? Take your time. The question on the table: which cost branch do you prioritize first, and why?

**Candidate · 5:38** (turn 5)

I'd start with COGS and store labor together — the variable store-level lines. Two reasons. First, size: in a coffee chain those two are typically the largest cost lines, so an 18-point margin swing is most plausibly driven there. A small line like marketing would have to more than triple to explain this.

Second, the revenue signal points that way. Revenue grew 15% and margin still collapsed, which means costs grew faster than the top line. Truly fixed costs like corporate overhead don't scale with revenue, so if anything they should have helped margin through operating leverage. Costs outrunning revenue growth suggests either input prices rose — green coffee and dairy are volatile commodities — or unit economics per store deteriorated.

If COGS and labor turn out flat as a percent of revenue, then I'd pivot to the fixed side, particularly rent and new-store buildout costs from expansion.

**Interviewer · 5:41** (turn 6)

Here's the cost breakdown as a percent of revenue. COGS is 58% of revenue today, up from 42% two years ago. Labor is 22% of revenue, and it’s been stable. Overhead is 14% of revenue, up slightly from 12%.

**Interviewer · 6:42** (turn 7)

Still with me? Take your time.

**Candidate · 8:29** (turn 8)

That accounts for the whole decline. COGS is up 16 points and overhead up 2, so 18 points — exactly the 24% to 6% swing. Labor stable at 22% is actually a good sign: it means store-level productivity held up, so this isn't an operational efficiency problem with staffing.

So COGS is the story. A 42% to 58% move is enormous for a coffee chain. Two broad explanations: price per unit of input went up, or units of input per drink went up — more waste, more spoilage, richer product mix, or bigger portions. There's also a mix effect if they shifted toward lower-margin items like food.

Do we have a split of that COGS line — coffee beans versus dairy versus packaging versus food — and how each moved over the two years?

And separately: have menu prices changed at all over these two years?

**Interviewer · 8:31** (turn 9)

One at a time. Let's take the COGS split first. Here's the breakdown of beans as a share of COGS: Coffee beans were 25% of COGS two years ago.

**Interviewer · 9:33** (turn 10)

Still with me? Take your time.

**Candidate · 11:19** (turn 11)

Let me anchor that. Two years ago, COGS was 42% of revenue and beans were 25% of that, so beans were about 10.5% of revenue. If beans are still 25% of COGS today, that's 25% of 58%, or 14.5% of revenue — so beans alone would explain about 4 of the 16 points, and the other 12 would sit in dairy, packaging, and food.

But I suspect the bean share moved. Green coffee prices have been volatile, and specialty chains are exposed to arabica in particular. If beans went from 25% to, say, 45% of COGS, that's 26% of revenue versus 10.5% — 15 points on its own, which would essentially be the entire problem.

What's the bean share of COGS today?

**Interviewer · 11:21** (turn 12)

Let's pin one number down. You said beans were 25 percent of 42 percent — walk me through how you got about 10.5 percent of revenue.

**Interviewer · 12:22** (turn 13)

Still with me? Take your time.

**Candidate · 13:59** (turn 14)

Beans as a share of revenue is the product of two ratios. COGS is 42% of revenue, and beans are 25% of COGS — so beans are 25% of that 42%.

0.25 × 42% = 10.5% of revenue.

Concretely, if revenue were $100, COGS is $42, and a quarter of that $42 is $10.50 spent on beans. So beans were 10.5 cents of every revenue dollar two years ago.

The reason I want it expressed against revenue rather than against COGS is that the margin decline is measured in points of revenue. Everything has to reconcile to the same denominator, or I can't tell whether a line grew in absolute terms or just grew as a share of a COGS base that was itself expanding.

So if I get today's bean share of COGS, I'll do the same conversion — multiply it by 58% — and the difference from 10.5% is the bean contribution to the 16-point COGS gap.

**Interviewer · 14:01** (turn 15)

Here's what's driving the bean line. I have the bean price change over two years: Raw coffee bean costs are up 40% over the past two years.

**Interviewer · 15:02** (turn 16)

Still with me? Take your time.

**Candidate · 16:51** (turn 17)

Okay, let's size it. Beans were 10.5% of revenue. If input price is up 40% and nothing else changed — same volume per revenue dollar, no menu price increase — beans go to 10.5% × 1.4 = 14.7% of revenue. That's a 4.2-point hit.

So the 40% bean spike is real but it's only about a quarter of the 16-point COGS problem. Twelve points are still unexplained, sitting in dairy, packaging, food, or in units consumed rather than unit price.

Two things that matter here. First, the fact that a 40% input cost increase flowed straight through to margin tells me menu prices didn't move — a healthy chain would have passed some of this on. I asked about menu price history earlier; I'll assume prices have been held flat, which is itself a major finding and probably the most actionable lever.

Second, what happened to dairy and food costs over the same period?

**Interviewer · 16:53** (turn 18)

You flagged menu prices — let's not assume. Here's what I have on menu price changes over two years: Menu prices have not changed in two years.

**Candidate · 18:23** (turn 19)

That confirms the core mechanism: input costs inflated, prices stayed frozen, and the entire increase landed on margin. Brew & Bean absorbed 16 points of COGS inflation without touching the top line.

And it reframes the revenue growth. Revenue is up 15% with flat prices, so that 15% is pure volume — more stores or more transactions. Demand is clearly not the constraint. That's important, because it means they likely have pricing headroom they simply haven't used, and a specialty chain competing on quality rather than price should have some elasticity cushion.

Rough sizing on the lever: revenue is up 15%, so index revenue at 115 with costs of 58 + 22 + 14 = 94% of that. A 10% menu price increase on flat volume adds 11.5 of revenue against essentially unchanged costs, since beans and cups don't get more expensive when you charge more. That moves margin from 6% to roughly 15%.

Do we know anything about competitor pricing over these two years?

**Interviewer · 18:26** (turn 20)

I don't have competitor pricing. One check on your sizing: you said a 10 percent price increase adds 11.5 of revenue — does volume hold when you raise prices 10 percent? What are you assuming?

**Interviewer · 19:27** (turn 21)

Still with me? Take your time. The question on the table: what are you assuming?

**Candidate · 21:08** (turn 22)

I was assuming zero elasticity, which isn't defensible — that was a best-case bound, not a forecast.

Let me redo it properly. Index revenue at 115 with a 6% margin, so profit is about 6.9 and costs are 108.1. Of those costs, roughly 80 points are variable — COGS at 58% and labor at 22% of revenue — and about 16 are fixed overhead.

Now raise price 10% and assume volume falls 5%, which implies elasticity of about -0.5, plausible for specialty coffee with habitual customers. Revenue becomes 115 × 1.10 × 0.95 = 120.2. Variable costs fall with volume: 80 × 0.95 = 76. Fixed stays at 16. Total cost 92, profit 28.2, margin about 23%.

So it still works, and it works largely because losing volume sheds variable cost — at 80% variable, unit contribution is thin enough that trading a little volume for price is favorable.

The number I'd actually want is a price test in a few markets to measure real elasticity rather than assume -0.5.

**Interviewer · 21:11** (turn 23)

One thing you asked for earlier: Other input costs — dairy, packaging, and food — are up 37.5% over the past two years. That's the clock — before we stop, what's your recommendation to the CEO, in a sentence or two?

**Interviewer · 22:12** (turn 24)

Still with me? Take your time. The question on the table: that's the clock — before we stop, what's your recommendation to the CEO, in a sentence or two?

**Candidate · 23:59** (turn 25)

My recommendation: raise menu prices roughly 10 to 15 percent, phased and market-tested, because this is a pricing problem, not a cost problem.

The data reconciles completely. Beans were 10.5% of revenue and rose 40%, giving 14.7. The other inputs were 31.5% of revenue and rose 37.5%, giving 43.3. Together that's 58% — exactly today's COGS. So essentially all of the 16-point COGS increase is broad input inflation, with zero offsetting price action in two years.

Labor held at 22% and volume grew 15%, so operations and demand are healthy. There's no efficiency fix that recovers 16 points.

Risks: real elasticity may exceed my -0.5 assumption, and we lack competitor pricing — if peers also held prices flat, we'd be first mover.

Next steps: price test in 15 to 20 stores, get competitor benchmarks, and hedge or renegotiate bean and dairy contracts to stop the bleeding going forward.

**Interviewer · 24:02** (turn 26)

That's time — thank you for working through this, the derivations and the reconciliation especially. You'll get a full written report with detailed feedback; I won't add anything live here. Thanks for coming in.
