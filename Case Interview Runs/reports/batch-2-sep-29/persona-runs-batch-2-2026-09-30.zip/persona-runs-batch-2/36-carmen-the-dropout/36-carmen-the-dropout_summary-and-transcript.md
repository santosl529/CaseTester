# Live run — Brew & Bean Profitability

- Session: `5c86db99-5014-485f-920f-945cc8f1cf84` · case `prof-001` · status **completed** · 2026-09-30
- Overall: **strong**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **36. Carmen — the Dropout**
- Tests: Rule 16's silence-versus-dropout ambiguity and Rule 19 pause mechanics: check-in first, then session-pause logic — not ladder escalation, and the pause interval must be excluded from case-time analytics.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `menu_price_change`, `bean_share_of_cogs`, `bean_price_change`, `non_bean_input_change`, `stores_count`
- Force-released before the recommendation ask: `[{"phase":"BRAINSTORM","itemIds":["stores_count"],"trigger":"model_ask"}]`
- Scoring QA: `{"caveatFloors":0,"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"markClaimDrops":0,"dataRequestGaps":0,"reconcileMerges":2,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":1,"crossDimensionRepeats":0,"dataRequestsNotInCase":0,"interviewerErrorMarks":0}`
- Assists / interventions: silence_check_in@13, technical_pause@14, session_resumed@15

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 1 | defer | cogs_pct, labor_pct, overhead_pct | Cost breakdown as a percent of revenue for both years | no |
| 3 | release | cogs_pct, labor_pct, overhead_pct | Cost breakdown (COGS, labor, overhead) as a percent of revenue, comparing current year to two years ago | yes |
| 3 | none | stores_count | Store count change over the two-year period | no |
| 5 | none | menu_price_change | Menu price history over the two years — whether price increases were taken | no |
| 7 | release | menu_price_change | Menu price history over the past two years | yes |
| 7 | none | bean_share_of_cogs, non_bean_input_change | COGS breakdown / what components make up COGS | no |
| 9 | release | bean_share_of_cogs, non_bean_input_change | COGS breakdown showing how much of COGS comes from coffee beans versus dairy, packaging, and other inputs | no |
| 11 | none | bean_share_of_cogs | Current coffee beans as a share of COGS | yes |
| 15 | release | non_bean_input_change | Dairy and packaging cost trends, or milk-cost trend data | yes |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 11 | 87468 | 836 | $0.458 |
| coverage | 10 | 18618 | 1090 | $0.024 |
| data_request | 11 | 9532 | 699 | $0.013 |
| judge | 1 | 11082 | 4108 | $0.158 |
| verifier | 1 | 5500 | 553 | $0.041 |
| reconcile | 1 | 2204 | 338 | $0.019 |
| candidate simulator (claude-opus-5) | 11 | 29189 | 3988 | $0.246 |

- App cost (interviewer + scoring): **$0.71** · with simulator: **$0.96** · list prices, uncached
- Wall time: 20:59

## Feedback

**Top improvement:** Sharpen the recommendation from a blanket 12–15% price rise to a selective, elasticity-aware increase (8–12% on high-margin, less-elastic specialty SKUs), and nail the supporting margin math the first time — flow labor and overhead leverage through before stating the recovery number rather than correcting it two turns later.

### Problem Structuring — strong
- ✅ Restated the core tension, formed a hypothesis before asking for data, and enumerated tailored non-overlapping buckets with sub-points.
  > So the key tension is revenue up 15% but margin collapsing from 24% to 6% — that's a three-quarter drop in margin, so this is almost certainly a cost story, not a revenue story.
  > Second, the cost side, split into COGS — coffee beans, milk, cups — versus operating costs like labor, rent, utilities, and then corporate overhead.
- ✅ Prioritized where the answer likely lives and justified it.
  > On prioritization — I'd start with cost as a percent of revenue, comparing the two years side by side. That's the fastest way to isolate which line moved.
- ✅ Stress-tested own MECE-ness and closed a real gap when challenged.
  > One gap: I didn't explicitly carve out non-operating items like interest expense or one-time charges... So let me add that as a fourth bucket.
- 💡 In the opening framework, the candidate covered revenue drivers but did not explicitly raise competitive context or pricing power as a structural element.
  > Better: I'd also want to understand the competitive context — are peers seeing the same margin compression, and what pricing power do we have, since that determines whether we can pass cost increases through.

### Quantitative & Analytical Rigor — strong
- ✅ Correctly attributed margin decline to COGS and quantified the share.
  > Total margin dropped 18 points, and COGS accounts for 16 of those — so roughly 89% of the decline.
- ✅ Executed the nested-percentage conversion correctly, translating bean share of COGS into points of revenue and sizing the bean contribution accurately.
  > Beans started at 10.5% of revenue... a 40% cost increase takes beans to 10.5 × 1.4, about 14.7% of revenue. So beans explain roughly 4.2 of the 16-point COGS increase
  > Other inputs were 75% of COGS two years ago, so 0.75 × 42 = 31.5% of revenue. Up 37.5%, that's 31.5 × 1.375 = 43.3% of revenue. Add beans at 14.7%, and total COGS = 58.0% of revenue. That reconciles exactly to the exhibit.
- ✅ The candidate caught and corrected an own error on margin impact, flowing labor and overhead leverage through properly, but the initial '58/42, about 38%' price-lever sizing was a loose ratio-based approximation and the first margin-recovery figure was materially wrong before self-correction.
  > Now, let me correct myself on the margin number, because I short-changed it. Labor and overhead are also fixed in absolute terms in the near run... profit is 19. That's 19/113 ≈ 16.8%, not 13%.
  > revenue per unit would need to rise by 58/42, about 38%. That's a huge price increase
  > recovering roughly 7 points of margin, to 13%.

### Data & Exhibit Interpretation — strong
- ✅ Isolated the driver, stated the so-what, and proposed the next data pull.
  > COGS accounts for 16 of those... Overhead's 2 points is real but secondary, and labor is flat, so I'd set those aside for now.
  > COGS as a percent of revenue can rise for three reasons... That third one is where I'd start. Do we have menu price history
- ✅ Tested whether the bean spike could explain the full COGS increase rather than stopping at beans, exactly the discriminating move.
  > So beans explain roughly 4.2 of the 16-point COGS increase — call it a quarter of the problem. That's significant but it's not the whole story. Something else is driving the other 12 points.
- ✅ Drew a structural inference from the smooth year-over-year progression.
  > it's a steady progression, not a one-time shock: 42 to 50 to 58, about 8 points a year. That pattern suggests something structural and ongoing rather than a single bad contract.

### Business Judgment & Insight — strong
- ✅ The candidate read the flat-price/volume-up combination as unused pricing power and demand strength, but proposed a single blanket 12–15% increase rather than a selective rise on high-margin, less-elastic SKUs and did not consider that a one-step double-digit rise may itself trigger disproportionate volume loss.
  > flat footprint, flat prices, revenue up 15% means transaction volume is up 15%. Demand is healthy and they have pricing power they aren't using.
  > Brew & Bean should take a phased menu price increase of roughly 12–15% over the next 12 months
- ✅ Correctly concluded that broad-based inflation means procurement alone can't close the gap and pricing must lead.
  > because it's across-the-board, you can't fix it by renegotiating one supplier or swapping one ingredient. Pricing has to do the heavy lifting.
- ✅ Named realistic risks and next steps tied to the recommendation.
  > Risks: volume elasticity, and competitor response. Next steps: elasticity testing in a few markets, and a bean hedging review.
- 💡 When recommending the price increase, the candidate treated it as a uniform menu-wide move.
  > Better: I'd concentrate the increase on high-margin specialty SKUs where demand is least elastic — 8–12% there — rather than a blanket rise, to protect volume on price-sensitive staples.

### Creativity & Brainstorming — strong
- ✅ Organized the brainstorm into explicit buckets before listing ideas.
  > Let me split it into three buckets beyond price.
- ✅ Produced diverse, specific ideas including a non-obvious mix insight tied to the data.
  > Dairy is now the bigger input, so promoting products that use less of it directly helps.
  > Packaging is often the easiest win — lighter cups, fewer SKUs, no double-cupping.
- ✅ Prioritized among the ideas rather than leaving them flat.
  > Realistically, pricing plus mix does most of the work. Should I quantify?
- 💡 The brainstorm covered COGS, mix, and overhead but omitted a lower-cost product tier as a lever for price-sensitive segments.
  > Better: One more option: pilot a lower-cost 'commodity blend' at budget-conscious locations so we hold volume among price-sensitive customers while raising prices on the premium tier.

### Synthesis & Recommendation — strong
- ✅ Led answer-first with a clear, specific recommendation.
  > My recommendation: Brew & Bean should take a phased menu price increase of roughly 12–15% over the next 12 months, paired with mix and procurement actions.
- ✅ Gave three supporting reasons tied directly to the analysis, plus risks and next steps.
  > One, the decline is almost entirely COGS — 16 of the 18 margin points... Two, prices haven't moved in two years while volume grew 15%... Three, because inflation was across-the-board, procurement alone can't close a 16-point gap.
  > Risks: volume elasticity, and competitor response. Next steps: elasticity testing in a few markets, and a bean hedging review.
- ⚠️ The supporting math embedded in the recommendation carried a wrong margin figure that had to be corrected two turns later, slightly undermining the crispness of the delivered synthesis.
  > a 13% price increase on flat volume lifts revenue 13%, and COGS drops from 58% to about 51% of revenue — recovering roughly 7 points of margin, to 13%.

### Communication & Delivery — strong
- ✅ Consistently top-down and signposted, stating structure before detail.
  > I'd approach it in three buckets. First, confirm the revenue side...
  > Let me split it into three buckets beyond price.
- ✅ Used hypothesis-driven phrasing throughout.
  > this is almost certainly a cost story, not a revenue story
  > That third one is where I'd start.
- ✅ Recovered composure and communication cleanly after a technical dropout.
  > sorry, did you hear any of that? my wifi dropped. Picking up where I was

### Pushback, Composure & Case Leadership — strong
- ✅ Answered the MECE challenge crisply, holding the structure while conceding a genuine gap with reasoning.
  > Honestly, it's close to MECE but not perfectly... One gap: I didn't explicitly carve out non-operating items... So let me add that as a fourth bucket.
- ✅ Handled the 'where did the middle year come from' probe by sourcing it and explaining why it mattered analytically.
  > From the exhibit you showed — the middle row, 'Last year,' has COGS at 50%.
  > if the jump had been 42 to 44 to 58, I'd be hunting for a discrete event last year
- ✅ On the final challenge, updated the figure without defensiveness and explained exactly what changed.
  > Now, let me correct myself on the margin number, because I short-changed it... So a 13% increase gets them to roughly 17% margin — closer to the 24% starting point than I said.

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a moment, then walk me through how you'd approach this.

**Candidate · 1:30** (turn 1)

Let me take a second to structure this.

So the key tension is revenue up 15% but margin collapsing from 24% to 6% — that's a three-quarter drop in margin, so this is almost certainly a cost story, not a revenue story. If revenue grew and margin fell that hard, costs grew much faster than revenue.

I'd approach it in three buckets. First, confirm the revenue side: is the 15% growth coming from new stores, more transactions per store, or higher prices? That matters because new-store growth can drag margins if new locations aren't mature yet.

Second, the cost side, split into COGS — coffee beans, milk, cups — versus operating costs like labor, rent, utilities, and then corporate overhead. I'd want to see which line grew fastest as a percentage of revenue.

Third, once we isolate the driver, figure out whether it's price-driven, volume-driven, or efficiency-driven, and then build recommendations from there.

Does that structure work? And do we have a cost breakdown as a percent of revenue for both years?

**Interviewer · 1:32** (turn 2)

Okay. Before we get to data — is that structure MECE, and which branch would you prioritize first?

**Candidate · 3:02** (turn 3)

Honestly, it's close to MECE but not perfectly. Revenue and cost are collectively exhaustive on the P&L, and within costs, COGS versus operating versus corporate overhead don't overlap if I define them cleanly — COGS is variable per unit sold, operating is store-level fixed or semi-fixed, corporate is above-store. One gap: I didn't explicitly carve out non-operating items like interest expense or one-time charges, and if they took on debt to fund expansion, that hits net margin without touching operations. So let me add that as a fourth bucket.

On prioritization — I'd start with cost as a percent of revenue, comparing the two years side by side. That's the fastest way to isolate which line moved. Revenue grew, so revenue is less likely the culprit, though I do want to know the store count change because expansion could be driving both the revenue growth and the cost bloat simultaneously.

Can I get that cost breakdown?

**Interviewer · 3:05** (turn 4)

Here's the cost structure as a percent of revenue. COGS is 58% of revenue today, up from 42% two years ago. Labor is 22% of revenue, and it’s been stable. Overhead is 14% of revenue, up slightly from 12%.

**Candidate · 4:36** (turn 5)

That's clear. Total margin dropped 18 points, and COGS accounts for 16 of those — so roughly 89% of the decline. Overhead's 2 points is real but secondary, and labor is flat, so I'd set those aside for now.

And it's a steady progression, not a one-time shock: 42 to 50 to 58, about 8 points a year. That pattern suggests something structural and ongoing rather than a single bad contract.

COGS as a percent of revenue can rise for three reasons. One, input costs per unit went up — green coffee, dairy, packaging. Two, the mix shifted toward lower-margin items. Three, prices didn't keep pace, so even flat input costs would show up as a higher percentage if we held menu prices while costs crept.

That third one is where I'd start. Do we have menu price history over the two years — have they taken any price increases?

**Interviewer · 4:38** (turn 6)

You mentioned a steady progression, 42 to 50 to 58 — walk me through where you got the middle year.

**Candidate · 6:08** (turn 7)

From the exhibit you showed — the middle row, "Last year," has COGS at 50%. So it's 42 two years ago, 50 last year, 58 current. That's an 8-point step each year, which is what made me say it's a steady progression rather than a single shock.

The reason I flagged it: if the jump had been 42 to 44 to 58, I'd be hunting for a discrete event last year — a supplier contract renegotiation, a bad hedge rolling off, a big menu change. A smooth 8-point-per-year climb looks more like a sustained input cost trend, or prices staying flat while costs drift up year over year.

Profit tracks it inversely too — 24, 15, 6, so about 9 points a year. The extra point versus COGS is the overhead creep, 12 to 13 to 14.

So back to my question — do we have menu price history, or data on what's inside COGS?

**Interviewer · 6:10** (turn 8)

Let me give you the menu price history and the COGS breakdown. Here's the menu price data first: Menu prices have not changed in two years.

**Candidate · 7:40** (turn 9)

That's a big finding. Flat prices for two years while COGS rose 16 points of revenue means they've absorbed every bit of input cost inflation. And note that revenue grew 15% with no price increase — so that growth is entirely volume or store count, which actually makes the cost problem worse, because they're selling more units at a worse margin on each one.

Let me size the price lever roughly. If COGS is 58% of revenue and we want it back near 42%, holding unit costs constant, revenue per unit would need to rise by 58/42, about 38%. That's a huge price increase and not realistic in one step — so price alone won't fix this, but it's clearly part of the answer.

Before I go further on recommendations, can I see the COGS breakdown? I want to know whether this is concentrated in one input — say green coffee beans — or spread across beans, dairy, and packaging. That changes whether we're talking hedging and supplier negotiation versus a broader menu redesign.

**Interviewer · 7:42** (turn 10)

Here's the COGS breakdown. Beans first: Coffee beans were 25% of COGS two years ago.

**Candidate · 8:58** (turn 11)

Okay, so beans were 25% of COGS two years ago. Let me anchor that in revenue terms: COGS was 42% of revenue, so beans were 0.25 × 42, which is about 10.5% of revenue.

Now I need the current figure to see whether beans grew as a share. If beans are still 25% of a much bigger COGS, that's 0.25 × 58, about 14.5% of revenue — so beans alone would explain 4 of the 16 points, and the rest is elsewhere. But if beans jumped to, say, 45% of COGS, that's 0.45 × 58, roughly 26% of revenue, which would be

**Interviewer · 9:00** (turn 12)

Let me give you the two remaining pieces. Here's how bean prices moved: Raw coffee bean costs are up 40% over the past two years.

**Interviewer · 10:01** (turn 13)

Still with me? Take your time.

**Interviewer · 12:01** (turn 14)

Looks like we may have lost you — I've paused the clock. If you're not back within 5 minutes, we'll end the session here.

**Candidate · 13:50** (turn 15)

sorry, did you hear any of that? my wifi dropped. Picking up where I was — if beans jumped to 45% of COGS, that's 0.45 × 58, roughly 26% of revenue, which would make beans the dominant driver on its own.

Now, with the 40% bean cost increase, let me test that. Beans started at 10.5% of revenue. If volume per unit is unchanged and prices are flat, a 40% cost increase takes beans to 10.5 × 1.4, about 14.7% of revenue. So beans explain roughly 4.2 of the 16-point COGS increase — call it a quarter of the problem.

That's significant but it's not the whole story. Something else is driving the other 12 points. Do we have the dairy and packaging numbers, or a milk-cost trend? That's the gap I need to close.

**Interviewer · 13:52** (turn 16)

I've got that piece. Here's the other-input change: Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 15:23** (turn 17)

That closes it. Other inputs were 75% of COGS two years ago, so 0.75 × 42 = 31.5% of revenue. Up 37.5%, that's 31.5 × 1.375 = 43.3% of revenue. Add beans at 14.7%, and total COGS = 58.0% of revenue. That reconciles exactly to the exhibit.

So the answer is cleaner than I expected: this isn't a mix problem or a waste problem. Input costs rose roughly 38–40% across the board — beans and everything else — and Brew & Bean passed none of it through. Beans contribute about 4.2 points of the 16, other inputs about 11.8 points. It's broad-based commodity inflation meeting a frozen menu.

The implication for recommendations is important: because it's across-the-board, you can't fix it by renegotiating one supplier or swapping one ingredient. Pricing has to do the heavy lifting.

Want me to go to a recommendation, or should I size the price increase needed first?

**Interviewer · 15:24** (turn 18)

Beyond pricing, what else could Brew and Bean do to reverse the margin decline? Give me a structured set of options.

**Candidate · 16:55** (turn 19)

Let me split it into three buckets beyond price.

First, cost of goods. Supplier consolidation and volume commitments — 200 stores is real buying power, and if they're buying spot rather than on contract, locking in forward contracts or hedging beans smooths volatility. Recipe and portion engineering: standardizing pours, reducing milk overpour, and cutting waste from spoilage and remakes. Packaging is often the easiest win — lighter cups, fewer SKUs, no double-cupping.

Second, mix. Even without changing headline prices, you can shift revenue toward higher-margin items — food attach, drip coffee over milk-heavy espresso drinks, and pushing sizes. Dairy is now the bigger input, so promoting products that use less of it directly helps.

Third, overhead and productivity. Overhead crept from 12 to 14 points; I'd want to know if that's corporate headcount added for expansion. Labor's flat at 22% but that's flat against growing revenue, so there may be no problem there.

Realistically, pricing plus mix does most of the work. Should I quantify?

**Interviewer · 16:57** (turn 20)

Understood. Before we wrap, on what you asked about earlier: 200 stores today — and it was 200 stores two years ago, so the footprint hasn’t changed. What's your recommendation to the CEO?

**Candidate · 18:27** (turn 21)

That store count detail actually strengthens the case: flat footprint, flat prices, revenue up 15% means transaction volume is up 15%. Demand is healthy and they have pricing power they aren't using.

My recommendation: Brew & Bean should take a phased menu price increase of roughly 12–15% over the next 12 months, paired with mix and procurement actions.

Three supporting points. One, the decline is almost entirely COGS — 16 of the 18 margin points — driven by 38–40% broad-based input inflation, not operational failure. Two, prices haven't moved in two years while volume grew 15%, so customers are choosing them on something other than price. Three, because inflation was across-the-board, procurement alone can't close a 16-point gap.

Rough math: a 13% price increase on flat volume lifts revenue 13%, and COGS drops from 58% to about 51% of revenue — recovering roughly 7 points of margin, to 13%.

Risks: volume elasticity, and competitor response. Next steps: elasticity testing in a few markets, and a bean hedging review.

**Interviewer · 18:29** (turn 22)

Walk me through that last figure — how a 13% price increase moves COGS from 58% to about 51%.

**Candidate · 20:00** (turn 23)

Sure. Index revenue at 100 today. COGS is 58, labor 22, overhead 14, profit 6.

A 13% price increase on flat volume takes revenue to 113. Input costs don't change — you're buying the same beans and milk for the same number of drinks — so COGS stays at 58 in absolute terms. As a percent: 58/113 = 51.3%. That's the 7-point drop.

Now, let me correct myself on the margin number, because I short-changed it. Labor and overhead are also fixed in absolute terms in the near run — 22 and 14. So total costs stay at 94, revenue is 113, profit is 19. That's 19/113 ≈ 16.8%, not 13%. I under-counted by only flowing through the COGS leverage and not labor and overhead.

So a 13% increase gets them to roughly 17% margin — closer to the 24% starting point than I said. Though that assumes zero volume loss, which is why elasticity testing is the first next step.

**Interviewer · 20:02** (turn 24)

That's time. You'll get a full written report with detailed feedback afterward. Thanks for working through the case.
