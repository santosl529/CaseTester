# Live run — Brew & Bean Profitability

- Session: `c6076209-0da1-4541-9f9a-4f60ae402abc` · case `prof-001` · status **completed** · 2026-09-30
- Overall: **needs_work**
- Candidate simulator: `claude-opus-5` (sees only the transcript)
- Persona: **1. Maya — the Freezer**
- Tests: Rules 13 (full ladder + silence tolerance), 14 (two-attempt cap, repeated-error class), 12/13 (synthesis cap), 15, 17-C1, 17-C5 — the highest-stakes untested path in the spec.
- Pacing: human (8000ms think + 90 wpm typing, ≤90s per turn); persona pauses ≤600s

## Rule 11 / v4.1 checks

- Ledger items revealed: `cogs_pct`, `labor_pct`, `overhead_pct`, `bean_share_of_cogs`, `bean_price_change`, `non_bean_input_change`, `menu_price_change`, `revenue_total`, `stores_count`, `avg_ticket`
- Force-released before the recommendation ask: none
- Scoring QA: `{"caveatFloors":0,"artifactTypes":[],"gapClaimDrops":0,"verifierDrops":0,"evidenceStrips":0,"markClaimDrops":0,"dataRequestGaps":0,"reconcileMerges":4,"evidencePointDrops":0,"transcriptArtifacts":0,"dataRequestBackfills":2,"crossDimensionRepeats":1,"dataRequestsNotInCase":1,"interviewerErrorMarks":0}`
- Assists / interventions: silence_check_in@1, restate_anchor@44, silence_check_in@48, narrow_frame@49, silence_check_in@51, synthesis_unresolved@52, synthesis_unresolved@58, load_shed@64

| Candidate turn | Response | Ledger items | Asked for | Revealed by then |
|---|---|---|---|---|
| 6 | release | stores_count | Whether store count has changed over the past two years | no |
| 8 | clarify | revenue_total | Clarification of whether 15% revenue growth is annual or cumulative over two years | no |
| 10 | defer | menu_price_change, avg_ticket | Whether revenue growth is driven by customer volume increases or price increases | no |
| 22 | release | cogs_pct, labor_pct, overhead_pct | Breakdown of cost lines as a percentage of revenue | yes |
| 32 | clarify | bean_share_of_cogs, non_bean_input_change | COGS breakdown between coffee beans, milk, cups, and other inputs | no |
| 32 | none | menu_price_change | Menu price changes over time | no |
| 34 | release | bean_price_change | Current coffee bean prices or what beans cost today | yes |
| 34 | none | menu_price_change | Menu price changes over time | no |
| 36 | release | non_bean_input_change | Breakdown of COGS components: milk, cups, food, and waste | yes |
| 38 | release | menu_price_change | Menu price changes over 2 years | yes |
| 38 | release | revenue_total, stores_count | Total revenue and store count | yes |
| 64 | release | — | access to written report with case details and specifics | no |

## LLM usage

| Component | Calls | Input tokens | Output tokens | Est. USD |
|---|---|---|---|---|
| interviewer | 34 | 255513 | 1893 | $1.325 |
| data_request | 34 | 23135 | 1171 | $0.029 |
| coverage | 32 | 55257 | 4499 | $0.078 |
| judge | 1 | 12582 | 3798 | $0.158 |
| verifier | 1 | 6356 | 1332 | $0.065 |
| reconcile | 1 | 2881 | 983 | $0.039 |
| candidate simulator (claude-opus-5) | 33 | 88757 | 2409 | $0.504 |

- App cost (interviewer + scoring): **$1.69** · with simulator: **$2.20** · list prices, uncached
- Wall time: 21:28

## Feedback

**Top improvement:** Practice converting a diagnosis into a committed, answer-first recommendation: once you've isolated that inputs rose while prices stayed flat, immediately name the lever (raise prices), give 2-3 supporting reasons, a risk, and a next step — and hold composure under questioning instead of retreating to 'I don't know.'

### Problem Structuring — needs_work
- ⚠️ The candidate opened with three broad buckets covering revenue, cost, and external context, but the framework was a generic, untailored list with no restated objective and no coffee-chain-specific sub-points.
  > First, revenue — like what's happening with sales. Second, costs, so what they're spending money on.
  > First, revenue — like what's happening with sales. Second, costs, so what they're spending money on. And third, maybe the market or competition
- ⚠️ Could not prioritize with sound reasoning and then could not break the cost side down without heavy interviewer scaffolding.
  > hmm, I'm not sure. Maybe costs?
  > I'm stuck, sorry.
  > I don't really know where to start.
- ⚠️ The cost buckets (rent, labor, coffee) were only produced after the interviewer walked it down to a single coffee shop.
  > Um... rent, and the workers. And the coffee itself, I guess.
- 💡 At turn 11 the interviewer asked which branch to prioritize and why.
  > Better: I'd start with costs, because revenue grew 15% yet margin collapsed 18 points — that pattern points to a cost problem, not a demand one. I'd disaggregate costs into COGS, labor, and overhead, hypothesizing COGS given input inflation, and I'd check revenue as price × volume to confirm demand is healthy.

### Quantitative & Analytical Rigor — meets_bar
- ✅ Correctly executed the nested-percentage conversion for beans, translating a share of COGS into points of revenue.
  > 25% of 42 is 10.5, so beans were 10.5 points of revenue. Up 40% is 14.7, so +4.2 points.
- ✅ Completed the full COGS decomposition accurately, tying the two input drivers back to the 16-point increase.
  > The rest is 75% of COGS, so 31.5 points of revenue. Up 37.5% is about 43.3, so +11.8 points.
  > 4.2 plus 11.8 is 16 points. That's the whole COGS increase.
- ✅ Decomposed revenue growth into ticket and traffic to show demand was healthy.
  > revenue up 15%, ticket up 10%, so transactions up roughly 5% — traffic's actually fine.
- ⚠️ Repeatedly conflated a points-of-revenue change with a percent change and defended the error under questioning until walked through it.
  > COGS went from 42 to 58, so that's a 16% increase in COGS
  > It's up 16% I think? Like it went from 42 to 58, so 16%.
  > I think it's a 16% change, because it went up by 16 from 42.
- ⚠️ Needed the interviewer to explicitly point out that 16 divided by 42 is not 16% before correcting.
  > Okay — 16 plus 2 is 18 points, and the margin fell 18 points, so that explains all of it.
- 💡 At turn 24 the candidate labeled the COGS shift a '16% increase' rather than a points-of-revenue change.
  > Better: COGS rose 16 points of revenue, from 42% to 58%. Combined with overhead's 2-point rise, that's the full 18-point margin drop — so the margin story lives almost entirely in COGS.

### Data & Exhibit Interpretation — meets_bar
- ✅ Immediately isolated COGS as the driver from the cost structure and correctly dismissed labor and overhead.
  > That's the big one — labor's flat and overhead only moved 2%.
- ✅ Proactively asked for the next relevant slices of data rather than stopping at the first insight.
  > Do we have the other pieces — milk, cups, food, waste?
  > Do we have anything on what's inside COGS — like a split between coffee beans, milk, cups
- ⚠️ The candidate initially reached for an unfounded assumption that beans were the mover, but after being redirected did test whether beans alone could explain the COGS increase and drew the correct so-what that other inputs were the larger driver.
  > I'll assume beans are the piece that moved unless you tell me otherwise
  > I wanted to ask about menu prices too but I'll assume they haven't changed much
  > So beans only explain a quarter of it. Something else in COGS moved a lot more.
  > it's not just beans — it's basically every input going up together, and they haven't raised prices.

### Business Judgment & Insight — needs_work
- ✅ Correctly framed the root cause as a pass-through problem rather than a demand problem.
  > it's a pass-through problem, not a demand problem
  > the whole margin decline is input cost inflation with zero price pass-through.
- ⚠️ Could not name the obvious pricing lever even after diagnosing flat prices against 40% input inflation.
  > I don't know.
  > I'm sorry, I don't know.
- ⚠️ Risk awareness on a price increase was thin and only surfaced elasticity in the most generic terms.
  > that customers stop coming, I guess.
  > I don't really know beyond that.
- ⚠️ Procurement and menu levers came only after directive prompting and were vague.
  > Maybe buy in bulk, or lock in a price?
  > Maybe take off the things that cost the most?
- 💡 At turn 47 the interviewer asked what to worry about when raising prices.
  > Better: Elasticity — I'd raise selectively, 8–12% on high-margin specialty SKUs where demand is least price-sensitive, protect entry-level drinks, and pilot before rolling chain-wide to watch traffic and competitor response.

### Creativity & Brainstorming — needs_work
- ⚠️ Produced only obvious, single-line ideas and dried up quickly even with heavy scaffolding.
  > Maybe buy in bulk, or lock in a price?
  > Maybe take off the things that cost the most?
- ⚠️ No structure to the brainstorm and repeated declarations of not knowing.
  > I don't know, sorry.
  > I don't really know.
- 💡 At turn 50 the interviewer asked for levers beyond a price increase.
  > Better: I'd split levers into pricing, procurement, and product mix: multi-year supply contracts across beans, dairy, and packaging; a lower-cost commodity blend for budget locations; reformulating high-cost SKUs and cutting waste. I'd prioritize pricing and procurement since they hit the biggest input drivers.

### Synthesis & Recommendation — needs_work
- ⚠️ The candidate eventually articulated a clean one-line diagnosis of the root cause, but could not convert it into a recommendation, requiring multiple directive rescues before naming the lever.
  > I know I found the number, but I don't know how to say it as a recommendation.
  > Raise prices, I guess. But I don't know past that.
  > input costs went up about 40% and they never raised prices, so the margin got squeezed.
- ⚠️ The final recommendation was a single hedged lever with no supporting reasons, risks, or next steps.
  > Raise prices, I think. Beyond that I really don't know — sorry.
- 💡 At turn 57 the interviewer asked the candidate to pull it together for the CEO.
  > Better: Root cause: inputs rose ~38% while menu prices stayed flat two years, driving all 18 margin points of compression — a pass-through problem, not demand. Recommendation: raise prices 8–12% on high-margin specialty SKUs, pair with renegotiated multi-year supply contracts across all inputs, and pilot a lower-cost blend. Key risk is elasticity, so test before scaling.

### Communication & Delivery — needs_work
- ✅ When math flowed, narration was clear and step-by-step.
  > 25% of 42 is 10.5, so beans were 10.5 points of revenue. Up 40% is 14.7, so +4.2 points.
- ✅ Closed with an honest, coachable reflection on what tripped them up.
  > I think I see it now: costs moved almost 40% across every input, prices didn't move at all, and traffic is actually fine, so it's a pass-through problem
- ⚠️ Frequently defaulted to 'I don't know' and self-deprecation rather than working the problem out loud.
  > God, I'm so bad at this. Honestly I'm probably going to bomb every interview I do
  > I'm stuck, sorry.
- ⚠️ Answers were bottom-up and hesitant with heavy filler, rarely leading with a top-down structure.
  > hmm, I'm not sure. Maybe costs?
  > Um... rent, and the workers. And the coffee itself, I guess.

### Pushback, Composure & Case Leadership — needs_work
- ⚠️ Melted into self-criticism under mild pressure rather than composed evaluative reasoning.
  > God, I'm so bad at this. Honestly I'm probably going to bomb every interview I do, I don't even know why I'm doing this.
- ⚠️ Was largely led rather than driving; required Level 1 and Level 2 assists and still could not deliver an independent recommendation.
  > I'm sorry — I really don't know.
  > I know I found the number, but I don't know how to say it as a recommendation.
- ⚠️ The candidate defended the wrong percent framing several times instead of pausing to check the arithmetic when challenged, but stayed engaged through repeated correction and did eventually incorporate the points-versus-percent distinction.
  > I think it's a 16% change, because it went up by 16 from 42.
  > Okay — 16 plus 2 is 18 points, and the margin fell 18 points, so that explains all of it.
- 💡 At turns 43-46 the interviewer repeatedly anchored toward the pricing lever.
  > Better: The lever is the one thing that never moved — menu prices. Since inputs rose ~38% with zero pass-through, I'd recommend a targeted price increase as the first move, then pressure-test elasticity.

## Transcript

**Interviewer · 0:00** (turn 0)

Your client is Brew & Bean, a specialty coffee chain with 200 locations across the US. Over the past two years, their net profit margin has declined from 24% to 6%, even though revenues have grown 15% over the same period. The CEO has hired us to identify the root cause of this profit decline and recommend how to reverse it. How would you approach this problem?

Take a moment, then walk me through how you'd approach this.

**Interviewer · 1:01** (turn 1)

Still with me? Take your time. The question on the table: how would you approach this problem?

**Candidate · 1:55** (turn 2)

Okay. So I guess I'd want to look at, um, three things. First, revenue — like what's happening with sales. Second, costs, so what they're spending money on. And third, maybe the market or competition, like what's going on outside the company.

Does that seem okay as a starting point?

**Interviewer · 1:57** (turn 3)

Before I react — what one or two questions would you want answered to scope this problem?

**Candidate · 2:17** (turn 4)

Um, first — when you say net profit margin, is that after everything, like taxes and interest too?

**Interviewer · 2:19** (turn 5)

Treat it as operating margin — costs of running the business, before tax and interest. What else?

**Candidate · 2:43** (turn 6)

Okay. And the 200 locations — is that the same as two years ago, or did they open a bunch of new stores?

**Interviewer · 2:44** (turn 7)

Store count is roughly flat over the two years. Now walk me through your framework in more detail.

**Candidate · 3:05** (turn 8)

Sorry, one more thing — the 15% revenue growth, is that total over the two years or per year?

**Interviewer · 3:07** (turn 9)

Total over the two years. Now, your framework — flesh it out for me.

**Candidate · 3:25** (turn 10)

And is that revenue growth coming from more customers, or from higher prices? Do we know?

**Interviewer · 3:27** (turn 11)

Hold that — that's an analysis question we'll get to. First, your framework.

You named revenue, costs, and market. Which branch do you prioritize, and why?

**Candidate · 3:40** (turn 12)

hmm, I'm not sure. Maybe costs?

**Interviewer · 3:41** (turn 13)

Why costs? Give me your reasoning.

**Candidate · 3:58** (turn 14)

Because revenue went up but profit went down... so something on the cost side?

**Interviewer · 4:00** (turn 15)

Okay. So how would you break down the cost side to find the driver?

**Candidate · 4:10** (turn 16)

I'm stuck, sorry.

**Interviewer · 4:11** (turn 17)

Take a breath. Costs of running a coffee chain — what buckets would money go into?

**Candidate · 4:24** (turn 18)

I don't really know where to start.

**Interviewer · 4:26** (turn 19)

Think about a single coffee shop. What does it pay for to keep the doors open?

**Candidate · 4:41** (turn 20)

Um... rent, and the workers. And the coffee itself, I guess.

**Interviewer · 4:43** (turn 21)

So rent, labor, and the coffee and ingredients. Which of those would you look at first, and how?

**Candidate · 5:02** (turn 22)

Do we have a breakdown of the cost lines, like what percent of revenue each one is?

**Interviewer · 5:05** (turn 23)

I have that. Here's the cost structure. COGS is 58% of revenue today, up from 42% two years ago. Labor is 22% of revenue, and it’s been stable. Overhead is 14% of revenue, up slightly from 12%.

**Candidate · 5:44** (turn 24)

Okay so COGS went from 42 to 58, so that's a 16% increase in COGS. That's the big one — labor's flat and overhead only moved 2%.

So COGS grew 16% and that basically explains the whole margin drop.

Am I on the right track?

**Interviewer · 5:45** (turn 25)

Say "16 points," not "16%" — points of what? Tie that to the margin drop of eighteen points for me.

**Candidate · 6:27** (turn 26)

God, I'm so bad at this. Honestly I'm probably going to bomb every interview I do, I don't even know why I'm doing this.

But — COGS went up 16%, and the margin dropped 18 points, so the 16% is most of it, plus overhead going up 2 covers the rest.

**Interviewer · 6:29** (turn 27)

Stay with it — you're actually closing the gap. One precision point: is COGS up sixteen percent, or sixteen points of revenue?

**Candidate · 7:04** (turn 28)

It's up 16% I think? Like it went from 42 to 58, so 16%.

I mean — sorry, I know you're pushing me on that. Do you want me to walk through where the 18 points come from again?

**Interviewer · 7:06** (turn 29)

From forty-two to fifty-eight — is that a percent change, or a change in points of revenue? Which one, and why does it matter here?

**Candidate · 7:41** (turn 30)

I think it's a 16% change, because it went up by 16 from 42. And it matters because that's what's eating the margin.

Sorry, am I on the right track at all? I feel like I'm missing something you're pointing at.

**Interviewer · 7:44** (turn 31)

Sixteen divided by forty-two isn't sixteen percent — so "up 16" is a change in points of revenue, not a percent. Sixteen points of revenue plus two points of overhead — how much margin does that explain?

**Candidate · 8:30** (turn 32)

Okay — 16 plus 2 is 18 points, and the margin fell 18 points, so that explains all of it.

So COGS is basically the whole story.

Do we have anything on what's inside COGS — like a split between coffee beans, milk, cups, that kind of thing? Or whether prices on the menu changed at all?

**Interviewer · 8:34** (turn 33)

Here's the beans share of COGS. Coffee beans were 25% of COGS two years ago.

**Candidate · 9:34** (turn 34)

Okay, and I don't think I have what beans are today, so I'll assume beans are the piece that moved unless you tell me otherwise — since green coffee prices have been going up, that'd be the most likely driver.

Sorry, I wanted to ask about menu prices too but I'll assume they haven't changed much, which would mean they're eating the whole input cost increase instead of passing it through.

Is that a fair place to be?

**Interviewer · 9:37** (turn 35)

Don't assume — you asked, so let's test it. Here's the bean price change over two years. Raw coffee bean costs are up 40% over the past two years.

**Candidate · 10:31** (turn 36)

Okay so beans were 25% of COGS, and COGS was 42% of revenue, so beans were about 10.5% of revenue. Up 40% means they go to about 14.7%, so that's only about 4 points of revenue.

But COGS went up 16 points. So beans only explain a quarter of it. Something else in COGS moved a lot more.

Do we have the other pieces — milk, cups, food, waste?

**Interviewer · 10:33** (turn 37)

Walk me through that conversion once more — twenty-five percent of COGS, at COGS being forty-two percent of revenue, gives you what in points of revenue? Other input costs — dairy, packaging, and food — are up 37.5% over the past two years.

**Candidate · 11:26** (turn 38)

25% of 42 is 10.5, so beans were 10.5 points of revenue. Up 40% is 14.7, so +4.2 points.

The rest is 75% of COGS, so 31.5 points of revenue. Up 37.5% is about 43.3, so +11.8 points.

4.2 plus 11.8 is 16 points. That's the whole COGS increase. So it's not just beans — it's basically every input going up together, and they haven't raised prices.

**Interviewer · 11:30** (turn 39)

You keep saying "they haven't raised prices" — but that's the one thing you assumed. Here's the menu price change. And here's total revenue and store count while I'm at it. Menu prices have not changed in two years. Total revenue is $480M a year. 200 stores today — and it was 200 stores two years ago, so the footprint hasn’t changed. The average transaction is $6.80, up from $6.20 two years ago — about a 10% increase, because customers are buying more items per visit.

**Candidate · 12:08** (turn 40)

Okay so revenue up 15%, ticket up 10%, so transactions up roughly 5% — traffic's actually fine. And prices haven't moved at all in two years while inputs went up almost 40%.

So the whole margin decline is input cost inflation with zero price pass-through.

**Interviewer · 12:10** (turn 41)

So what's your recommendation to the CEO?

**Candidate · 12:20** (turn 42)

I don't know.

**Interviewer · 12:23** (turn 43)

You just diagnosed it. Inputs up nearly forty percent, menu prices flat — so what's the obvious first move?

**Candidate · 12:35** (turn 44)

I'm sorry, I don't know.

**Interviewer · 12:37** (turn 45)

Take your time. If costs rose and the price never moved, the lever is the thing that never moved. What is it?

**Candidate · 13:30** (turn 46)

I'm sorry — I really don't know.

**Interviewer · 13:32** (turn 47)

If input costs went up and menu prices stayed flat, the direct lever is menu prices. Say you raise them — what would you be worried about?

**Interviewer · 14:33** (turn 48)

Still with me? Take your time. The question on the table: say you raise them — what would you be worried about?

**Candidate · 14:59** (turn 49)

Um... that customers stop coming, I guess.

I don't really know beyond that.

**Interviewer · 15:00** (turn 50)

Okay. Beyond a price increase, what else could the client do to protect margin?

**Interviewer · 16:02** (turn 51)

Still with me? Take your time. The question on the table: beyond a price increase, what else could the client do to protect margin?

**Candidate · 16:21** (turn 52)

I don't know, sorry.

**Interviewer · 16:23** (turn 53)

Think about the cost side you diagnosed. If beans and dairy are up, what could a chain do about how it buys them?

**Candidate · 16:37** (turn 54)

Maybe buy in bulk, or lock in a price?

**Interviewer · 16:39** (turn 55)

Okay. Anything on the product side — the menu itself, or what gets wasted?

**Candidate · 16:56** (turn 56)

Hmm. Maybe take off the things that cost the most?

I don't really know.

**Interviewer · 16:58** (turn 57)

Okay. Pull it together for the CEO — root cause and your top recommendation, in a few sentences.

**Candidate · 17:21** (turn 58)

I'm sorry — I don't know.

I know I found the number, but I don't know how to say it as a recommendation.

**Interviewer · 17:24** (turn 59)

Try this: one sentence on what caused the decline, one on what to do. Just start.

**Candidate · 17:49** (turn 60)

Um... input costs went up about 40% and they never raised prices, so the margin got squeezed.

And what to do... I don't know. Sorry.

**Interviewer · 17:50** (turn 61)

That's the diagnosis. For the action, just name the lever that never moved — finish it in one sentence.

**Candidate · 18:06** (turn 62)

Raise prices, I guess. But I don't know past that. Sorry.

**Interviewer · 18:08** (turn 63)

That's a recommendation. You'll get a full written report afterward.

**Candidate · 19:20** (turn 64)

Okay. Thank you for being patient with me — I know I was pretty stuck for a lot of that, especially on the points versus percent thing.

I think I see it now: costs moved almost 40% across every input, prices didn't move at all, and traffic is actually fine, so it's a pass-through problem, not a demand problem. I just couldn't get from that to the answer when you asked.

God, I'm so bad at this. But I'd like to read the report. Is there anything specific I should drill before my next one?

**Interviewer · 19:23** (turn 65)

Your read there — pass-through problem, not demand — is exactly the synthesis. The report will have the specifics to drill; I'll keep my feedback to that written version. Thanks for working through it. We're near time. What's your bottom-line recommendation to the CEO?

**Candidate · 19:39** (turn 66)

Raise prices, I think. Beyond that I really don't know — sorry.

**Interviewer · 19:41** (turn 67)

That's your recommendation. The full written report will follow. Thanks for your time today.

**Candidate · 20:11** (turn 68)

Thank you. I'm sorry I froze so much — I know that's not what you want in a case.

I'll watch for the report. Thanks again for sticking with me for the whole hour.

**Interviewer · 20:13** (turn 69)

Thank you for working through it. Time's up here, and the written report will follow. Take care.
