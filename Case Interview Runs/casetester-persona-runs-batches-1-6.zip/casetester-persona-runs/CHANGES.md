# What changed between batches

Reconstructed from the git history (commit times matched against the run timestamps) and the project's progress notes. Each section lists what changed *before* that batch ran, so a batch's results reflect the changes listed above it. Short commit ids are given where useful.

"Rule N" refers to the interviewer behaviour spec (`docs/interviewer-behavior.md`). The spec version changed as fixes landed: v4.2 at batch 1, v4.3 at batch 2, v4.6 from batch 3.

## Models used

| Batches | Interviewer | Scoring (judge) |
|---|---|---|
| 1–3 | Claude Opus 4.8, thinking off | Claude Opus 4.8 |
| 4–5 | Claude Sonnet 5.5, thinking off | Claude Opus 5.5, thinking on |
| 6 | Claude Sonnet 5.5, thinking on at low effort | Claude Opus 5.5, thinking on |

Background checks (data-request classifier, coverage, distress, hint check) ran on Claude Haiku 4.5 throughout. The simulated candidate is Claude Opus 5.

---

## Batch 1 (27–28 Sep): baseline, 11 personas
Just before the runs:
- Technical pauses capped, so silence can't buy extra case time.
- A spoken closing line now actually ends the case.
- Once the candidate has given a recommendation, the stuck-candidate help ("ladder") stands down.
- Test harness: persona pause tags, a forced correction for Derek, run logs saved.

## Batch 1 → Batch 2 (29 Sep): spec v4.3
**Data handling**
- The leak audit now actually blocks unreleased figures instead of only logging them (Rule 6).
- The math hint is a question only and never contains case data (Rule 2).
- Promises to give data are recovered even when paraphrased, and data the case holds is never refused (Rule 10).

**Math checks**
- Live and scoring math checks only use numbers that are actually in the transcript and inputs the candidate has been given. All three false corrections in batch 1 were the check's own mistake.

**Conduct and distress**
- The distress check now catches disclosures like Sam's. The interviewer's offer has the required elements, and the case clock pauses during it.
- Off-topic or injection attempts get a redirect and the case continues. Quoted hostile speech is never treated as abuse (Rules 16, 17).

**Close**
- The recommendation question always gets asked (Rule 12).

**Scoring**
- Interviewer errors are marked and excluded from the candidate's score.
- Claims that the candidate made an error are verified.
- A minimum caveat is applied when data coverage was incomplete.
- Ratings were recalibrated.

**Test harness**
- Personas changed to exercise paths batch 1 missed.

## Batch 2 → Batch 3 (30 Sep – 2 Oct): spec v4.4–v4.6
**Data requests**
- A data request the interviewer ignored is resolved in the same turn: released or deferred by code (v4.4).
- The interviewer never challenges an assumption the candidate made about data they had asked for.

**Stuck candidates (Rule 13)**
- Turns are classified by content, and number words count as numbers. This fixed a hint wrongly triggered on Yuki.
- A hint only counts as given if the sent turn actually carries it.

**Distress**
- A second distress check runs on Haiku in parallel with the interviewer, to catch disclosures the keyword list misses.

**Math**
- Figures the candidate has verified are tracked, and probes on correct math are withheld.

**Close**
- Exactly one goodbye, and only once the end is confirmed.

**Leak checks**
- A timeframe-consistency check was added (log-only).

**Scoring**
- New pass checking findings against the answer key and the caveat wording.
- The judge and the claim verifier use structured output.

**Instrumentation**
- Every live check records its decision (the "Check decisions" table in each run's `.md`).

**Test harness**
- Derek's hostility moved later in the case.
- Leah (quiet distress) and Ben (case-only frustration) added.

## Batch 3 → Batch 4 (2 Oct): model switch
**Fixes from batch 3**
- Hint delivery fixed: Maya's hint ladder had frozen.
- Recommendation asks capped: Maya was asked 17 times.

**Data**
- Every fact the interviewer announces is delivered, not just the first one.
- Data requested earlier is released by code once the case reaches that stage.

**Close**
- A request in the candidate's final message is answered before the goodbye.

**Wording**
- System vocabulary ("nothing flagged", "ledger") is rewritten into normal speech.

**Hints**
- A model check confirms whether a question-style hint was really a hint.

**Scoring**
- A "strong" rating requires a checklist against the rubric's strong descriptor.

**Models**
- Interviewer moved to Sonnet 5.5 with thinking off (speed and cost).
- Scoring moved to Opus 5.5 with thinking.
- Server-side refusal fallbacks enabled.

## Batch 4 → Batch 5 (2–3 Oct)
**Scoring**
- In batch 4, scoring failed in every run (the long scoring requests timed out). Scoring now streams, and those runs were re-scored afterwards with `--finish`.

**Sonnet-specific problems**
- Sonnet spoke its reasoning about tools out loud; a narration filter was added.
- It copied the "Still with me?" check-in into its own turns; now removed.
- Three false "impact" flags caused by the word "margin" were fixed.
- Refusals were being read as promises to deliver data; fixed.

**Blank turns**
- A first narration fix produced blank turns, which crashed five batch-5 runs.
- Fixed: plain text is the reply unless the turn also uses the speak tool, and a blank turn is never sent. The five runs were re-run.

**Tests**
- Replay test suite over the saved batch 1–4 runs.

**Test harness**
- Persona set changed: Destiny, Claire, Nikhil, Lena, Devon and Marisol added.

## Batch 5 → Batch 6 (3 Oct)
**Fixes from batch 5**
- The probe guard no longer suppresses unit-error probes (Derek).
- Hints are phrased as instructions.
- Steps that verify the non-bean inputs fixed. The judge had wrongly marked Tobias's math as an error.

**Narration**
- The narration filter now runs on the model's own words only, so released data never passes through it.
- Its patterns cover the phrasing Sonnet actually used.
- A turn that is nothing but narration no longer keeps the narration.

**Thinking**
- Interviewer thinking turned on at low effort to test whether it removes narration at the source.

**Exhibits**
- An exhibit shown with no words gets a scripted line ("Take a look at this and tell me what you see."). Claire's run started a minute before this fix, which is why her first turn is the exhibit with "Go on."

**Logging**
- The interviewer model's raw text is now logged, so narration can be counted before the filter removes it.

**Test harness**
- Persona set changed: Tyler, Marcus, Naomi, Anika, Hugo and Caleb added; Maya, Tobias, Claire and Lena re-run for comparison.

## Not recorded per batch
Small harness and documentation changes are omitted. The batch 1 → 2 and 2 → 3 groupings come from commit times, so a fix committed during a batch may have reached only some of its runs. Batch 1 ran over two days (27–28 Sep), and the late commit `98b8314` only changed the harness's cost reporting.
