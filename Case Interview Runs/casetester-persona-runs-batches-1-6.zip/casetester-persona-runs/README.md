# CaseTester — persona test runs (batches 1–6)

Simulated-candidate runs of the AI case interviewer, 27 Sep – 3 Oct 2026. Each run plays one case (prof-001, "Brew & Bean Profitability", a 20-minute profitability case). A simulated candidate (Claude Opus 5) plays a pressure-test persona. The real interviewer, the real data-gating code and the real scoring pipeline run every turn.

## What's in here

```
CHANGES.md                                         what changed in the code and models between batches
batches/<batch>/<NN-persona>/live-run-<date>-<session>.{md,pdf,json,log}
reference/interviewer-pressure-test-personas.pdf   all 62 personas and what each one tests
reference/Case Interview Feedback Rubric.pdf       the 8-dimension scoring rubric
```

The persona number (NN) matches the personas PDF. For each run:

- **.md** — start here. It has the persona and what it tests, the data-request table (what was asked, and whether it was released, refused or deferred), the per-check decision log, the full feedback report, and the transcript.
- **.pdf** — the feedback report as a candidate would see it. A few batch-1 runs don't have one.
- **.json** — the raw records: turns, events, scores, revealed data.
- **.log** — the console output, including the interviewer model's raw responses.

## Batches

| Batch | Dates | Focus | Headline |
|---|---|---|---|
| 1, 2 | 27–30 Sep | First 11 personas | Found false math corrections, data-gating gaps and distress-handling gaps; fixed between batches. |
| 3 | 2 Oct | Round-2 fixes (last Opus 4.8 batch) | Goodbyes per session 4→1; ignored data requests 23→4; doubt probes on correct math 5→0. |
| 4 | 2 Oct | Switch to Sonnet 5.5 interviewer | Requested-but-never-provided data 4→0; grades spread out more. Sonnet started speaking its reasoning out loud. |
| 5 | 2–3 Oct | Targeted personas | 0 data leaks, 0 broken promises, 0 ignored requests for case data. But the interviewer spoke internal narration ~16 times in 8/10 runs. |
| 6 | 3 Oct | Narration fix + thinking at low effort | 0 narration, 0 leaks, 0 broken promises. But interviewer latency rose (median 1.8s → 2.75s, p95 3.0s → 5.7s). |

## Open problems after batch 6

1. **Interviewer thinking mode undecided.** Thinking at low effort removes narration but is too slow for voice. Leaning towards thinking off, plus a code filter that strips narration.
2. **Interviewer handed a struggling candidate the recommendation** (batch 6, Maya). This breaks the rule that the interviewer never supplies the answer.
3. **A blocked case end produces a bare "Go on."** (batch 6, Maya, after her recommendation and past the 20-minute mark).
4. **Data released without being asked** (2–3 per batch).
5. **Leftover "I'll come to that data shortly" lines** right after data was already given.
6. **Requests for data that isn't in the case are sometimes ignored** instead of refused (1–5 per batch).
7. **Recommendation and goodbye detection gaps:** "didn't get to a recommendation" counts as a recommendation; "we'll leave it there" isn't recognised as a goodbye.
8. **Judge reports for batch 6 not yet reviewed by hand.** Grading consistency (re-scoring the same session) has never been measured.
